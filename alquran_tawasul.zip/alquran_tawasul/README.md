# Al Quran dan Tawasul

Aplikasi Android (Flutter): Al-Quran 30 juz + Tawasul, desain efek kaca (glass).

## Build APK lewat GitHub
1. Buat repo baru di GitHub, upload **semua isi folder ini** (termasuk folder `.github`).
2. Buka tab **Actions** → workflow **Build APK** (jalan otomatis saat push, atau klik *Run workflow*).
3. Tunggu ±8–12 menit. Unduh APK di bagian **Artifacts** → `alquran-tawasul-apk`.
   Pilih `app-arm64-v8a-release.apk` untuk HP modern.

Saat build, workflow mengunduh teks Al-Quran lengkap (114 surah, 6236 ayat, 30 juz), terjemahan Indonesia,
transliterasi dan tafsir Jalalayn dan menyimpannya di dalam APK (bisa dibaca offline).

## Fitur
- Quran: tab Bookmark / Juz / Surah (daftar surah + nama Arab + tombol audio), baca dalam halaman mushaf Utsmani 604 halaman (geser kiri-kanan, ketuk ayat untuk terjemahan/audio), mode daftar, bookmark, salin ayat
- Membaca: lanjutkan baca terakhir, ayat hari ini, baca per juz
- Tawasul: buat buku (folder), isi tulisan manual, edit font Arab (14 font, ukuran, jarak baris, warna, perataan)
- Pengaturan: Tampilan (10 tema warna, 14 gaya penulisan, tajwid berwarna, terjemahan, tafsir, ukuran huruf),
  Qari, Unduhan audio, Statistik, Target Khatam, Versi Aplikasi, Laporan Bug, Tentang Kami, Kebijakan Privasi

## Offline
Teks Al-Quran, terjemahan, tafsir, dan semua font dimasukkan ke dalam APK saat build, jadi membaca bisa 100% tanpa internet.
Hanya audio qari yang perlu diunduh dulu (Pengaturan → Unduhan) agar bisa diputar offline.

## Jika folder .github tidak terlihat / tidak ikut ter-upload
Folder berawalan titik sering disembunyikan oleh file manager HP/PC. File yang sama tersedia juga sebagai `build.yml` di folder utama.
Di GitHub: **Add file → Create new file**, ketik nama `.github/workflows/build.yml`, lalu tempel isi `build.yml`, klik **Commit**.
