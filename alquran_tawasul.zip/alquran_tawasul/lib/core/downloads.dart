import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'audio.dart';
import 'data.dart';

/// Layanan latar depan (foreground service) agar unduhan tetap jalan saat layar mati / aplikasi ditutup dari layar utama.
class BgService {
  static bool _ready = false;

  static void init() {
    try {
      FlutterForegroundTask.init(
        androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'alquran_download',
          channelName: 'Unduhan audio',
          channelDescription: 'Progres unduhan audio Al Quran',
          onlyAlertOnce: true,
        ),
        iosNotificationOptions: const IOSNotificationOptions(),
        foregroundTaskOptions: ForegroundTaskOptions(
          eventAction: ForegroundTaskEventAction.nothing(),
          allowWakeLock: true,
          allowWifiLock: true,
        ),
      );
      _ready = true;
    } catch (_) {}
  }

  static Future<void> askNotificationPermission() async {
    try {
      final perm = await FlutterForegroundTask.checkNotificationPermission();
      if (perm != NotificationPermission.granted) {
        await FlutterForegroundTask.requestNotificationPermission();
      }
    } catch (_) {}
  }

  static Future<void> start(String text) async {
    if (!_ready) return;
    try {
      if (await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.updateService(notificationTitle: 'Mengunduh audio', notificationText: text);
      } else {
        await FlutterForegroundTask.startService(notificationTitle: 'Mengunduh audio', notificationText: text);
      }
    } catch (_) {}
  }

  static Future<void> update(String text) async {
    if (!_ready) return;
    try {
      await FlutterForegroundTask.updateService(notificationTitle: 'Mengunduh audio', notificationText: text);
    } catch (_) {}
  }

  static Future<void> stop() async {
    if (!_ready) return;
    try {
      await FlutterForegroundTask.stopService();
    } catch (_) {}
  }
}

class _Job {
  final String qari;
  final Surah surah;
  _Job(this.qari, this.surah);
}

/// Pengelola unduhan: berjalan terlepas dari halaman Unduhan, dengan antrean dan notifikasi.
class DownloadManager extends ChangeNotifier {
  static final DownloadManager I = DownloadManager._();
  DownloadManager._();

  final Map<String, Set<int>> _done = {};
  final Map<String, double> _progress = {};
  final List<_Job> _queue = [];
  bool _running = false;
  bool _loaded = false;
  bool failedSome = false;

  String _k(String qari, int n) => '$qari|$n';

  Future<void> load() async {
    if (_loaded) return;
    final pr = await SharedPreferences.getInstance();
    for (final k in pr.getKeys().where((k) => k.startsWith('dl_'))) {
      _done[k.substring(3)] = (pr.getStringList(k) ?? []).map(int.parse).toSet();
    }
    _loaded = true;
    notifyListeners();
  }

  bool get busy => _running || _queue.isNotEmpty;
  double? progressOf(String qari, int n) => _progress[_k(qari, n)];
  bool isDone(String qari, int n) => _done[qari]?.contains(n) ?? false;
  bool isQueued(String qari, int n) => _queue.any((j) => j.qari == qari && j.surah.n == n);

  Future<void> _save(String qari) async {
    final pr = await SharedPreferences.getInstance();
    await pr.setStringList('dl_$qari', (_done[qari] ?? {}).map((e) => '$e').toList());
  }

  void enqueue(String qari, Surah s) {
    if (isDone(qari, s.n) || _progress.containsKey(_k(qari, s.n)) || isQueued(qari, s.n)) return;
    _queue.add(_Job(qari, s));
    _progress[_k(qari, s.n)] = 0;
    failedSome = false;
    notifyListeners();
    _run();
  }

  Future<void> _run() async {
    if (_running) return;
    _running = true;
    await BgService.start('Menyiapkan unduhan...');
    try {
      while (_queue.isNotEmpty) {
        final job = _queue.removeAt(0);
        await _downloadSurah(job);
      }
    } finally {
      _running = false;
      await BgService.stop();
      notifyListeners();
    }
  }

  Future<void> _downloadSurah(_Job job) async {
    final s = job.surah;
    final key = _k(job.qari, s.n);
    final client = http.Client();
    int ok = 0, finished = 0, next = 0;
    final total = s.ayat.length;

    Future<void> one(Ayah a) async {
      final f = await localAudio(job.qari, a.g);
      if (await f.exists() && await f.length() > 0) {
        ok++;
        return;
      }
      for (final u in audioUrls(job.qari, a)) {
        if (!_progress.containsKey(key)) return;
        try {
          final r = await client.get(Uri.parse(u)).timeout(const Duration(seconds: 25));
          if (r.statusCode == 200 && r.bodyBytes.isNotEmpty) {
            await f.parent.create(recursive: true);
            await f.writeAsBytes(r.bodyBytes);
            ok++;
            return;
          }
        } catch (_) {}
      }
    }

    // 6 unduhan sekaligus agar jauh lebih cepat
    Future<void> worker() async {
      while (_progress.containsKey(key)) {
        final i = next++;
        if (i >= total) return;
        await one(s.ayat[i]);
        finished++;
        if (_progress.containsKey(key)) _progress[key] = finished / total;
        notifyListeners();
        if (finished % 6 == 0 || finished == total) {
          BgService.update('${s.en}: ${(finished * 100 / total).round()}%'
              '${_queue.isEmpty ? '' : ' (antre ${_queue.length} surah)'}');
        }
      }
    }

    try {
      await Future.wait([for (int w = 0; w < 6; w++) worker()]);
    } finally {
      client.close();
    }
    if (!_progress.containsKey(key)) return; // dibatalkan
    _progress.remove(key);
    if (ok == total) {
      (_done[job.qari] ??= {}).add(s.n);
      await _save(job.qari);
    } else {
      failedSome = true;
    }
    notifyListeners();
  }

  /// Batalkan semua unduhan yang sedang/antre.
  void cancelAll() {
    _queue.clear();
    _progress.clear();
    notifyListeners();
  }

  Future<void> deleteSurah(String qari, Surah s) async {
    for (final a in s.ayat) {
      final f = await localAudio(qari, a.g);
      if (await f.exists()) await f.delete();
    }
    _done[qari]?.remove(s.n);
    await _save(qari);
    notifyListeners();
  }

  Future<void> forgetQari(String qari) async {
    _done.remove(qari);
    final pr = await SharedPreferences.getInstance();
    await pr.remove('dl_$qari');
    notifyListeners();
  }

  Future<void> forgetAll() async {
    _done.clear();
    final pr = await SharedPreferences.getInstance();
    for (final k in pr.getKeys().where((k) => k.startsWith('dl_')).toList()) {
      await pr.remove(k);
    }
    notifyListeners();
  }
}
