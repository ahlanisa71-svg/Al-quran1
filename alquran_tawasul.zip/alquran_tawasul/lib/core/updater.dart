import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'settings.dart';

/// Repositori GitHub tempat APK terbaru dirilis (Releases).
const String updateRepo = 'ahlanisa71-svg/Al-Quran1';

class UpdateInfo {
  final int number;
  final String name;
  final String notes;
  final String apkUrl;
  final int size;
  UpdateInfo(this.number, this.name, this.notes, this.apkUrl, this.size);
}

/// Memeriksa, mengunduh, dan memasang pembaruan APK dari GitHub Releases.
class Updater extends ChangeNotifier {
  static final Updater I = Updater._();
  Updater._();

  static const _ch = MethodChannel('alquran/update');

  String currentName = '';
  int currentNumber = 0;
  UpdateInfo? available;
  bool checking = false;
  bool checkedOnce = false;
  String? message; // pesan status / galat untuk ditampilkan
  double? progress; // 0..1 saat mengunduh
  String? downloadedPath;

  bool get downloading => progress != null;

  /// Nomor urut versi = bagian terakhir versi, mis. 1.0.12 → 12.
  int _numOf(String v) => int.tryParse(v.replaceAll(RegExp(r'^[^0-9]*'), '').split('+').first.split('.').last) ?? 0;

  Future<void> loadCurrent() async {
    final i = await PackageInfo.fromPlatform();
    currentName = i.version;
    currentNumber = _numOf(i.version);
    notifyListeners();
  }

  Future<String> _abi() async {
    try {
      return await _ch.invokeMethod<String>('abi') ?? '';
    } catch (_) {
      return '';
    }
  }

  Future<void> check({bool silent = false}) async {
    if (checking || downloading) return;
    checking = true;
    if (!silent) message = null;
    notifyListeners();
    try {
      await loadCurrent();
      final r = await http
          .get(Uri.parse('https://api.github.com/repos/$updateRepo/releases/latest'),
              headers: {'Accept': 'application/vnd.github+json'})
          .timeout(const Duration(seconds: 12));
      if (r.statusCode == 404) {
        if (!silent) message = 'Belum ada rilis di GitHub. Pastikan repositori bersifat publik dan build sudah selesai.';
      } else if (r.statusCode != 200) {
        if (!silent) message = 'Gagal memeriksa pembaruan (kode ${r.statusCode}). Coba lagi nanti.';
      } else {
        final j = jsonDecode(r.body) as Map<String, dynamic>;
        final tag = (j['tag_name'] ?? '') as String;
        final n = _numOf(tag);
        final assets = ((j['assets'] ?? []) as List).cast<Map<String, dynamic>>().where((a) => ('${a['name']}').endsWith('.apk')).toList();
        if (n > currentNumber && assets.isNotEmpty) {
          final abi = await _abi();
          final pick = assets.firstWhere((a) => abi.isNotEmpty && '${a['name']}'.contains(abi), orElse: () => assets.first);
          available = UpdateInfo(n, tag.replaceFirst(RegExp(r'^[vV]'), ''), (j['body'] ?? '') as String,
              pick['browser_download_url'] as String, (pick['size'] ?? 0) as int);
          downloadedPath = null;
          if (silent) {
            messengerKey.currentState
              ?..hideCurrentSnackBar()
              ..showSnackBar(SnackBar(
                  content: Text('Versi baru ${available!.name} tersedia. Buka Pengaturan → Pembaruan Aplikasi.')));
          }
        } else {
          available = null;
          if (!silent) message = 'Aplikasi Anda sudah versi terbaru.';
        }
      }
      checkedOnce = true;
    } catch (_) {
      if (!silent) message = 'Tidak bisa terhubung ke GitHub. Periksa koneksi internet.';
    } finally {
      checking = false;
      notifyListeners();
    }
  }

  /// Unduh APK lalu buka pemasang Android. Mengembalikan pesan status.
  Future<void> downloadAndInstall() async {
    final info = available;
    if (info == null || downloading) return;
    message = null;
    try {
      if (downloadedPath == null || !await File(downloadedPath!).exists()) {
        progress = 0;
        notifyListeners();
        final dir = Directory('${(await getTemporaryDirectory()).path}/update');
        if (await dir.exists()) await dir.delete(recursive: true);
        await dir.create(recursive: true);
        final file = File('${dir.path}/alquran-tawasul.apk');
        final client = http.Client();
        try {
          final resp = await client.send(http.Request('GET', Uri.parse(info.apkUrl))).timeout(const Duration(seconds: 30));
          if (resp.statusCode != 200) throw Exception('http ${resp.statusCode}');
          final total = resp.contentLength ?? info.size;
          int got = 0;
          final sink = file.openWrite();
          await for (final chunk in resp.stream) {
            sink.add(chunk);
            got += chunk.length;
            if (total > 0) {
              progress = (got / total).clamp(0.0, 1.0).toDouble();
              notifyListeners();
            }
          }
          await sink.flush();
          await sink.close();
        } finally {
          client.close();
        }
        downloadedPath = file.path;
      }
      progress = null;
      notifyListeners();
      final res = await _ch.invokeMethod<String>('install', {'path': downloadedPath});
      if (res == 'need_permission') {
        message = 'Izinkan "Pasang aplikasi tidak dikenal" untuk Al Quran dan Tawasul, lalu kembali ke sini dan tekan "Pasang sekarang".';
      }
    } catch (e) {
      progress = null;
      downloadedPath = null;
      message = 'Gagal mengunduh pembaruan. Periksa koneksi lalu coba lagi.';
    }
    notifyListeners();
  }

  /// Pasang ulang file yang sudah diunduh (mis. setelah memberi izin).
  Future<void> installAgain() => downloadAndInstall();
}
