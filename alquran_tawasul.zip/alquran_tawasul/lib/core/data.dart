import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class Ayah {
  final int sn, n, g, j, p;
  final String a, s, t, i, k;
  Ayah(this.sn, Map<String, dynamic> m)
      : n = m['n'], g = m['g'], j = m['j'], p = m['p'],
        a = m['a'], s = m['s'], t = m['t'], i = m['i'], k = m['k'];
}

class Surah {
  final int n;
  final String ar, en, id, type;
  final List<Ayah> ayat;
  Surah(this.n, this.ar, this.en, this.id, this.type, this.ayat);
  String get arPlain => plainAr(ar);
}

/// Hapus harakat dan kata "surah" dari nama Arab.
String plainAr(String s) => s
    .replaceAll(RegExp('[\u064B-\u065F\u0670\u06D6-\u06ED]'), '')
    .replaceAll('\u0671', '\u0627')
    .replaceAll('سورة', '')
    .trim();

List<dynamic> _decode(String raw) => jsonDecode(raw) as List<dynamic>;

class QuranData {
  static List<Surah> surahs = [];
  static List<Ayah> all = [];
  static Map<int, List<Ayah>> pages = {};

  static Future<void> load() async {
    final raw = await rootBundle.loadString('assets/quran.json');
    final list = await compute(_decode, raw);
    surahs = [];
    all = [];
    for (final m in list) {
      final sn = m['n'] as int;
      final ayat = (m['ayat'] as List).map((e) => Ayah(sn, e as Map<String, dynamic>)).toList();
      surahs.add(Surah(sn, m['ar'], m['en'], m['id'], m['type'], ayat));
      all.addAll(ayat);
    }
    pages = {};
    for (final a in all) {
      pages.putIfAbsent(a.p, () => []).add(a);
    }
  }

  static Surah surah(int n) => surahs[n - 1];
  static Ayah byGlobal(int g) => all[g - 1];
  static List<Ayah> juz(int j) => all.where((a) => a.j == j).toList();
  static Ayah juzStart(int j) => all.firstWhere((a) => a.j == j);
}

const bismillah = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ';

String arNum(int n) {
  const d = '٠١٢٣٤٥٦٧٨٩';
  return '$n'.split('').map((c) => d[int.parse(c)]).join();
}
