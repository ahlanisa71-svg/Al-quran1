import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'data.dart';
import 'settings.dart';

String _pad(int n, int w) => n.toString().padLeft(w, '0');

/// Daftar alamat yang dicoba berurutan (kualitas berbeda tidak tersedia untuk semua qari).
/// Pola URL buatan pengguna: {global} {surah} {surah3} {ayah} {ayah3}
List<String> audioUrls(String qari, Ayah a) {
  final custom = settings.customQaris.where((q) => q.id == qari);
  if (custom.isNotEmpty) {
    return [
      custom.first.template!
          .replaceAll('{global}', '${a.g}')
          .replaceAll('{surah3}', _pad(a.sn, 3))
          .replaceAll('{surah}', '${a.sn}')
          .replaceAll('{ayah3}', _pad(a.n, 3))
          .replaceAll('{ayah}', '${a.n}')
    ];
  }
  return [for (final br in const ['64', '128', '192', '32']) 'https://cdn.islamic.network/quran/audio/$br/$qari/${a.g}.mp3'];
}

Future<File> localAudio(String qari, int g) async {
  final d = await getApplicationDocumentsDirectory();
  return File('${d.path}/audio/$qari/$g.mp3');
}

class AudioService {
  static final AudioService I = AudioService._();
  final AudioPlayer _player = AudioPlayer();
  final ValueNotifier<int?> current = ValueNotifier(null);
  List<Ayah> _queue = [];
  int _idx = 0;

  AudioService._() {
    _player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.completed) _next();
    });
  }

  Future<void> toggle(List<Ayah> q, int idx) async {
    if (current.value == q[idx].g) {
      await stop();
    } else {
      _queue = q;
      _idx = idx;
      await _playCurrent();
    }
  }

  Future<void> _playCurrent() async {
    final a = _queue[_idx];
    current.value = a.g;
    try {
      final f = await localAudio(settings.qari, a.g);
      if (await f.exists()) {
        await _player.setFilePath(f.path);
      } else {
        Object? lastErr;
        bool ok = false;
        for (final u in audioUrls(settings.qari, a)) {
          try {
            await _player.setUrl(u);
            ok = true;
            break;
          } catch (e) {
            lastErr = e;
          }
        }
        if (!ok) throw lastErr ?? Exception('audio');
      }
      _player.play();
    } catch (_) {
      current.value = null;
      messengerKey.currentState
        ?..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(
            content: Text('Audio tidak bisa dimuat. Periksa internet, atau pilih qari lain di Pengaturan → Qari.')));
    }
  }

  void _next() {
    if (_idx + 1 < _queue.length) {
      _idx++;
      _playCurrent();
    } else {
      current.value = null;
    }
  }

  Future<void> stop() async {
    current.value = null;
    try {
      await _player.stop();
    } catch (_) {}
  }
}
