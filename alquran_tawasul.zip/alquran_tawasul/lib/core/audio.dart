import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:path_provider/path_provider.dart';
import 'data.dart';
import 'settings.dart';

String _pad(int n, int w) => n.toString().padLeft(w, '0');

/// Daftar alamat yang dicoba berurutan (kualitas berbeda tidak tersedia untuk semua qari).
/// Pola URL buatan pengguna: {global} {surah} {surah3} {ayah} {ayah3}
List<String> audioUrls(String qari, Ayah a, {String? prefer}) {
  final custom = settings.customQaris.where((q) => q.id == qari);
  if (custom.isNotEmpty) {
    return [
      custom.first.template!
          .replaceAll('{global}', '${a.g}')
          .replaceAll('{surah3}', _pad(a.sn, 3))
          .replaceAll('{surah}', '${a.sn}')
          .replaceAll('{ayah3}', _pad(a.n, 3))
          .replaceAll('{ayah}', '${a.n}')
    ];
  }
  final order = <String>[if (prefer != null) prefer, ...const ['64', '128', '192', '32']];
  final seen = <String>{};
  return [for (final br in order) if (seen.add(br)) 'https://cdn.islamic.network/quran/audio/$br/$qari/${a.g}.mp3'];
}

Future<File> localAudio(String qari, int g) async {
  final d = await getApplicationDocumentsDirectory();
  return File('${d.path}/audio/$qari/$g.mp3');
}

class AudioService {
  static final AudioService I = AudioService._();
  final AudioPlayer _player = AudioPlayer();
  final ValueNotifier<int?> current = ValueNotifier(null);
  final ValueNotifier<bool> playing = ValueNotifier(false);
  List<Ayah> _queue = [];
  int _idx = 0;
  String _qid = '';
  /// Qari yang sedang diputar (bisa berbeda dari qari terpilih saat memutar surat unduhan qari lain).
  String? qariNow;

  AudioService._() {
    _player.playerStateStream.listen((s) {
      playing.value = s.playing && s.processingState != ProcessingState.completed && s.processingState != ProcessingState.idle;
      if (s.processingState == ProcessingState.completed) _next();
    });
  }

  Future<void> toggle(List<Ayah> q, int idx, {String? qari}) async {
    final qid = qari ?? settings.qari;
    if (current.value == q[idx].g && qariNow == qid) {
      await stop();
    } else {
      _queue = q;
      _idx = idx;
      _qid = qid;
      await _playCurrent();
    }
  }

  Future<void> _playCurrent() async {
    final a = _queue[_idx];
    final qid = _qid.isEmpty ? settings.qari : _qid;
    final qi = settings.allQaris.firstWhere((q) => q.id == qid, orElse: () => settings.qariInfo);
    qariNow = qid;
    current.value = a.g;
    final tag = MediaItem(
      id: '${qid}_${a.g}',
      title: '${QuranData.surah(a.sn).en} : ${a.n}',
      album: 'Al Quran dan Tawasul',
      artist: qi.name,
    );
    try {
      final f = await localAudio(qid, a.g);
      if (await f.exists()) {
        await _player.setAudioSource(AudioSource.uri(Uri.file(f.path), tag: tag));
      } else {
        Object? lastErr;
        bool ok = false;
        for (final u in audioUrls(qid, a)) {
          try {
            await _player.setAudioSource(AudioSource.uri(Uri.parse(u), tag: tag));
            ok = true;
            break;
          } catch (e) {
            lastErr = e;
          }
        }
        if (!ok) throw lastErr ?? Exception('audio');
      }
      _player.play();
    } catch (_) {
      current.value = null;
      messengerKey.currentState
        ?..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(
            content: Text('Audio tidak bisa dimuat. Periksa internet, atau pilih qari lain di Pengaturan → Qari.')));
    }
  }

  void _next() {
    if (_idx + 1 < _queue.length) {
      _idx++;
      _playCurrent();
    } else {
      current.value = null;
    }
  }

  Future<void> stop() async {
    qariNow = null;
    current.value = null;
    try {
      await _player.stop();
    } catch (_) {}
  }
}
