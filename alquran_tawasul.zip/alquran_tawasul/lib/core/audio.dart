import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'data.dart';
import 'settings.dart';

String audioUrl(String qari, int g) => 'https://cdn.islamic.network/quran/audio/64/$qari/$g.mp3';

Future<File> localAudio(String qari, int g) async {
  final d = await getApplicationDocumentsDirectory();
  return File('${d.path}/audio/$qari/$g.mp3');
}

class AudioService {
  static final AudioService I = AudioService._();
  final AudioPlayer _player = AudioPlayer();
  final ValueNotifier<int?> current = ValueNotifier(null);
  List<Ayah> _queue = [];
  int _idx = 0;

  AudioService._() {
    _player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.completed) _next();
    });
  }

  Future<void> toggle(List<Ayah> q, int idx) async {
    if (current.value == q[idx].g) {
      await stop();
    } else {
      _queue = q;
      _idx = idx;
      await _playCurrent();
    }
  }

  Future<void> _playCurrent() async {
    final a = _queue[_idx];
    current.value = a.g;
    try {
      final f = await localAudio(settings.qari, a.g);
      if (await f.exists()) {
        await _player.setFilePath(f.path);
      } else {
        await _player.setUrl(audioUrl(settings.qari, a.g));
      }
      _player.play();
    } catch (_) {
      current.value = null;
    }
  }

  void _next() {
    if (_idx + 1 < _queue.length) {
      _idx++;
      _playCurrent();
    } else {
      current.value = null;
    }
  }

  Future<void> stop() async {
    current.value = null;
    try {
      await _player.stop();
    } catch (_) {}
  }
}
