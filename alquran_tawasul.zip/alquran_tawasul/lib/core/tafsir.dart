import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

List<String> _parseTafsir(Uint8List bytes) {
  final data = jsonDecode(utf8.decode(bytes))['data']['surahs'] as List;
  final out = <String>[];
  for (final s in data) {
    for (final a in (s['ayahs'] as List)) {
      out.add((a['text'] ?? '').toString());
    }
  }
  return out;
}

/// Tafsir Jalalayn (Bahasa Indonesia): tidak ikut di dalam APK, diunduh sekali lalu disimpan di HP.
class Tafsir extends ChangeNotifier {
  static final Tafsir I = Tafsir._();
  Tafsir._();

  List<String>? _t;
  bool busy = false;
  double? progress; // 0..1, null = belum diketahui
  String? error;

  bool get ready => _t != null;

  String text(int g) => (_t != null && g >= 1 && g <= _t!.length) ? _t![g - 1] : '';

  Future<File> _file() async => File('${(await getApplicationDocumentsDirectory()).path}/tafsir_jalalayn.json');

  Future<void> load() async {
    try {
      final f = await _file();
      if (await f.exists()) {
        final l = jsonDecode(await f.readAsString()) as List;
        if (l.length == 6236) _t = l.map((e) => e.toString()).toList();
      }
    } catch (_) {}
    notifyListeners();
  }

  Future<bool> download() async {
    if (busy) return false;
    busy = true;
    progress = null;
    error = null;
    notifyListeners();
    final client = http.Client();
    try {
      final resp = await client
          .send(http.Request('GET', Uri.parse('https://api.alquran.cloud/v1/quran/id.jalalayn')))
          .timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) throw 'Server menjawab ${resp.statusCode}';
      final total = resp.contentLength ?? 0;
      final buf = BytesBuilder(copy: false);
      var got = 0;
      await for (final c in resp.stream) {
        buf.add(c);
        got += c.length;
        if (total > 0) {
          progress = (got / total).clamp(0.0, 1.0);
          notifyListeners();
        }
      }
      final list = await compute(_parseTafsir, buf.takeBytes());
      if (list.length != 6236) throw 'Data tafsir tidak lengkap';
      await (await _file()).writeAsString(jsonEncode(list));
      _t = list;
      return true;
    } catch (e) {
      error = 'Gagal mengunduh tafsir. Periksa koneksi internet lalu coba lagi.';
      return false;
    } finally {
      client.close();
      busy = false;
      progress = null;
      notifyListeners();
    }
  }

  Future<void> remove() async {
    try {
      final f = await _file();
      if (await f.exists()) await f.delete();
    } catch (_) {}
    _t = null;
    notifyListeners();
  }
}
