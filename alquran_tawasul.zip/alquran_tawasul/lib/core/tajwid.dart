import 'package:flutter/material.dart';

const tajwidColors = <String, Color>{
  'qalqalah': Color(0xFF3B9CFF),
  'ghunnah': Color(0xFF22C55E),
  'mad': Color(0xFFEF4444),
  'ikhfa': Color(0xFFF59E0B),
  'idgham': Color(0xFFA855F7),
  'iqlab': Color(0xFFEC4899),
};

const tajwidInfo = <String, List<String>>{
  'mad': ['Mad', 'Bacaan dipanjangkan (tanda mad / maddah).'],
  'ghunnah': ['Ghunnah', 'Nun atau Mim bertasydid, dengung 2 harakat.'],
  'qalqalah': ['Qalqalah', 'Huruf ق ط ب ج د yang mati (sukun), dipantulkan.'],
  'ikhfa': ['Ikhfa', 'Nun mati / tanwin bertemu huruf ikhfa, dibaca samar.'],
  'idgham': ['Idgham', 'Nun mati / tanwin bertemu ي ن م و, dilebur.'],
  'iqlab': ['Iqlab', 'Nun mati / tanwin bertemu ب, diganti bunyi mim.'],
};

bool _isMark(int c) => (c >= 0x064B && c <= 0x065F) || c == 0x0670 || (c >= 0x06D6 && c <= 0x06ED);

/// Pewarnaan tajwid otomatis berbasis aturan (perkiraan, bukan pengganti mushaf tajwid).
List<InlineSpan> tajwidSpans(String text, TextStyle base) {
  final clusters = <String>[];
  final buf = StringBuffer();
  for (final r in text.runes) {
    if (_isMark(r) && buf.isNotEmpty) {
      buf.writeCharCode(r);
    } else {
      if (buf.isNotEmpty) clusters.add(buf.toString());
      buf.clear();
      buf.writeCharCode(r);
    }
  }
  if (buf.isNotEmpty) clusters.add(buf.toString());

  String baseOf(String c) => String.fromCharCode(c.runes.first);
  bool has(String c, int m) => c.runes.contains(m);
  bool sukun(String c) => has(c, 0x0652) || has(c, 0x06E1);
  const ikhfaL = 'تثجدذزسشصضطظفقك';
  const idghamL = 'ينمو';

  String? nextBase(int i) {
    for (int j = i + 1; j < clusters.length; j++) {
      final b = baseOf(clusters[j]);
      if (b == ' ' || _isMark(b.runes.first)) continue;
      return b;
    }
    return null;
  }

  String? rule(int i) {
    final c = clusters[i];
    final b = baseOf(c);
    if (has(c, 0x0653)) return 'mad';
    if ((b == 'ن' || b == 'م') && has(c, 0x0651)) return 'ghunnah';
    if ('قطبجد'.contains(b) && sukun(c)) return 'qalqalah';
    final tanwin = has(c, 0x064B) || has(c, 0x064C) || has(c, 0x064D);
    if (tanwin || (b == 'ن' && sukun(c))) {
      if (has(c, 0x06E2) || has(c, 0x06ED)) return 'iqlab';
      final n = nextBase(i);
      if (n == null) return null;
      if (n == 'ب') return 'iqlab';
      if (idghamL.contains(n)) return 'idgham';
      if (ikhfaL.contains(n)) return 'ikhfa';
    }
    return null;
  }

  final spans = <InlineSpan>[];
  String? cur;
  final sb = StringBuffer();
  void flush() {
    if (sb.isEmpty) return;
    spans.add(TextSpan(text: sb.toString(), style: cur == null ? base : base.copyWith(color: tajwidColors[cur])));
    sb.clear();
  }

  for (int i = 0; i < clusters.length; i++) {
    final r = rule(i);
    if (r != cur) {
      flush();
      cur = r;
    }
    sb.write(clusters[i]);
  }
  flush();
  return spans;
}
