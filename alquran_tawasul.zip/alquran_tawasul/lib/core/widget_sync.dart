import 'dart:async';
import 'package:flutter/services.dart';
import 'audio.dart';
import 'data.dart';
import 'settings.dart';

/// Mengirim data ke widget layar utama Android (ayat hari ini, lanjutkan membaca, target khatam).
/// Jembatan native ada di MainActivity (dibuat oleh tools/patch_android.py). Gagal diam-diam bila tidak tersedia.
class WidgetSync {
  static const _ch = MethodChannel('alquran/widget');
  static Timer? _t;
  static bool _started = false;

  static void start() {
    if (_started) return;
    _started = true;
    settings.addListener(schedule);
    AudioService.I.current.addListener(pushPlayerSoon);
    AudioService.I.playing.addListener(pushPlayerSoon);
    schedule();
  }

  static void schedule() {
    _t?.cancel();
    _t = Timer(const Duration(seconds: 2), push);
  }

  static Timer? _pt;
  static void pushPlayerSoon() {
    _pt?.cancel();
    _pt = Timer(const Duration(milliseconds: 350), pushPlayer);
  }

  static Future<void> pushPlayer() async {
    try {
      final g = AudioService.I.current.value;
      String title = '', sub = '';
      if (g != null) {
        final a = QuranData.byGlobal(g);
        title = '${QuranData.surah(a.sn).en} • ayat ${a.n}';
        sub = settings.qariInfo.name;
      }
      await _ch.invokeMethod('update', <String, Object>{
        'play_active': g == null ? 0 : 1,
        'play_playing': AudioService.I.playing.value ? 1 : 0,
        'play_title': title,
        'play_sub': sub,
      });
    } catch (_) {}
  }

  static Future<void> push() async {
    try {
      if (QuranData.all.isEmpty) return;
      final now = DateTime.now();
      final doy = now.difference(DateTime(now.year)).inDays;
      final daily = QuranData.byGlobal((doy * 37) % QuranData.all.length + 1);
      final dailySurah = QuranData.surah(daily.sn);

      String lastTitle = 'Belum ada bacaan';
      String lastSub = 'Buka Al-Quran untuk mulai membaca';
      if (settings.lastRead > 0) {
        final l = QuranData.byGlobal(settings.lastRead);
        lastTitle = '${QuranData.surah(l.sn).en} • ayat ${l.n}';
        lastSub = 'Juz ${l.j} • Halaman ${l.p}';
      }

      final total = QuranData.all.length;
      final read = settings.readSet.length;
      final pct = total == 0 ? 0 : (read * 100 / total).round();

      await _ch.invokeMethod('update', <String, Object>{
        'daily_ar': daily.a,
        'daily_tr': daily.i,
        'daily_ref': 'QS ${dailySurah.en}: ${daily.n}',
        'last_title': lastTitle,
        'last_sub': lastSub,
        'khatam_pct': '$pct%',
        'khatam_sub': '$read dari $total ayat dibaca',
        'khatam_progress': pct,
      });
    } catch (_) {}
  }
}
