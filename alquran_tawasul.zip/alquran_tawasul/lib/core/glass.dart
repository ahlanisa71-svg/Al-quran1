import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'fonts.dart';
import 'settings.dart';

const navPad = 112.0;

Widget sb(Widget Function(BuildContext, AppPalette) f) =>
    ListenableBuilder(listenable: settings, builder: (c, _) => f(c, settings.pal));

Route<T> smoothRoute<T>(Widget page) => PageRouteBuilder<T>(
      transitionDuration: const Duration(milliseconds: 420),
      reverseTransitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, anim, sec, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic);
        return FadeTransition(
          opacity: curved,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0.12, 0), end: Offset.zero).animate(curved),
            child: child,
          ),
        );
      },
    );

class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  /// Latar datar satu warna + dua lingkaran lembut (kiri atas, kanan bawah).
  @override
  Widget build(BuildContext context) => sb((c, p) => ColoredBox(
        color: p.bg[1],
        child: Stack(children: [
          Positioned(top: -90, left: -110, child: _Blob(360, p.accent.withValues(alpha: p.dark ? 0.15 : 0.14))),
          Positioned(bottom: -130, right: -120, child: _Blob(400, p.blob.withValues(alpha: p.dark ? 0.20 : 0.18))),
          Positioned.fill(child: child),
        ]),
      ));
}

class _Blob extends StatelessWidget {
  final double size;
  final Color color;
  const _Blob(this.size, this.color);
  @override
  Widget build(BuildContext context) =>
      IgnorePointer(child: Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color)));
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding, margin;
  final VoidCallback? onTap, onLongPress;
  final double radius;
  final bool blur;
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin = const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
    this.onTap,
    this.onLongPress,
    this.radius = 24,
    this.blur = true,
  });

  @override
  Widget build(BuildContext context) => sb((c, p) {
        Widget inner = Material(
          color: p.glass,
          child: InkWell(
            onTap: onTap,
            onLongPress: onLongPress,
            child: Container(
              padding: padding,
              decoration: BoxDecoration(
                  border: Border.all(color: p.glassBorder), borderRadius: BorderRadius.circular(radius)),
              child: child,
            ),
          ),
        );
        if (blur) inner = BackdropFilter(filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20), child: inner);
        return Padding(
          padding: margin,
          child: ClipRRect(borderRadius: BorderRadius.circular(radius), child: inner),
        );
      });
}

class GlassScaffold extends StatelessWidget {
  final String title;
  final Widget body;
  final List<Widget> actions;
  final Widget? floating;
  const GlassScaffold({super.key, required this.title, required this.body, this.actions = const [], this.floating});

  @override
  Widget build(BuildContext context) => sb((c, p) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: p.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
        child: AppBackground(
          child: Scaffold(
            backgroundColor: Colors.transparent,
            floatingActionButton: floating,
            floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              scrolledUnderElevation: 0,
              foregroundColor: p.text,
              centerTitle: false,
              titleSpacing: 0,
              leading: Padding(
                padding: const EdgeInsets.all(8),
                child: ClipOval(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                    child: Material(
                      color: p.glass,
                      child: InkWell(
                        onTap: () => Navigator.maybePop(context),
                        child: Icon(Icons.arrow_back_rounded, color: p.text, size: 22),
                      ),
                    ),
                  ),
                ),
              ),
              title: Text(title, style: uiStyle(19, p.text, w: FontWeight.w700)),
              actions: actions,
            ),
            body: body,
          ),
        ),
      ));
}

class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel(this.text, {super.key});
  @override
  Widget build(BuildContext context) => sb((c, p) => Padding(
        padding: const EdgeInsets.fromLTRB(28, 4, 24, 6),
        child: Text(text, style: uiStyle(12.5, p.sub, w: FontWeight.w600)),
      ));
}

/// Satu baris menu di dalam GlassCard (gaya referensi: judul, nilai opsional, panah).
class MenuRow extends StatelessWidget {
  final String title;
  final String? value, subtitle;
  final VoidCallback? onTap;
  final Widget? trailing;
  final bool divider;
  const MenuRow(this.title, {super.key, this.value, this.subtitle, this.onTap, this.trailing, this.divider = true});

  @override
  Widget build(BuildContext context) => sb((c, p) => Column(children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: uiStyle(15, p.text, w: FontWeight.w600)),
                  if (subtitle != null) Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Text(subtitle!, style: uiStyle(12.5, p.sub)),
                  ),
                ]),
              ),
              if (value != null)
                Flexible(
                  child: Text(value!, overflow: TextOverflow.ellipsis, style: uiStyle(14, p.sub, w: FontWeight.w600)),
                ),
              if (trailing != null) trailing!,
              if (trailing == null && onTap != null) Icon(Icons.chevron_right_rounded, color: p.sub),
            ]),
          ),
        ),
        if (divider) Divider(height: 1, color: p.glassBorder),
      ]));
}

class GlassSwitch extends StatelessWidget {
  final bool value;
  final ValueChanged<bool> onChanged;
  const GlassSwitch(this.value, this.onChanged, {super.key});
  @override
  Widget build(BuildContext context) => sb((c, p) => Switch(
        value: value,
        onChanged: onChanged,
        activeThumbColor: Colors.white,
        activeTrackColor: p.accent,
        inactiveThumbColor: Colors.white,
        inactiveTrackColor: p.sub.withValues(alpha: 0.35),
        trackOutlineColor: WidgetStatePropertyAll(Colors.transparent),
      ));
}

Color goldOf(AppPalette p) => p.dark ? const Color(0xFFD9B45A) : const Color(0xFFA8802E);

/// Bar hiasan mushaf (header halaman, banner nama surah).
class OrnamentBarPainter extends CustomPainter {
  final Color color;
  final bool bold;
  OrnamentBarPainter(this.color, {this.bold = false});

  @override
  void paint(Canvas canvas, Size size) {
    final h = size.height, w = size.width;
    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..color = color
      ..strokeWidth = bold ? 1.8 : 1.2;
    final thin = Paint()
      ..style = PaintingStyle.stroke
      ..color = color.withValues(alpha: 0.55)
      ..strokeWidth = 0.8;
    final fill = Paint()..color = color.withValues(alpha: bold ? 0.16 : 0.08);
    final r = RRect.fromRectAndRadius(Rect.fromLTWH(h * 0.6, 0, w - h * 1.2, h), Radius.circular(h * 0.28));
    canvas.drawRRect(r, fill);
    canvas.drawRRect(r, stroke);
    canvas.drawRRect(r.deflate(h * 0.13), thin);
    for (final left in [true, false]) {
      final cx = left ? h * 0.55 : w - h * 0.55;
      final d = Path()
        ..moveTo(cx - h * 0.55, h / 2)
        ..lineTo(cx, 0)
        ..lineTo(cx + h * 0.55, h / 2)
        ..lineTo(cx, h)
        ..close();
      canvas.drawPath(d, Paint()..color = color.withValues(alpha: 0.18));
      canvas.drawPath(d, stroke);
      canvas.drawCircle(Offset(cx, h / 2), h * 0.14, Paint()..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant OrnamentBarPainter o) => o.color != color || o.bold != bold;
}

/// Lencana bintang 8 sudut untuk nomor surah.
class StarBadgePainter extends CustomPainter {
  final Color color;
  StarBadgePainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final R = math.min(size.width, size.height) / 2 - 1.5;
    final r = R * 0.80;
    final path = Path();
    for (int i = 0; i < 16; i++) {
      final a = -math.pi / 2 + i * math.pi / 8;
      final rad = i.isEven ? R : r;
      final pt = Offset(c.dx + rad * math.cos(a), c.dy + rad * math.sin(a));
      i == 0 ? path.moveTo(pt.dx, pt.dy) : path.lineTo(pt.dx, pt.dy);
    }
    path.close();
    canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.3
          ..strokeJoin = StrokeJoin.round
          ..color = color);
  }

  @override
  bool shouldRepaint(covariant StarBadgePainter o) => o.color != color;
}

/// Penanda akhir ayat (lingkaran ganda).
class AyahMarkPainter extends CustomPainter {
  final Color color;
  AyahMarkPainter(this.color);
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final R = size.width / 2 - 1;
    canvas.drawCircle(
        c,
        R,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.3
          ..color = color);
    canvas.drawCircle(
        c,
        R * 0.80,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.7
          ..color = color.withValues(alpha: 0.6));
    for (int i = 0; i < 12; i++) {
      final a = i * math.pi / 6;
      canvas.drawCircle(Offset(c.dx + R * math.cos(a), c.dy + R * math.sin(a)), 0.9, Paint()..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant AyahMarkPainter o) => o.color != color;
}
