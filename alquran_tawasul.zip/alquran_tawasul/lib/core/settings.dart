import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppPalette {
  final String name;
  final bool dark;
  final List<Color> bg;
  final Color accent, blob, text, sub, glass, glassBorder;
  const AppPalette(this.name, this.dark, this.bg, this.accent, this.blob, this.text, this.sub, this.glass, this.glassBorder);
}

AppPalette _dark(String n, List<int> bg, int accent, int blob) => AppPalette(n, true,
    bg.map((e) => Color(e)).toList(), Color(accent), Color(blob), Colors.white, const Color(0xB3FFFFFF),
    Colors.white.withValues(alpha: 0.09), Colors.white.withValues(alpha: 0.18));

final palettes = <AppPalette>[
  _dark('Nila', const [0xFF1B2A8A, 0xFF0F1A5C, 0xFF060B2B], 0xFF7CF2C0, 0xFF6366F1),
  AppPalette('Putih', false, const [Color(0xFFFFFFFF), Color(0xFFF7F8F8), Color(0xFFECEFEE)], const Color(0xFF12A36B),
      const Color(0xFF7DD3B0), const Color(0xFF14211C), const Color(0xFF5B6B64), Colors.black.withValues(alpha: 0.045), Colors.black.withValues(alpha: 0.10)),
  _dark('Gelap', const [0xFF11141F, 0xFF11141F, 0xFF11141F], 0xFF3DDC97, 0xFF14B8A6),
  _dark('Cokelat', const [0xFF5E4130, 0xFF3E2B20, 0xFF22160F], 0xFF7EE0A8, 0xFFD97706),
  _dark('Zamrud', const [0xFF0F5A45, 0xFF0A3B2E, 0xFF04170F], 0xFFF2D675, 0xFF10B981),
  _dark('Anggur', const [0xFF4C2A85, 0xFF2E1A55, 0xFF140B2B], 0xFFE0C3FF, 0xFFA855F7),
  _dark('Marun', const [0xFF7A1E2E, 0xFF4A1019, 0xFF1F070C], 0xFFFFC2B0, 0xFFE11D48),
  _dark('Emas', const [0xFF8A6A1E, 0xFF4F3B10, 0xFF1F1706], 0xFFFFE08A, 0xFFF59E0B),
  _dark('Tosca', const [0xFF0E7490, 0xFF0B4A5E, 0xFF04202B], 0xFF7FF5E0, 0xFF22D3EE),
  AppPalette('Langit', false, const [Color(0xFFEAF4FF), Color(0xFFD6E9FB), Color(0xFFC2DBF4)], const Color(0xFF2563EB),
      const Color(0xFF60A5FA), const Color(0xFF10243D), const Color(0xFF5A6B80), Colors.white.withValues(alpha: 0.6), Colors.white.withValues(alpha: 0.9)),
];

class QariInfo {
  final String id, name;
  const QariInfo(this.id, this.name);
}

const qariList = [
  QariInfo('ar.abdulbasitmurattal', 'AbdulBaset AbdulSamad'),
  QariInfo('ar.alafasy', 'Mishary Rashid Alafasy'),
  QariInfo('ar.husary', 'Mahmoud Khalil Al-Husary'),
  QariInfo('ar.minshawi', 'Muhammad Siddiq Al-Minshawi'),
  QariInfo('ar.abdurrahmaansudais', 'Abdurrahman As-Sudais'),
  QariInfo('ar.saoodshuraym', 'Saud Ash-Shuraim'),
];

String todayKey() => DateTime.now().toIso8601String().substring(0, 10);

class AppSettings extends ChangeNotifier {
  late SharedPreferences _p;
  int themeIdx = 2;
  bool showArabic = true, bookMode = true, showTranslit = true, tajwid = false, showTranslation = true, showTafsir = false;
  String font = 'Amiri Quran';
  double arabSize = 30, textSize = 15;
  String qari = qariList.first.id;
  int khatamDays = 30;
  String khatamStart = '';
  Set<int> bookmarks = {}, readSet = {};
  int lastRead = 0, sessions = 0, marker = 0;
  Map<String, int> dailySeconds = {}, dailyAyat = {};

  AppPalette get pal => palettes[themeIdx];
  QariInfo get qariInfo => qariList.firstWhere((q) => q.id == qari, orElse: () => qariList.first);

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    themeIdx = (_p.getInt('theme') ?? 2).clamp(0, palettes.length - 1);
    showArabic = _p.getBool('showArabic') ?? true;
    bookMode = _p.getBool('bookMode') ?? true;
    showTranslit = _p.getBool('showTranslit') ?? true;
    tajwid = _p.getBool('tajwid') ?? false;
    showTranslation = _p.getBool('showTranslation') ?? true;
    showTafsir = _p.getBool('showTafsir') ?? false;
    font = _p.getString('font') ?? 'Amiri Quran';
    arabSize = _p.getDouble('arabSize') ?? 30;
    textSize = _p.getDouble('textSize') ?? 15;
    qari = _p.getString('qari') ?? qariList.first.id;
    khatamDays = _p.getInt('khatamDays') ?? 30;
    khatamStart = _p.getString('khatamStart') ?? '';
    lastRead = _p.getInt('lastRead') ?? 0;
    marker = _p.getInt('marker') ?? 0;
    sessions = _p.getInt('sessions') ?? 0;
    bookmarks = (_p.getStringList('bookmarks') ?? []).map(int.parse).toSet();
    final rs = _p.getString('readSet') ?? '';
    readSet = rs.isEmpty ? {} : rs.split(',').map(int.parse).toSet();
    try {
      final d = jsonDecode(_p.getString('daily') ?? '{}') as Map<String, dynamic>;
      dailySeconds = (d['s'] as Map? ?? {}).map((k, v) => MapEntry(k as String, v as int));
      dailyAyat = (d['a'] as Map? ?? {}).map((k, v) => MapEntry(k as String, v as int));
    } catch (_) {}
  }

  void update(void Function() f) {
    f();
    notifyListeners();
    _persist();
  }

  void _persist() {
    _p.setInt('theme', themeIdx);
    _p.setBool('showArabic', showArabic);
    _p.setBool('bookMode', bookMode);
    _p.setBool('showTranslit', showTranslit);
    _p.setBool('tajwid', tajwid);
    _p.setBool('showTranslation', showTranslation);
    _p.setBool('showTafsir', showTafsir);
    _p.setString('font', font);
    _p.setDouble('arabSize', arabSize);
    _p.setDouble('textSize', textSize);
    _p.setString('qari', qari);
    _p.setInt('khatamDays', khatamDays);
    _p.setString('khatamStart', khatamStart);
    _p.setInt('lastRead', lastRead);
    _p.setInt('marker', marker);
    _p.setInt('sessions', sessions);
    _p.setStringList('bookmarks', bookmarks.map((e) => '$e').toList());
    _p.setString('readSet', readSet.join(','));
    _p.setString('daily', jsonEncode({'s': dailySeconds, 'a': dailyAyat}));
  }

  void toggleBookmark(int g) => update(() => bookmarks.contains(g) ? bookmarks.remove(g) : bookmarks.add(g));
  void setLastRead(int g) => update(() => lastRead = g);
  void setMarker(int g) => update(() => marker = g);
  void clearMarker() => update(() => marker = 0);

  int markRead(Iterable<int> gs) {
    int added = 0;
    update(() {
      for (final g in gs) {
        if (readSet.add(g)) added++;
      }
      if (added > 0) dailyAyat[todayKey()] = (dailyAyat[todayKey()] ?? 0) + added;
    });
    return added;
  }

  void addSeconds(int s) {
    if (s < 3) return;
    update(() => dailySeconds[todayKey()] = (dailySeconds[todayKey()] ?? 0) + s);
  }

  void addSession() => update(() => sessions++);
}

final settings = AppSettings();
