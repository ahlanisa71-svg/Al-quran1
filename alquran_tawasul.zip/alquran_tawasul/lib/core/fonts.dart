import 'package:flutter/material.dart';
import 'data.dart';
import 'settings.dart';

class AppFont {
  final String name, label;
  final bool uthmani;
  const AppFont(this.name, this.label, this.uthmani);
}

const appFonts = [
  AppFont('Amiri Quran', 'Uthmani', true),
  AppFont('Scheherazade New', 'Uthmani - Scheherazade', true),
  AppFont('Amiri', 'Naskh Klasik - Amiri', true),
  AppFont('Noto Naskh Arabic', 'Naskh Modern', true),
  AppFont('Lateef', 'Lateef', false),
  AppFont('Harmattan', 'Harmattan', false),
  AppFont('Noto Nastaliq Urdu', 'Nastaliq', false),
  AppFont('Cairo', 'Cairo', false),
  AppFont('Tajawal', 'Tajawal', false),
  AppFont('Reem Kufi', 'Kufi', false),
  AppFont('Markazi Text', 'Markazi', false),
  AppFont('El Messiri', 'El Messiri', false),
  AppFont('Aref Ruqaa', "Ruq'ah", false),
  AppFont('Mirza', 'Mirza', false),
];

AppFont fontOf(String name) => appFonts.firstWhere((f) => f.name == name, orElse: () => appFonts.first);

// Font dipasang langsung di pubspec (dibuat oleh tools/patch_fonts.py), tidak lagi lewat paket google_fonts.
TextStyle arabicStyle(String name, double size, Color color, {double height = 1.9}) =>
    TextStyle(fontFamily: name, fontSize: size, color: color, height: height);

TextStyle uiStyle(double size, Color color, {FontWeight w = FontWeight.w500, double? height}) =>
    TextStyle(fontFamily: 'Poppins', fontSize: size, color: color, fontWeight: w, height: height);

String arabicText(Ayah a) => fontOf(settings.font).uthmani ? a.a : a.s;
