import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'core/core.dart';
import 'screens/quran_tab.dart';
import 'screens/read_tab.dart';
import 'screens/settings_tab.dart';
import 'screens/tawasul.dart';

Future<void> _init() async {
  await settings.load();
  await tawasul.load();
  await QuranData.load();
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  GoogleFonts.config.allowRuntimeFetching = false; // semua font sudah ada di dalam APK (offline)
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: settings,
        builder: (c, _) {
          final dark = settings.pal.dark;
          return MaterialApp(
            title: 'Al Quran dan Tawasul',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              useMaterial3: true,
              brightness: dark ? Brightness.dark : Brightness.light,
              colorScheme: ColorScheme.fromSeed(
                  seedColor: const Color(0xFF12A36B), brightness: dark ? Brightness.dark : Brightness.light),
              scaffoldBackgroundColor: Colors.transparent,
              splashFactory: InkRipple.splashFactory,
            ),
            home: const Boot(),
          );
        },
      );
}

class Boot extends StatefulWidget {
  const Boot({super.key});
  @override
  State<Boot> createState() => _BootState();
}

class _BootState extends State<Boot> {
  late final Future<void> _f = _init();
  @override
  Widget build(BuildContext context) => FutureBuilder<void>(
        future: _f,
        builder: (c, s) {
          Widget child;
          if (s.connectionState != ConnectionState.done) {
            child = const Scaffold(
                backgroundColor: Color(0xFF11141F), body: Center(child: CircularProgressIndicator(color: Color(0xFF3DDC97))));
          } else if (s.hasError) {
            child = Scaffold(
                backgroundColor: const Color(0xFF11141F),
                body: Center(
                    child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text('Gagal memuat data Al-Quran.\n${s.error}', style: const TextStyle(color: Colors.white)),
                )));
          } else {
            child = const Shell();
          }
          return AnimatedSwitcher(duration: const Duration(milliseconds: 500), child: child);
        },
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _KeepAlive extends StatefulWidget {
  final Widget child;
  const _KeepAlive(this.child);
  @override
  State<_KeepAlive> createState() => _KeepAliveState();
}

class _KeepAliveState extends State<_KeepAlive> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    super.build(context);
    return widget.child;
  }
}

class _ShellState extends State<Shell> {
  final _pc = PageController();
  int _i = 0;

  static const _items = [
    (Icons.auto_stories_rounded, 'Quran'),
    (Icons.menu_book_rounded, 'Membaca'),
    (Icons.folder_special_rounded, 'Tawasul'),
    (Icons.settings_rounded, 'Pengaturan'),
  ];

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  void _go(int i) => _pc.animateToPage(i, duration: const Duration(milliseconds: 520), curve: Curves.easeInOutCubic);

  Widget _page(int i, Widget child) => AnimatedBuilder(
        animation: _pc,
        child: _KeepAlive(child),
        builder: (c, w) {
          double page = _i.toDouble();
          if (_pc.hasClients && _pc.position.haveDimensions) page = _pc.page ?? page;
          final d = (page - i).abs().clamp(0.0, 1.0).toDouble();
          return Opacity(opacity: 1 - d * 0.65, child: Transform.scale(scale: 1 - d * 0.05, child: w));
        },
      );

  @override
  Widget build(BuildContext context) => sb((c, p) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: p.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
        child: AppBackground(
          child: Scaffold(
            backgroundColor: Colors.transparent,
            extendBody: true,
            body: PageView(
              controller: _pc,
              physics: const BouncingScrollPhysics(),
              onPageChanged: (i) => setState(() => _i = i),
              children: [
                _page(0, const QuranTab()),
                _page(1, const ReadTab()),
                _page(2, const TawasulTab()),
                _page(3, const SettingsTab()),
              ],
            ),
            bottomNavigationBar: SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(34),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 28, sigmaY: 28),
                    child: Container(
                      height: 70,
                      decoration: BoxDecoration(
                        color: p.glass,
                        borderRadius: BorderRadius.circular(34),
                        border: Border.all(color: p.glassBorder),
                      ),
                      child: Row(children: [
                        for (int i = 0; i < _items.length; i++)
                          Expanded(
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () => _go(i),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 380),
                                curve: Curves.easeOutCubic,
                                margin: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: _i == i ? p.accent.withValues(alpha: 0.20) : Colors.transparent,
                                  borderRadius: BorderRadius.circular(28),
                                ),
                                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                  AnimatedScale(
                                    scale: _i == i ? 1.18 : 1,
                                    duration: const Duration(milliseconds: 380),
                                    curve: Curves.easeOutBack,
                                    child: Icon(_items[i].$1, size: 24, color: _i == i ? p.accent : p.sub),
                                  ),
                                  const SizedBox(height: 2),
                                  AnimatedDefaultTextStyle(
                                    duration: const Duration(milliseconds: 300),
                                    style: uiStyle(10.5, _i == i ? p.accent : p.sub, w: _i == i ? FontWeight.w700 : FontWeight.w500),
                                    child: Text(_items[i].$2, maxLines: 1),
                                  ),
                                ]),
                              ),
                            ),
                          ),
                      ]),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ));
}
