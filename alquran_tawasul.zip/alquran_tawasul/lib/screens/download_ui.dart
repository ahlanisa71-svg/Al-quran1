import 'package:flutter/material.dart';
import '../core/core.dart';

const List<String> kRates = ['32', '64', '128', '192'];
const Map<String, String> kRateNote = {'32': 'Hemat', '64': 'Standar', '128': 'Bagus', '192': 'Terbaik'};

/// Perkiraan ukuran per ayat (rata-rata ±10 detik): kbps × 1250 byte.
int bytesPerAyat(String kbps) => int.parse(kbps) * 1250;

String fmtBytes(int b) {
  if (b < 1024) return '$b B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
  if (b < 1024 * 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
  return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
}

class DownloadChoice {
  final String rate;
  final List<String> qaris;
  DownloadChoice(this.rate, this.qaris);
}

/// Pop-up kaca: pilih kualitas (bitrate) dan qari (boleh lebih dari satu) beserta perkiraan ukuran total.
/// [skip] = qari yang sudah punya surat ini (tidak bisa dipilih lagi).
Future<DownloadChoice?> pickDownload(BuildContext context, String title, int ayat, {Set<String> skip = const {}}) =>
    showGeneralDialog<DownloadChoice>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Tutup',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 340),
      pageBuilder: (ctx, _, __) {
        String rate = settings.dlBitrate;
        final sel = <String>{if (!skip.contains(settings.qari)) settings.qari};
        final qaris = settings.allQaris;
        return sb((c, p) => SafeArea(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                  child: Material(
                    color: Colors.transparent,
                    child: RepaintBoundary(
                      child: DecoratedBox(
                        decoration: BoxDecoration(color: p.bg[1], borderRadius: BorderRadius.circular(24)),
                        child: ConstrainedBox(
                          constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.86),
                          child: GlassCard(
                            blur: false,
                            margin: EdgeInsets.zero,
                            padding: const EdgeInsets.fromLTRB(0, 20, 0, 8),
                            child: StatefulBuilder(builder: (ctx, setS) {
                              final free = [for (final q in qaris) if (!skip.contains(q.id)) q.id];
                              final allOn = free.isNotEmpty && free.every(sel.contains);
                              final total = ayat * bytesPerAyat(rate) * sel.length;
                              return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 22),
                                  child: Text(title, style: uiStyle(18, p.text, w: FontWeight.w700)),
                                ),
                                Flexible(
                                  child: SingleChildScrollView(
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(22, 10, 22, 4),
                                        child: Text('KUALITAS SUARA', style: uiStyle(11.5, p.sub, w: FontWeight.w600)),
                                      ),
                                      for (final r in kRates)
                                        InkWell(
                                          onTap: () => setS(() => rate = r),
                                          child: Container(
                                            color: rate == r ? p.accent.withValues(alpha: 0.16) : Colors.transparent,
                                            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                                            child: Row(children: [
                                              Icon(rate == r ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                                                  size: 22, color: rate == r ? p.accent : p.sub),
                                              const SizedBox(width: 14),
                                              Expanded(
                                                child: Text('$r kbps  •  ${kRateNote[r] ?? ''}',
                                                    style: uiStyle(14, p.text, w: FontWeight.w600)),
                                              ),
                                              Text('~${fmtBytes(ayat * bytesPerAyat(r))}',
                                                  style: uiStyle(13, p.sub, w: FontWeight.w500)),
                                            ]),
                                          ),
                                        ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(22, 12, 12, 0),
                                        child: Row(children: [
                                          Expanded(child: Text('QARI', style: uiStyle(11.5, p.sub, w: FontWeight.w600))),
                                          TextButton(
                                            onPressed: free.isEmpty
                                                ? null
                                                : () => setS(() {
                                                      if (allOn) {
                                                        sel.clear();
                                                      } else {
                                                        sel.addAll(free);
                                                      }
                                                    }),
                                            child: Text(allOn ? 'Kosongkan' : 'Pilih semua qari',
                                                style: uiStyle(12.5, p.accent, w: FontWeight.w600)),
                                          ),
                                        ]),
                                      ),
                                      for (final q in qaris)
                                        InkWell(
                                          onTap: skip.contains(q.id)
                                              ? null
                                              : () => setS(() => sel.contains(q.id) ? sel.remove(q.id) : sel.add(q.id)),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 9),
                                            child: Row(children: [
                                              Icon(
                                                  skip.contains(q.id)
                                                      ? Icons.check_circle_rounded
                                                      : sel.contains(q.id)
                                                          ? Icons.check_box_rounded
                                                          : Icons.check_box_outline_blank_rounded,
                                                  size: 22,
                                                  color: skip.contains(q.id) ? p.sub : (sel.contains(q.id) ? p.accent : p.sub)),
                                              const SizedBox(width: 14),
                                              Expanded(
                                                child: Text(q.name,
                                                    style: uiStyle(14, skip.contains(q.id) ? p.sub : p.text, w: FontWeight.w500)),
                                              ),
                                              if (skip.contains(q.id)) Text('Sudah ada', style: uiStyle(11.5, p.sub, w: FontWeight.w400)),
                                            ]),
                                          ),
                                        ),
                                    ]),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(22, 8, 22, 0),
                                  child: Text(
                                    sel.isEmpty
                                        ? 'Pilih minimal satu qari'
                                        : 'Total: ${sel.length} qari × ~${fmtBytes(ayat * bytesPerAyat(rate))} = ~${fmtBytes(total)}',
                                    style: uiStyle(13, sel.isEmpty ? p.sub : p.text, w: FontWeight.w700),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                                  child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                                    TextButton(
                                      onPressed: () => Navigator.pop(ctx),
                                      child: Text('Batal', style: uiStyle(14, p.sub, w: FontWeight.w600)),
                                    ),
                                    TextButton(
                                      onPressed: sel.isEmpty
                                          ? null
                                          : () => Navigator.pop(ctx, DownloadChoice(rate, [for (final q in qaris) if (sel.contains(q.id)) q.id])),
                                      child: Text('Unduh', style: uiStyle(14, sel.isEmpty ? p.sub : p.accent, w: FontWeight.w700)),
                                    ),
                                  ]),
                                ),
                              ]);
                            }),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ));
      },
      transitionBuilder: (ctx, anim, _, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutQuart, reverseCurve: Curves.easeInCubic);
        return FadeTransition(
          opacity: curved,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero).animate(curved),
            child: child,
          ),
        );
      },
    );

/// Baris surat yang belum diunduh: ketuk → pop-up kualitas → unduh. Progres ditampilkan di baris sendiri.
class PendingSurahRow extends StatelessWidget {
  final Surah surah;
  final VoidCallback onDownload;
  const PendingSurahRow({super.key, required this.surah, required this.onDownload});

  @override
  Widget build(BuildContext context) => sb((c, p) => ListenableBuilder(
        listenable: DownloadManager.I,
        builder: (ctx, _) {
          final dm = DownloadManager.I;
          final prog = dm.progressOf(settings.qari, surah.n);
          final queued = prog != null;
          final others = [for (final q in settings.allQaris) if (q.id != settings.qari && dm.progressOf(q.id, surah.n) != null) q.id];
          return InkWell(
            onTap: queued ? null : onDownload,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
              child: Row(children: [
                SizedBox(width: 34, child: Text('${surah.n}', style: uiStyle(13.5, p.sub, w: FontWeight.w600))),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(surah.en, style: uiStyle(15, p.text, w: FontWeight.w600)),
                    Text(
                      queued
                          ? (prog > 0 ? 'Mengunduh ${(prog * 100).round()}%' : 'Menunggu antrean…')
                          : others.isNotEmpty
                              ? 'Sedang diunduh untuk ${others.length} qari lain…'
                              : '${surah.ayat.length} ayat • ~${fmtBytes(surah.ayat.length * bytesPerAyat(settings.dlBitrate))}',
                      style: uiStyle(12, queued || others.isNotEmpty ? p.accent : p.sub, w: FontWeight.w400),
                    ),
                  ]),
                ),
                SizedBox(
                  width: 38,
                  height: 38,
                  child: queued
                      ? Padding(
                          padding: const EdgeInsets.all(8),
                          child: CircularProgressIndicator(
                              strokeWidth: 2.4, value: prog > 0 ? prog : null, color: p.accent, backgroundColor: p.accent.withValues(alpha: 0.2)),
                        )
                      : Icon(Icons.download_rounded, color: p.accent, size: 24),
                ),
              ]),
            ),
          );
        },
      ));
}
