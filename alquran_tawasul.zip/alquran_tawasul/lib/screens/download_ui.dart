import 'package:flutter/material.dart';
import '../core/core.dart';

const List<String> kRates = ['32', '64', '128', '192'];
const Map<String, String> kRateNote = {'32': 'Hemat', '64': 'Standar', '128': 'Bagus', '192': 'Terbaik'};

/// Perkiraan ukuran per ayat (rata-rata ±10 detik): kbps × 1250 byte.
int bytesPerAyat(String kbps) => int.parse(kbps) * 1250;

String fmtBytes(int b) {
  if (b < 1024) return '$b B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
  if (b < 1024 * 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
  return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
}

/// Pop-up kaca: pilih kualitas (bitrate) beserta perkiraan ukuran. Hasil: kbps terpilih atau null.
Future<String?> pickDownloadRate(BuildContext context, String title, int ayat) => showGeneralDialog<String>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Tutup',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 340),
      pageBuilder: (ctx, _, __) => sb((c, p) => SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: Material(
                  color: Colors.transparent,
                  child: RepaintBoundary(
                    child: DecoratedBox(
                      decoration: BoxDecoration(color: p.bg[1], borderRadius: BorderRadius.circular(24)),
                      child: GlassCard(
                        blur: false,
                        margin: EdgeInsets.zero,
                        padding: const EdgeInsets.fromLTRB(0, 20, 0, 8),
                        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 22),
                            child: Text(title, style: uiStyle(18, p.text, w: FontWeight.w700)),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(22, 6, 22, 10),
                            child: Text('Pilih kualitas suara (bitrate). Makin tinggi makin jernih, tapi makin besar.\n${settings.qariInfo.name}',
                                style: uiStyle(12, p.sub, w: FontWeight.w400, height: 1.5)),
                          ),
                          for (final r in kRates)
                            InkWell(
                              onTap: () => Navigator.pop(ctx, r),
                              child: Container(
                                color: settings.dlBitrate == r ? p.accent.withValues(alpha: 0.16) : Colors.transparent,
                                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                                child: Row(children: [
                                  Icon(settings.dlBitrate == r ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                                      size: 22, color: settings.dlBitrate == r ? p.accent : p.sub),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                      Text('$r kbps', style: uiStyle(15, p.text, w: FontWeight.w700)),
                                      Text(kRateNote[r] ?? '', style: uiStyle(12, p.sub, w: FontWeight.w400)),
                                    ]),
                                  ),
                                  Text('~${fmtBytes(ayat * bytesPerAyat(r))}', style: uiStyle(14, p.text, w: FontWeight.w600)),
                                ]),
                              ),
                            ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Padding(
                              padding: const EdgeInsets.only(right: 12, top: 4),
                              child: TextButton(
                                onPressed: () => Navigator.pop(ctx),
                                child: Text('Batal', style: uiStyle(14, p.accent, w: FontWeight.w600)),
                              ),
                            ),
                          ),
                        ]),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          )),
      transitionBuilder: (ctx, anim, _, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutQuart, reverseCurve: Curves.easeInCubic);
        return FadeTransition(
          opacity: curved,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero).animate(curved),
            child: child,
          ),
        );
      },
    );

/// Baris surat yang belum diunduh: ketuk → pop-up kualitas → unduh. Progres ditampilkan di baris sendiri.
class PendingSurahRow extends StatelessWidget {
  final Surah surah;
  final VoidCallback onDownload;
  const PendingSurahRow({super.key, required this.surah, required this.onDownload});

  @override
  Widget build(BuildContext context) => sb((c, p) => ListenableBuilder(
        listenable: DownloadManager.I,
        builder: (ctx, _) {
          final dm = DownloadManager.I;
          final prog = dm.progressOf(settings.qari, surah.n);
          final queued = prog != null;
          return InkWell(
            onTap: queued ? null : onDownload,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
              child: Row(children: [
                SizedBox(width: 34, child: Text('${surah.n}', style: uiStyle(13.5, p.sub, w: FontWeight.w600))),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(surah.en, style: uiStyle(15, p.text, w: FontWeight.w600)),
                    Text(
                      queued
                          ? (prog > 0 ? 'Mengunduh ${(prog * 100).round()}%' : 'Menunggu antrean…')
                          : '${surah.ayat.length} ayat • ~${fmtBytes(surah.ayat.length * bytesPerAyat(settings.dlBitrate))}',
                      style: uiStyle(12, queued ? p.accent : p.sub, w: FontWeight.w400),
                    ),
                  ]),
                ),
                SizedBox(
                  width: 38,
                  height: 38,
                  child: queued
                      ? Padding(
                          padding: const EdgeInsets.all(8),
                          child: CircularProgressIndicator(
                              strokeWidth: 2.4, value: prog > 0 ? prog : null, color: p.accent, backgroundColor: p.accent.withValues(alpha: 0.2)),
                        )
                      : Icon(Icons.download_rounded, color: p.accent, size: 24),
                ),
              ]),
            ),
          );
        },
      ));
}
