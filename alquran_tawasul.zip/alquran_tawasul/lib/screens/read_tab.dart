import 'package:flutter/material.dart';
import '../core/core.dart';
import 'reader.dart';

class ReadTab extends StatelessWidget {
  const ReadTab({super.key});

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final last = settings.lastRead > 0 ? QuranData.byGlobal(settings.lastRead) : null;
        final doy = DateTime.now().difference(DateTime(DateTime.now().year)).inDays;
        final daily = QuranData.byGlobal((doy * 37) % QuranData.all.length + 1);
        final dailySurah = QuranData.surah(daily.sn);
        return SafeArea(
          bottom: false,
          child: ListView(padding: const EdgeInsets.only(bottom: navPad), children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 14, 24, 10),
              child: Text('Membaca', style: uiStyle(24, p.text, w: FontWeight.w700)),
            ),
            if (settings.marker > 0)
              Builder(builder: (_) {
                final m = QuranData.byGlobal(settings.marker);
                return GlassCard(
                  onTap: () => openSurah(context, QuranData.surah(m.sn), jumpTo: m.g),
                  child: Row(children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent.withValues(alpha: 0.18)),
                      child: Icon(Icons.flag_rounded, color: p.accent),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Terakhir dibaca (penanda)', style: uiStyle(12.5, p.sub)),
                        Text('${QuranData.surah(m.sn).en} • ayat ${m.n}', style: uiStyle(16, p.text, w: FontWeight.w700)),
                        Text('Juz ${m.j} • Halaman ${m.p}', style: uiStyle(12.5, p.sub)),
                      ]),
                    ),
                    IconButton(
                      tooltip: 'Hapus penanda',
                      icon: Icon(Icons.close_rounded, color: p.sub),
                      onPressed: settings.clearMarker,
                    ),
                  ]),
                );
              }),
            if (last != null)
              GlassCard(
                onTap: () => openSurah(context, QuranData.surah(last.sn), jumpTo: last.g),
                child: Row(children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent.withValues(alpha: 0.18)),
                    child: Icon(Icons.auto_stories_rounded, color: p.accent),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Lanjutkan posisi terakhir', style: uiStyle(12.5, p.sub)),
                      Text('${QuranData.surah(last.sn).en} • ayat ${last.n}',
                          style: uiStyle(16, p.text, w: FontWeight.w700)),
                      Text('Juz ${last.j}', style: uiStyle(12.5, p.sub)),
                    ]),
                  ),
                  Icon(Icons.chevron_right_rounded, color: p.sub),
                ]),
              ),
            const SectionLabel('AYAT HARI INI'),
            GlassCard(
              onTap: () => openSurah(context, dailySurah, jumpTo: daily.g),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SizedBox(
                  width: double.infinity,
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Text(arabicText(daily),
                        textAlign: TextAlign.right,
                        style: arabicStyle(settings.font, 26, p.text)),
                  ),
                ),
                const SizedBox(height: 8),
                Text(daily.i, style: uiStyle(14, p.text, w: FontWeight.w400, height: 1.55)),
                const SizedBox(height: 6),
                Text('QS ${dailySurah.en}: ${daily.n}', style: uiStyle(12.5, p.accent, w: FontWeight.w600)),
              ]),
            ),
            const SectionLabel('BACA PER JUZ'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: GridView.count(
                crossAxisCount: 5,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                children: [
                  for (int j = 1; j <= 30; j++)
                    GlassCard(
                      blur: false,
                      margin: EdgeInsets.zero,
                      padding: EdgeInsets.zero,
                      radius: 18,
                      onTap: () => openJuz(context, j),
                      child: Center(child: Text('$j', style: uiStyle(16, p.text, w: FontWeight.w700))),
                    ),
                ],
              ),
            ),
          ]),
        );
      });
}
