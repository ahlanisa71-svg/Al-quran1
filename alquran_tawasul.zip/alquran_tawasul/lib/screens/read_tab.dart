import 'package:flutter/material.dart';
import '../core/core.dart';
import 'reader.dart';
import 'download_ui.dart';
import 'settings_pages.dart' show DownloadsPage;

class ReadTab extends StatefulWidget {
  const ReadTab({super.key});

  @override
  State<ReadTab> createState() => _ReadTabState();
}

class _ReadTabState extends State<ReadTab> {
  final dm = DownloadManager.I;

  @override
  void initState() {
    super.initState();
    dm.load();
  }

  String _qariName(String id) => settings.allQaris.firstWhere((q) => q.id == id, orElse: () => settings.qariInfo).name;

  bool _isPlaying(Surah s, String qari) {
    final cur = AudioService.I.current.value;
    return cur != null && QuranData.byGlobal(cur).sn == s.n && AudioService.I.qariNow == qari;
  }

  /// Putar / hentikan satu surat penuh dari audio yang sudah diunduh (dengan qari milik surat itu).
  Future<void> _togglePlay(Surah s, String qari) async {
    if (_isPlaying(s, qari)) {
      await AudioService.I.stop();
    } else {
      await AudioService.I.toggle(s.ayat, 0, qari: qari);
    }
  }

  Future<void> _download(Surah s) async {
    final skip = {for (final q in settings.allQaris) if (dm.isDone(q.id, s.n)) q.id};
    final r = await pickDownload(context, 'Unduh ${s.en}', s.ayat.length, skip: skip);
    if (r == null) return;
    settings.update(() => settings.dlBitrate = r.rate);
    for (final q in r.qaris) {
      dm.enqueue(q, s);
    }
  }

  Future<void> _downloadAll(List<Surah> todo) async {
    if (todo.isEmpty) return;
    final r = await pickDownload(context, 'Unduh semua surat', todo.fold<int>(0, (t, x) => t + x.ayat.length));
    if (r == null) return;
    settings.update(() => settings.dlBitrate = r.rate);
    for (final q in r.qaris) {
      for (final x in todo) {
        dm.enqueue(q, x); // yang sudah diunduh otomatis dilewati
      }
    }
  }

  Future<void> _delete(Surah s, String qari) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Hapus audio ${s.en}?'),
        content: Text('Audio surat ini (${_qariName(qari)}) dihapus dari HP. Anda bisa mengunduhnya lagi nanti.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;
    if (_isPlaying(s, qari)) await AudioService.I.stop();
    await dm.deleteSurah(qari, s);
  }

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final last = settings.lastRead > 0 ? QuranData.byGlobal(settings.lastRead) : null;
        final doy = DateTime.now().difference(DateTime(DateTime.now().year)).inDays;
        final daily = QuranData.byGlobal((doy * 37) % QuranData.all.length + 1);
        final dailySurah = QuranData.surah(daily.sn);
        return SafeArea(
          bottom: false,
          child: ListView(padding: const EdgeInsets.only(bottom: navPad), children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 14, 24, 10),
              child: Text('Mendengarkan', style: uiStyle(24, p.text, w: FontWeight.w700)),
            ),
            if (settings.marker > 0)
              Builder(builder: (_) {
                final m = QuranData.byGlobal(settings.marker);
                return GlassCard(
                  onTap: () => openSurah(context, QuranData.surah(m.sn), jumpTo: m.g),
                  child: Row(children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent.withValues(alpha: 0.18)),
                      child: Icon(Icons.flag_rounded, color: p.accent),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Terakhir dibaca (penanda)', style: uiStyle(12.5, p.sub)),
                        Text('${QuranData.surah(m.sn).en} • ayat ${m.n}', style: uiStyle(16, p.text, w: FontWeight.w700)),
                        Text('Juz ${m.j} • Halaman ${m.p}', style: uiStyle(12.5, p.sub)),
                      ]),
                    ),
                    IconButton(
                      tooltip: 'Hapus penanda',
                      icon: Icon(Icons.close_rounded, color: p.sub),
                      onPressed: settings.clearMarker,
                    ),
                  ]),
                );
              }),
            if (last != null)
              GlassCard(
                onTap: () => openSurah(context, QuranData.surah(last.sn), jumpTo: last.g),
                child: Row(children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent.withValues(alpha: 0.18)),
                    child: Icon(Icons.auto_stories_rounded, color: p.accent),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Lanjutkan posisi terakhir', style: uiStyle(12.5, p.sub)),
                      Text('${QuranData.surah(last.sn).en} • ayat ${last.n}',
                          style: uiStyle(16, p.text, w: FontWeight.w700)),
                      Text('Juz ${last.j}', style: uiStyle(12.5, p.sub)),
                    ]),
                  ),
                  Icon(Icons.chevron_right_rounded, color: p.sub),
                ]),
              ),
            const SectionLabel('AYAT HARI INI'),
            GlassCard(
              onTap: () => openSurah(context, dailySurah, jumpTo: daily.g),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                SizedBox(
                  width: double.infinity,
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Text(arabicText(daily),
                        textAlign: TextAlign.right,
                        style: arabicStyle(settings.font, 26, p.text)),
                  ),
                ),
                const SizedBox(height: 8),
                Text(daily.i, style: uiStyle(14, p.text, w: FontWeight.w400, height: 1.55)),
                const SizedBox(height: 6),
                Text('QS ${dailySurah.en}: ${daily.n}', style: uiStyle(12.5, p.accent, w: FontWeight.w600)),
              ]),
            ),
            ValueListenableBuilder<int>(
              valueListenable: dm.doneRev,
              builder: (ctx, _, __) {
                // semua qari: satu baris per (surat, qari), urut nomor surat
                final done = [
                  for (final s in QuranData.surahs)
                    for (final q in settings.allQaris)
                      if (dm.isDone(q.id, s.n)) (s, q.id)
                ];
                final todo = [for (final s in QuranData.surahs) if (!dm.isDone(settings.qari, s.n)) s];
                return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(28, 6, 16, 2),
                    child: Row(children: [
                      Expanded(child: Text('SURAT YANG DIUNDUH', style: uiStyle(12.5, p.sub, w: FontWeight.w600))),
                      TextButton(
                        onPressed: () => Navigator.push(context, smoothRoute(const DownloadsPage())),
                        child: Text('Kelola', style: uiStyle(13, p.accent, w: FontWeight.w600)),
                      ),
                    ]),
                  ),
                  if (done.isEmpty)
                    GlassCard(
                      child: Column(children: [
                        Icon(Icons.headphones_rounded, size: 34, color: p.accent),
                        const SizedBox(height: 10),
                        Text('Belum ada surat yang diunduh', style: uiStyle(15, p.text, w: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text('Pilih surat di bawah untuk diunduh, lalu dengarkan di sini tanpa internet.',
                            textAlign: TextAlign.center, style: uiStyle(12.5, p.sub, w: FontWeight.w400, height: 1.5)),
                      ]),
                    )
                  else
                    ValueListenableBuilder<int?>(
                      valueListenable: AudioService.I.current,
                      builder: (ctx, cur, _) {
                        final playingSurah = cur == null ? null : QuranData.byGlobal(cur).sn;
                        final playingQari = AudioService.I.qariNow;
                        return Column(children: [
                          for (final e in done)
                            ...[
                            (() {
                              final s = e.$1;
                              final qid = e.$2;
                              final on = playingSurah == s.n && playingQari == qid;
                              return GlassCard(
                              blur: false,
                              padding: const EdgeInsets.fromLTRB(16, 10, 10, 10),
                              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                              radius: 20,
                              onTap: () => _togglePlay(s, qid),
                              child: Row(children: [
                                SizedBox(width: 34, child: Text('${s.n}', style: uiStyle(14, p.sub, w: FontWeight.w600))),
                                Expanded(
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    Text(s.en, style: uiStyle(16, on ? p.accent : p.text, w: FontWeight.w700)),
                                    Text('${s.ayat.length} ayat • ${_qariName(qid)}',
                                        maxLines: 1, overflow: TextOverflow.ellipsis, style: uiStyle(12, p.sub, w: FontWeight.w400)),
                                  ]),
                                ),
                                IconButton(
                                  tooltip: 'Hapus audio',
                                  icon: Icon(Icons.delete_outline_rounded, size: 20, color: p.sub),
                                  onPressed: () => _delete(s, qid),
                                ),
                                Container(
                                  width: 42,
                                  height: 42,
                                  decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent.withValues(alpha: 0.18)),
                                  child: Icon(on ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                      color: p.accent, size: 26),
                                ),
                              ]),
                              );
                            })(),
                            ],
                        ]);
                      },
                    ),
                  if (todo.isNotEmpty) ...[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(28, 14, 16, 2),
                      child: Row(children: [
                        Expanded(
                            child: Text('BELUM DIUNDUH • ${settings.qariInfo.name.toUpperCase()}',
                                maxLines: 1, overflow: TextOverflow.ellipsis, style: uiStyle(12.5, p.sub, w: FontWeight.w600))),
                        TextButton(
                          onPressed: () => _downloadAll(todo),
                          child: Text('Unduh semua', style: uiStyle(13, p.accent, w: FontWeight.w600)),
                        ),
                      ]),
                    ),
                    GlassCard(
                      blur: false,
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      radius: 22,
                      child: Column(children: [
                        for (int i = 0; i < todo.length; i++) ...[
                          PendingSurahRow(surah: todo[i], onDownload: () => _download(todo[i])),
                          if (i != todo.length - 1)
                            Divider(height: 1, thickness: 0.6, indent: 18, endIndent: 18, color: p.glassBorder),
                        ],
                      ]),
                    ),
                  ],
                ]);
              },
            ),
          ]),
        );
      });
}
