import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import '../core/core.dart';

void openSurah(BuildContext ctx, Surah s, {int? jumpTo}) {
  if (settings.bookMode) {
    final page = QuranData.byGlobal(jumpTo ?? s.ayat.first.g).p;
    Navigator.push(ctx, smoothRoute(MushafReader(title: s.en, startPage: page)));
  } else {
    Navigator.push(ctx, smoothRoute(ReaderPage(title: s.en, ayat: s.ayat, jumpTo: jumpTo)));
  }
}

void openJuz(BuildContext ctx, int j, {int? jumpTo}) {
  if (settings.bookMode) {
    final page = QuranData.byGlobal(jumpTo ?? QuranData.juzStart(j).g).p;
    Navigator.push(ctx, smoothRoute(MushafReader(title: 'Juz $j', startPage: page)));
  } else {
    Navigator.push(ctx, smoothRoute(ReaderPage(title: 'Juz $j', ayat: QuranData.juz(j), jumpTo: jumpTo)));
  }
}

const _juzNames = [
  'الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر',
  'الحادي عشر', 'الثاني عشر', 'الثالث عشر', 'الرابع عشر', 'الخامس عشر', 'السادس عشر', 'السابع عشر',
  'الثامن عشر', 'التاسع عشر', 'العشرون', 'الحادي والعشرون', 'الثاني والعشرون', 'الثالث والعشرون',
  'الرابع والعشرون', 'الخامس والعشرون', 'السادس والعشرون', 'السابع والعشرون', 'الثامن والعشرون',
  'التاسع والعشرون', 'الثلاثون',
];

// ═════════════════════════ MODE MUSHAF (tampilan halaman Utsmani) ═════════════════════════
class MushafReader extends StatefulWidget {
  final String title;
  final int startPage;
  const MushafReader({super.key, required this.title, required this.startPage});
  @override
  State<MushafReader> createState() => _MushafReaderState();
}

class _MushafReaderState extends State<MushafReader> {
  late final PageController _pc = PageController(initialPage: widget.startPage - 1);
  late int _page = widget.startPage;
  final _sw = Stopwatch()..start();
  late final Future<void> _font = _loadFont();

  Future<void> _loadFont() async {
    try {
      await GoogleFonts.pendingFonts([GoogleFonts.getFont(settings.font), GoogleFonts.getFont('Amiri Quran')]);
    } catch (_) {}
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      settings.addSession();
      _remember(_page);
    });
  }

  void _remember(int page) {
    final l = QuranData.pages[page];
    if (l != null && l.isNotEmpty) settings.setLastRead(l.first.g);
  }

  @override
  void dispose() {
    final secs = _sw.elapsed.inSeconds;
    _pc.dispose();
    Future.microtask(() {
      settings.addSeconds(secs);
      AudioService.I.stop();
    });
    super.dispose();
  }

  void _toList() {
    final l = QuranData.pages[_page] ?? const <Ayah>[];
    if (l.isEmpty) return;
    final s = QuranData.surah(l.first.sn);
    settings.update(() => settings.bookMode = false);
    Navigator.pushReplacement(context, smoothRoute(ReaderPage(title: s.en, ayat: s.ayat, jumpTo: l.first.g)));
  }

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final l = QuranData.pages[_page] ?? const <Ayah>[];
        final title = l.isEmpty ? widget.title : QuranData.surah(l.last.sn).en;
        return GlassScaffold(
          title: title,
          actions: [
            IconButton(
              tooltip: 'Tandai terakhir dibaca',
              icon: Icon(l.any((a) => a.g == settings.marker) ? Icons.flag_rounded : Icons.outlined_flag_rounded,
                  color: l.any((a) => a.g == settings.marker) ? p.accent : p.text),
              onPressed: () {
                if (l.isEmpty) return;
                settings.setMarker(l.first.g);
                final s = QuranData.surah(l.first.sn);
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Penanda terakhir dibaca: ${s.en} ayat ${l.first.n}. Ketuk ayat lain untuk memindahkan.')));
              },
            ),
            IconButton(
              tooltip: 'Tandai halaman selesai dibaca',
              icon: Icon(Icons.check_circle_outline_rounded, color: p.text),
              onPressed: () {
                final n = settings.markRead(l.map((a) => a.g));
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text(n > 0 ? '$n ayat ditandai selesai dibaca' : 'Halaman ini sudah ditandai')));
              },
            ),
            IconButton(
              tooltip: 'Mode Daftar',
              icon: Icon(Icons.view_agenda_rounded, color: p.text),
              onPressed: _toList,
            ),
          ],
          body: FutureBuilder<void>(
            future: _font,
            builder: (ctx, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return Center(child: CircularProgressIndicator(color: p.accent));
              }
              return PageView.builder(
                reverse: true,
                controller: _pc,
                physics: const BouncingScrollPhysics(),
                itemCount: 604,
                onPageChanged: (i) {
                  setState(() => _page = i + 1);
                  _remember(i + 1);
                },
                itemBuilder: (ctx, i) => MushafPage(key: ValueKey('p$i'), page: i + 1),
              );
            },
          ),
        );
      });
}

class MushafPage extends StatefulWidget {
  final int page;
  const MushafPage({super.key, required this.page});
  @override
  State<MushafPage> createState() => _MushafPageState();
}

class _MushafPageState extends State<MushafPage> {
  final _recs = <TapGestureRecognizer>[];
  String _cacheKey = '';
  double _cacheSize = 24;

  void _clear() {
    for (final r in _recs) {
      r.dispose();
    }
    _recs.clear();
  }

  @override
  void dispose() {
    _clear();
    super.dispose();
  }

  List<Object> _items(List<Ayah> ayat) {
    final out = <Object>[];
    var cur = <Ayah>[];
    for (final a in ayat) {
      if (a.n == 1) {
        if (cur.isNotEmpty) {
          out.add(cur);
          cur = [];
        }
        out.add(QuranData.surah(a.sn));
      }
      cur.add(a);
    }
    if (cur.isNotEmpty) out.add(cur);
    return out;
  }

  bool _hasBismillah(Surah s) => s.n != 1 && s.n != 9;
  double _bannerH(Surah s, double size) => size * 2.0 + (_hasBismillah(s) ? size * 1.9 : 0);

  List<InlineSpan> _spans(List<Ayah> list, double size, AppPalette p, {required bool live}) {
    final st = arabicStyle(settings.font, size, p.text, height: 1.8);
    final out = <InlineSpan>[];
    for (final a in list) {
      TapGestureRecognizer? rec;
      if (live) {
        rec = TapGestureRecognizer()..onTap = () => _sheet(a, p);
        _recs.add(rec);
      }
      final marked = a.g == settings.marker;
      out.add(TextSpan(
          text: arabicText(a),
          style: marked ? st.copyWith(backgroundColor: goldOf(p).withValues(alpha: 0.28)) : st,
          recognizer: rec));
      out.add(TextSpan(text: ' ', style: st));
      out.add(WidgetSpan(
        alignment: PlaceholderAlignment.middle,
        child: GestureDetector(
          onTap: live ? () => _sheet(a, p) : null,
          child: SizedBox(
            width: size,
            height: size,
            child: CustomPaint(
              painter: AyahMarkPainter(goldOf(p)),
              child: Center(
                child: Padding(
                  padding: EdgeInsets.all(size * 0.17),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(arNum(a.n), style: arabicStyle('Amiri Quran', size * 0.46, p.text, height: 1.0)),
                  ),
                ),
              ),
            ),
          ),
        ),
      ));
      out.add(TextSpan(text: ' ', style: st));
    }
    return out;
  }

  double _height(List<Object> items, double w, double size, AppPalette p) {
    double h = 0;
    for (final it in items) {
      if (it is Surah) {
        h += _bannerH(it, size);
      } else {
        final list = it as List<Ayah>;
        final tp = TextPainter(
          text: TextSpan(children: _spans(list, size, p, live: false)),
          textDirection: TextDirection.rtl,
          textAlign: TextAlign.justify,
          textScaler: TextScaler.noScaling,
        );
        tp.setPlaceholderDimensions(List.filled(
            list.length, PlaceholderDimensions(size: Size(size, size), alignment: PlaceholderAlignment.middle)));
        tp.layout(maxWidth: w);
        h += tp.height;
        tp.dispose();
      }
    }
    return h;
  }

  double _fit(List<Object> items, double w, double h, AppPalette p) {
    final key = '${widget.page}|${w.round()}|${h.round()}|${settings.font}|${settings.arabSize}';
    if (key == _cacheKey) return _cacheSize;
    double hi = settings.arabSize.clamp(18.0, 46.0).toDouble();
    double lo = 12;
    double best;
    if (_height(items, w, hi, p) <= h) {
      best = hi;
    } else {
      best = lo;
      for (int i = 0; i < 9; i++) {
        final mid = (lo + hi) / 2;
        if (_height(items, w, mid, p) <= h) {
          best = mid;
          lo = mid;
        } else {
          hi = mid;
        }
      }
    }
    _cacheKey = key;
    _cacheSize = best;
    return best;
  }

  Widget _banner(Surah s, double size, AppPalette p) {
    final gold = goldOf(p);
    return Column(children: [
      SizedBox(
        height: size * 2.0,
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: size * 0.15),
          child: CustomPaint(
            painter: OrnamentBarPainter(gold, bold: true),
            child: Center(child: Text('سورة ${s.arPlain}', style: arabicStyle(settings.font, size * 0.95, p.text, height: 1.2))),
          ),
        ),
      ),
      if (_hasBismillah(s))
        SizedBox(
          height: size * 1.9,
          child: Center(
            child: Text(bismillah, textDirection: TextDirection.rtl, style: arabicStyle(settings.font, size * 0.95, p.text, height: 1.5)),
          ),
        ),
    ]);
  }

  void _sheet(Ayah a, AppPalette p0) {
    final s = QuranData.surah(a.sn);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: p0.bg[1],
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => sb((c, p) => SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(22, 20, 22, 18),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${s.en} : ${a.n}', style: uiStyle(16, p.text, w: FontWeight.w700)),
                Text('Juz ${a.j} • Halaman ${a.p}', style: uiStyle(12.5, p.sub)),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Text(arabicText(a), textAlign: TextAlign.right, style: arabicStyle(settings.font, 28, p.text)),
                  ),
                ),
                const SizedBox(height: 10),
                Text(a.t, style: uiStyle(13.5, p.accent, height: 1.5)),
                const SizedBox(height: 8),
                Text(a.i, style: uiStyle(14.5, p.text, w: FontWeight.w400, height: 1.55)),
                if (settings.showTafsir) ...[
                  const SizedBox(height: 10),
                  Text('Tafsir Jalalayn', style: uiStyle(12, p.sub, w: FontWeight.w700)),
                  Text(a.k, style: uiStyle(13, p.sub, w: FontWeight.w400, height: 1.5)),
                ],
                const SizedBox(height: 14),
                ValueListenableBuilder<int?>(
                  valueListenable: AudioService.I.current,
                  builder: (_, cur, __) => Row(children: [
                    _SheetBtn(cur == a.g ? Icons.stop_circle_rounded : Icons.play_circle_rounded, cur == a.g ? 'Berhenti' : 'Putar',
                        p, () => AudioService.I.toggle([a], 0)),
                    _SheetBtn(settings.marker == a.g ? Icons.flag_rounded : Icons.outlined_flag_rounded, 'Terakhir dibaca', p, () {
                      settings.marker == a.g ? settings.clearMarker() : settings.setMarker(a.g);
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text(settings.marker == a.g ? 'Penanda terakhir dibaca disimpan' : 'Penanda dihapus')));
                    }),
                    _SheetBtn(settings.bookmarks.contains(a.g) ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, 'Bookmark',
                        p, () => settings.toggleBookmark(a.g)),
                    _SheetBtn(Icons.copy_rounded, 'Salin', p, () {
                      Clipboard.setData(ClipboardData(text: '${arabicText(a)}\n\n${a.i}\n(QS ${s.en}: ${a.n})'));
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ayat disalin')));
                    }),
                  ]),
                ),
              ]),
            ),
          )),
    );
  }

  @override
  Widget build(BuildContext context) => sb((c, p) {
        _clear();
        final ayat = QuranData.pages[widget.page] ?? const <Ayah>[];
        if (ayat.isEmpty) return const SizedBox();
        final gold = goldOf(p);
        final paper = p.dark ? p.glass : const Color(0xFFFBF8EF);
        final last = ayat.last;
        final items = _items(ayat);
        final headerStyle = arabicStyle('Amiri Quran', 14, p.text, height: 1.2);
        return Padding(
          padding: const EdgeInsets.fromLTRB(14, 2, 14, 14),
          child: Container(
            decoration: BoxDecoration(
              color: paper,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: p.glassBorder),
            ),
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
            child: Column(children: [
              SizedBox(
                height: 34,
                child: CustomPaint(
                  painter: OrnamentBarPainter(gold),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 34),
                    child: Directionality(
                      textDirection: TextDirection.rtl,
                      child: Row(children: [
                        Text('الجزء ${_juzNames[(last.j - 1).clamp(0, 29)]}', style: headerStyle),
                        Expanded(child: Center(child: Text('سورة ${QuranData.surah(last.sn).arPlain}', style: headerStyle))),
                        Text(arNum(widget.page), style: headerStyle),
                      ]),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: LayoutBuilder(builder: (ctx, box) {
                  final size = _fit(items, box.maxWidth, box.maxHeight, p);
                  final body = Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      for (final it in items)
                        if (it is Surah)
                          _banner(it, size, p)
                        else
                          SizedBox(
                            width: double.infinity,
                            child: Text.rich(
                              TextSpan(children: _spans(it as List<Ayah>, size, p, live: true)),
                              textDirection: TextDirection.rtl,
                              textAlign: TextAlign.justify,
                              textScaler: TextScaler.noScaling,
                            ),
                          ),
                    ],
                  );
                  return SingleChildScrollView(
                    physics: const ClampingScrollPhysics(),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(minHeight: box.maxHeight),
                      child: widget.page <= 2 ? Center(child: body) : Align(alignment: Alignment.topCenter, child: body),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 6),
              SizedBox(
                height: 26,
                width: 84,
                child: CustomPaint(
                  painter: OrnamentBarPainter(gold),
                  child: Center(child: Text(arNum(widget.page), style: arabicStyle('Amiri Quran', 13, p.text, height: 1.1))),
                ),
              ),
            ]),
          ),
        );
      });
}

class _SheetBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final AppPalette p;
  final VoidCallback onTap;
  const _SheetBtn(this.icon, this.label, this.p, this.onTap);
  @override
  Widget build(BuildContext context) => Expanded(
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(children: [
              Icon(icon, color: p.accent, size: 28),
              const SizedBox(height: 2),
              Text(label, style: uiStyle(12, p.text)),
            ]),
          ),
        ),
      );
}

// ═════════════════════════ MODE DAFTAR (ayat + terjemahan) ═════════════════════════
class ReaderPage extends StatefulWidget {
  final String title;
  final List<Ayah> ayat;
  final int? jumpTo;
  const ReaderPage({super.key, required this.title, required this.ayat, this.jumpTo});

  @override
  State<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends State<ReaderPage> {
  final _ctl = ItemScrollController();
  final _sw = Stopwatch()..start();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      settings.addSession();
      settings.setLastRead(widget.jumpTo ?? widget.ayat.first.g);
    });
    if (widget.jumpTo != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final i = _items().indexWhere((e) => e is Ayah && e.g == widget.jumpTo);
        if (i > 0 && _ctl.isAttached) _ctl.jumpTo(index: i);
      });
    }
  }

  @override
  void dispose() {
    final secs = _sw.elapsed.inSeconds;
    Future.microtask(() {
      settings.addSeconds(secs);
      AudioService.I.stop();
    });
    super.dispose();
  }

  List<Object> _items() {
    final out = <Object>[];
    for (final a in widget.ayat) {
      if (a.n == 1) out.add(QuranData.surah(a.sn));
      out.add(a);
    }
    return out;
  }

  String _copyText(Ayah a) => '${arabicText(a)}\n\n${a.i}\n(QS ${QuranData.surah(a.sn).en}: ${a.n})';

  void _toMushaf() {
    final g = settings.lastRead;
    final inList = widget.ayat.any((a) => a.g == g);
    final page = inList ? QuranData.byGlobal(g).p : widget.ayat.first.p;
    settings.update(() => settings.bookMode = true);
    Navigator.pushReplacement(context, smoothRoute(MushafReader(title: widget.title, startPage: page)));
  }

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final items = _items();
        return GlassScaffold(
          title: widget.title,
          actions: [
            IconButton(tooltip: 'Mode Mushaf', icon: Icon(Icons.menu_book_rounded, color: p.text), onPressed: _toMushaf),
          ],
          floating: _markButton(p),
          body: ScrollablePositionedList.builder(
            itemScrollController: _ctl,
            padding: const EdgeInsets.only(bottom: 110, top: 4),
            itemCount: items.length,
            itemBuilder: (ctx, i) {
              final it = items[i];
              return it is Surah ? _header(it, p) : _tile(it as Ayah, p);
            },
          ),
        );
      });

  Widget _markButton(AppPalette p) => ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: Material(
          color: p.accent,
          child: InkWell(
            onTap: () {
              final n = settings.markRead(widget.ayat.map((a) => a.g));
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(n > 0 ? '$n ayat ditandai selesai dibaca' : 'Sudah ditandai sebelumnya')));
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 13),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.check_circle_rounded, color: Colors.black87, size: 20),
                const SizedBox(width: 8),
                Text('Tandai selesai dibaca', style: uiStyle(14, Colors.black87, w: FontWeight.w700)),
              ]),
            ),
          ),
        ),
      );

  Widget _header(Surah s, AppPalette p) => GlassCard(
        blur: false,
        margin: const EdgeInsets.fromLTRB(16, 6, 16, 10),
        child: Column(children: [
          Text(s.arPlain, style: arabicStyle('Amiri Quran', 34, p.text)),
          Text('${s.en} • ${s.id}', style: uiStyle(14, p.text, w: FontWeight.w700)),
          Text('${s.type == 'Meccan' ? 'Makkiyah' : 'Madaniyah'} • ${s.ayat.length} ayat', style: uiStyle(12.5, p.sub)),
          if (s.n != 1 && s.n != 9) ...[
            const SizedBox(height: 10),
            Text(bismillah, textDirection: TextDirection.rtl, style: arabicStyle('Amiri Quran', 26, p.accent)),
          ],
        ]),
      );

  List<InlineSpan> _spans(Ayah a, TextStyle st) =>
      settings.tajwid ? tajwidSpans(arabicText(a), st) : [TextSpan(text: arabicText(a), style: st)];

  Widget _tile(Ayah a, AppPalette p) {
    final st = arabicStyle(settings.font, settings.arabSize, p.text);
    return ValueListenableBuilder<int?>(
      valueListenable: AudioService.I.current,
      builder: (ctx, cur, _) {
        final active = cur == a.g;
        final bm = settings.bookmarks.contains(a.g);
        return GlassCard(
          blur: false,
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
          onTap: () => settings.setLastRead(a.g),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                width: 34,
                height: 34,
                alignment: Alignment.center,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: p.accent, width: 1.4)),
                child: Text('${a.n}', style: uiStyle(12.5, p.accent, w: FontWeight.w700)),
              ),
              const Spacer(),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: Icon(active ? Icons.stop_circle_rounded : Icons.play_circle_outline_rounded, color: active ? p.accent : p.sub),
                onPressed: () {
                  final idx = widget.ayat.indexWhere((e) => e.g == a.g);
                  AudioService.I.toggle(widget.ayat, idx);
                },
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                tooltip: 'Tandai terakhir dibaca',
                icon: Icon(settings.marker == a.g ? Icons.flag_rounded : Icons.outlined_flag_rounded,
                    color: settings.marker == a.g ? p.accent : p.sub),
                onPressed: () => settings.marker == a.g ? settings.clearMarker() : settings.setMarker(a.g),
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: Icon(bm ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, color: bm ? p.accent : p.sub),
                onPressed: () => settings.toggleBookmark(a.g),
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: Icon(Icons.copy_rounded, color: p.sub, size: 20),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: _copyText(a)));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ayat disalin')));
                },
              ),
            ]),
            if (settings.showArabic)
              SizedBox(
                width: double.infinity,
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Text.rich(TextSpan(children: _spans(a, st)), textAlign: TextAlign.right),
                ),
              ),
            if (settings.showTranslit) ...[
              const SizedBox(height: 8),
              Text(a.t, style: uiStyle(settings.textSize - 1, p.accent, w: FontWeight.w500, height: 1.5)),
            ],
            if (settings.showTranslation) ...[
              const SizedBox(height: 8),
              Text(a.i, style: uiStyle(settings.textSize, p.text, w: FontWeight.w400, height: 1.55)),
            ],
            if (settings.showTafsir) ...[
              const SizedBox(height: 10),
              Text('Tafsir Jalalayn', style: uiStyle(12, p.sub, w: FontWeight.w700)),
              const SizedBox(height: 3),
              Text(a.k, style: uiStyle(settings.textSize - 1.5, p.sub, w: FontWeight.w400, height: 1.5)),
            ],
          ]),
        );
      },
    );
  }
}
