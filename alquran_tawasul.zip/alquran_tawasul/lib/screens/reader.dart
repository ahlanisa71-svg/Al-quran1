import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import '../core/core.dart';

void openSurah(BuildContext ctx, Surah s, {int? jumpTo}) {
  if (settings.bookMode) {
    final page = QuranData.byGlobal(jumpTo ?? s.ayat.first.g).p;
    Navigator.push(ctx, smoothRoute(MushafReader(title: s.en, startPage: page)));
  } else {
    Navigator.push(ctx, smoothRoute(ReaderPage(title: s.en, ayat: s.ayat, jumpTo: jumpTo)));
  }
}

void openJuz(BuildContext ctx, int j, {int? jumpTo}) {
  if (settings.bookMode) {
    final page = QuranData.byGlobal(jumpTo ?? QuranData.juzStart(j).g).p;
    Navigator.push(ctx, smoothRoute(MushafReader(title: 'Juz $j', startPage: page)));
  } else {
    Navigator.push(ctx, smoothRoute(ReaderPage(title: 'Juz $j', ayat: QuranData.juz(j), jumpTo: jumpTo)));
  }
}

const _juzNames = [
  'الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع', 'العاشر',
  'الحادي عشر', 'الثاني عشر', 'الثالث عشر', 'الرابع عشر', 'الخامس عشر', 'السادس عشر', 'السابع عشر',
  'الثامن عشر', 'التاسع عشر', 'العشرون', 'الحادي والعشرون', 'الثاني والعشرون', 'الثالث والعشرون',
  'الرابع والعشرون', 'الخامس والعشرون', 'السادس والعشرون', 'السابع والعشرون', 'الثامن والعشرون',
  'التاسع والعشرون', 'الثلاثون',
];

// ═════════════════════════ MODE MUSHAF (tampilan halaman Utsmani, 15 baris rata penuh) ═════════════════════════
class MushafReader extends StatefulWidget {
  final String title;
  final int startPage;
  const MushafReader({super.key, required this.title, required this.startPage});
  @override
  State<MushafReader> createState() => _MushafReaderState();
}

class _MushafReaderState extends State<MushafReader> {
  late final PageController _pc = PageController(initialPage: widget.startPage - 1);
  late int _page = widget.startPage;
  final _sw = Stopwatch()..start();
  late final Future<void> _font = _loadFont();

  Future<void> _loadFont() async {
    try {
      await GoogleFonts.pendingFonts([GoogleFonts.getFont(settings.font), GoogleFonts.getFont('Amiri Quran')]);
    } catch (_) {}
    _w20.clear();
    _fontEpoch++;
    // tunggu animasi pindah layar selesai sebelum menyusun halaman (yang berat) agar tidak patah-patah
    await Future.delayed(const Duration(milliseconds: 400));
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      settings.addSession();
      _remember(_page);
    });
  }

  void _remember(int page) {
    final l = QuranData.pages[page];
    if (l != null && l.isNotEmpty) settings.setLastRead(l.first.g);
  }

  @override
  void dispose() {
    final secs = _sw.elapsed.inSeconds;
    _pc.dispose();
    Future.microtask(() {
      settings.addSeconds(secs);
      AudioService.I.stop();
    });
    super.dispose();
  }

  void _toList() {
    final l = QuranData.pages[_page] ?? const <Ayah>[];
    if (l.isEmpty) return;
    final s = QuranData.surah(l.first.sn);
    settings.update(() => settings.bookMode = false);
    Navigator.pushReplacement(context, smoothRoute(ReaderPage(title: s.en, ayat: s.ayat, jumpTo: l.first.g)));
  }

  Widget _circleBtn(AppPalette p, IconData i, String tip, VoidCallback f, {Color? color}) => IconButton(
        tooltip: tip,
        visualDensity: VisualDensity.compact,
        icon: Icon(i, color: color ?? p.text, size: 22),
        onPressed: f,
      );

  Widget _header(AppPalette p, List<Ayah> l) {
    final s = l.isEmpty ? null : QuranData.surah(l.last.sn);
    final marked = l.any((a) => a.g == settings.marker);
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 6, 6, 6),
      child: Row(children: [
        ClipOval(
          child: Material(
            color: p.glass,
            child: InkWell(
              onTap: () => Navigator.maybePop(context),
              child: SizedBox(width: 40, height: 40, child: Icon(Icons.arrow_back_rounded, color: p.text, size: 22)),
            ),
          ),
        ),
        Expanded(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(s == null ? widget.title : s.arPlain,
                style: arabicStyle('Amiri Quran', 24, p.text, height: 1.3)),
            if (s != null)
              Text('الصفحة ${arNum(_page)} • الجزء ${arNum(l.last.j)} • ${arNum(s.ayat.length)} آية',
                  textDirection: TextDirection.rtl, style: arabicStyle('Amiri', 12.5, p.sub, height: 1.3)),
          ]),
        ),
        _circleBtn(p, marked ? Icons.flag_rounded : Icons.outlined_flag_rounded, 'Tandai terakhir dibaca', () {
          if (l.isEmpty) return;
          settings.setMarker(l.first.g);
          final sr = QuranData.surah(l.first.sn);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Penanda terakhir dibaca: ${sr.en} ayat ${l.first.n}. Ketuk ayat lain untuk memindahkan.')));
        }, color: marked ? p.accent : null),
        _circleBtn(p, Icons.check_circle_outline_rounded, 'Tandai halaman selesai dibaca', () {
          final n = settings.markRead(l.map((a) => a.g));
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(n > 0 ? '$n ayat ditandai selesai dibaca' : 'Halaman ini sudah ditandai')));
        }),
        _circleBtn(p, Icons.view_agenda_rounded, 'Mode Daftar', _toList),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final l = QuranData.pages[_page] ?? const <Ayah>[];
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: p.dark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
          child: AppBackground(
            child: Scaffold(
              backgroundColor: Colors.transparent,
              body: SafeArea(
                child: Column(children: [
                  _header(p, l),
                  Expanded(
                    child: FutureBuilder<void>(
                      future: _font,
                      builder: (ctx, snap) {
                        final ready = snap.connectionState == ConnectionState.done;
                        return AnimatedSwitcher(
                          duration: const Duration(milliseconds: 260),
                          child: !ready
                              ? const SizedBox.expand(key: ValueKey('wait'))
                              : PageView.builder(
                                  key: const ValueKey('pages'),
                                  reverse: true,
                                  controller: _pc,
                                  physics: const BouncingScrollPhysics(),
                                  itemCount: 604,
                                  onPageChanged: (i) {
                                    setState(() => _page = i + 1);
                                    _remember(i + 1);
                                  },
                                  itemBuilder: (ctx, i) => MushafPage(key: ValueKey('p$i'), page: i + 1),
                                ),
                        );
                      },
                    ),
                  ),
                ]),
              ),
            ),
          ),
        );
      });
}

// ---------- mesin tata letak: pecah kata menjadi baris yang rata penuh ----------
class _Tok {
  final String t;
  final Ayah a;
  final bool mark;
  _Tok(this.t, this.a, this.mark);
}

class _TextSeg {
  final List<_Tok> toks = [];
  bool endsSurah = false;
}

class _Line {
  final Surah? banner; // baris banner nama surah
  final Surah? bism; // baris bismillah
  final List<_Tok> toks;
  final bool justify;
  _Line({this.banner, this.bism, this.toks = const [], this.justify = true});
}

class _Layout {
  final double size, lineH;
  final List<_Line> lines;
  final bool overflow;
  _Layout(this.size, this.lineH, this.lines, this.overflow);
}

final Map<String, double> _w20 = {};
int _fontEpoch = 0;

double _widthAt20(String word) {
  final key = '${settings.font}|$word';
  return _w20.putIfAbsent(key, () {
    final tp = TextPainter(
      text: TextSpan(text: word, style: arabicStyle(settings.font, 20, Colors.black, height: 1.5)),
      textDirection: TextDirection.rtl,
      textScaler: TextScaler.noScaling,
    )..layout();
    final w = tp.width;
    tp.dispose();
    return w;
  });
}

List<double> _widths(List<_Tok> toks, double size) =>
    [for (final t in toks) t.mark ? size * 1.08 : _widthAt20(t.t) * size / 20 * 1.012];

double _lineWidth(List<double> w, int i, int j, double gap) {
  double s = 0;
  for (int k = i; k < j; k++) {
    s += w[k];
  }
  return s + gap * (j - i - 1);
}

List<int> _greedy(List<double> w, double W, double gap) {
  final starts = <int>[0];
  double cur = 0;
  int cnt = 0;
  for (int i = 0; i < w.length; i++) {
    final add = cnt == 0 ? w[i] : gap + w[i];
    if (cnt > 0 && cur + add > W) {
      starts.add(i);
      cur = w[i];
      cnt = 1;
    } else {
      cur += add;
      cnt++;
    }
  }
  return starts;
}

/// Pecah ke tepat [L] baris dengan sisa ruang (slack) sekecil mungkin. null jika mustahil.
List<int>? _balanced(List<double> w, double W, double gap, int L, bool freeLast) {
  final n = w.length;
  if (n == 0) return [0];
  if (L > n) L = n;
  const inf = 1e18;
  final dp = List.generate(L + 1, (_) => List<double>.filled(n + 1, inf));
  final cut = List.generate(L + 1, (_) => List<int>.filled(n + 1, 0));
  dp[0][0] = 0;
  for (int k = 1; k <= L; k++) {
    for (int j = k; j <= n; j++) {
      for (int i = j - 1; i >= k - 1; i--) {
        final width = _lineWidth(w, i, j, gap);
        if (width > W) break;
        if (dp[k - 1][i] >= inf) continue;
        final last = k == L && j == n;
        final slack = W - width;
        final cost = dp[k - 1][i] + ((last && freeLast) ? 0 : slack * slack);
        if (cost < dp[k][j]) {
          dp[k][j] = cost;
          cut[k][j] = i;
        }
      }
    }
  }
  if (dp[L][n] >= inf) return null;
  final starts = List<int>.filled(L, 0);
  int j = n;
  for (int k = L; k >= 1; k--) {
    starts[k - 1] = cut[k][j];
    j = cut[k][j];
  }
  return starts;
}

class MushafPage extends StatefulWidget {
  final int page;
  const MushafPage({super.key, required this.page});
  @override
  State<MushafPage> createState() => _MushafPageState();
}

class _MushafPageState extends State<MushafPage> {
  String _key = '';
  _Layout? _lay;

  bool _hasBism(Surah s) => s.n != 1 && s.n != 9;

  _Layout _compute(double W, double H, List<Ayah> ayat) {
    final page = widget.page;
    // 1. segmen
    final order = <Object>[]; // Surah | _TextSeg
    _TextSeg? cur;
    for (final a in ayat) {
      if (a.n == 1) {
        cur = null;
        order.add(QuranData.surah(a.sn));
      }
      if (cur == null) {
        cur = _TextSeg();
        order.add(cur);
      }
      for (final w in arabicText(a).split(' ')) {
        if (w.trim().isNotEmpty) cur.toks.add(_Tok(w, a, false));
      }
      cur.toks.add(_Tok('', a, true));
      cur.endsSurah = a.n == QuranData.surah(a.sn).ayat.length;
    }
    final segs = order.whereType<_TextSeg>().toList();
    final fixed = order.whereType<Surah>().fold<int>(0, (n, s) => n + 1 + (_hasBism(s) ? 1 : 0));
    int K = page <= 2 ? 5 : 15 - fixed;
    if (K < segs.length) K = segs.length;

    // 2. bagi jumlah baris ke tiap segmen sesuai jumlah kata
    final total = segs.fold<int>(0, (n, s) => n + s.toks.length).clamp(1, 1 << 30).toInt();
    final alloc = [for (final sg in segs) (K * sg.toks.length / total).round().clamp(1, K).toInt()];
    int diff = K - alloc.fold<int>(0, (a, b) => a + b);
    while (diff != 0 && segs.isNotEmpty) {
      int idx = 0;
      for (int i = 1; i < alloc.length; i++) {
        if ((diff > 0 && segs[i].toks.length > segs[idx].toks.length) ||
            (diff < 0 && alloc[i] > alloc[idx])) {
          idx = i;
        }
      }
      if (diff > 0) {
        alloc[idx]++;
        diff--;
      } else if (alloc[idx] > 1) {
        alloc[idx]--;
        diff++;
      } else {
        break;
      }
    }

    final rows = page <= 2 ? (fixed + K + 3) : 15;
    final lineH = H / rows;
    final sizeMax = (lineH / 1.3).clamp(10.0, 46.0).toDouble();
    final Wc = W * 0.996;

    bool feasible(double size) {
      final gap = size * 0.2;
      for (int j = 0; j < segs.length; j++) {
        final w = _widths(segs[j].toks, size);
        if (_balanced(w, Wc, gap, alloc[j], segs[j].endsSurah) == null) return false;
      }
      return true;
    }

    double size = sizeMax;
    bool overflow = false;
    if (!feasible(sizeMax)) {
      double lo = 10, hi = sizeMax;
      if (!feasible(lo)) {
        size = lo;
        overflow = true;
      } else {
        for (int i = 0; i < 9; i++) {
          final mid = (lo + hi) / 2;
          if (feasible(mid)) {
            lo = mid;
          } else {
            hi = mid;
          }
        }
        size = lo;
      }
    }

    // 3. susun baris
    final gap = size * 0.2;
    // Jika huruf sudah mentok besar tetapi teks masih sedikit, kurangi jumlah baris
    // agar tiap baris terisi >= 90% dan jarak antar kata tidak melebar.
    final eff = List<int>.from(alloc);
    if (!overflow && size == sizeMax) {
      for (int j = 0; j < segs.length; j++) {
        final w = _widths(segs[j].toks, size);
        final tot = _lineWidth(w, 0, w.length, gap);
        final need = (tot / (Wc * 0.9)).ceil();
        final gl = _greedy(w, Wc, gap).length;
        final want = need > gl ? need : gl;
        eff[j] = want < alloc[j] ? want : alloc[j];
      }
    }
    final lines = <_Line>[];
    int segIdx = 0;
    for (final it in order) {
      if (it is Surah) {
        lines.add(_Line(banner: it));
        if (_hasBism(it)) lines.add(_Line(bism: it));
      } else {
        final sg = it as _TextSeg;
        final w = _widths(sg.toks, size);
        List<int> starts;
        final g = _greedy(w, Wc, gap);
        if (overflow) {
          starts = g;
        } else if (g.length >= eff[segIdx]) {
          starts = _balanced(w, Wc, gap, eff[segIdx], sg.endsSurah) ?? g;
        } else {
          starts = _balanced(w, Wc, gap, eff[segIdx], sg.endsSurah) ?? g;
        }
        for (int li = 0; li < starts.length; li++) {
          final from = starts[li];
          final to = li + 1 < starts.length ? starts[li + 1] : sg.toks.length;
          final isLast = li == starts.length - 1;
          bool justify = true;
          if (isLast && sg.endsSurah) {
            justify = _lineWidth(w, from, to, gap) >= Wc * 0.9;
          }
          lines.add(_Line(toks: sg.toks.sublist(from, to), justify: justify));
        }
        segIdx++;
      }
    }
    return _Layout(size, lineH, lines, overflow || lines.length > rows);
  }

  void _sheet(Ayah a, AppPalette p0) {
    final s = QuranData.surah(a.sn);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: p0.bg[1],
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => sb((c, p) => SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(22, 20, 22, 18),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${s.en} : ${a.n}', style: uiStyle(16, p.text, w: FontWeight.w700)),
                Text('Juz ${a.j} • Halaman ${a.p}', style: uiStyle(12.5, p.sub)),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Text(arabicText(a), textAlign: TextAlign.right, style: arabicStyle(settings.font, 28, p.text)),
                  ),
                ),
                const SizedBox(height: 10),
                Text(a.t, style: uiStyle(13.5, p.accent, height: 1.5)),
                const SizedBox(height: 8),
                Text(a.i, style: uiStyle(14.5, p.text, w: FontWeight.w400, height: 1.55)),
                if (settings.showTafsir) ...[
                  const SizedBox(height: 10),
                  Text('Tafsir Jalalayn', style: uiStyle(12, p.sub, w: FontWeight.w700)),
                  Text(a.k, style: uiStyle(13, p.sub, w: FontWeight.w400, height: 1.5)),
                ],
                const SizedBox(height: 14),
                ValueListenableBuilder<int?>(
                  valueListenable: AudioService.I.current,
                  builder: (_, cur, __) => Row(children: [
                    _SheetBtn(cur == a.g ? Icons.stop_circle_rounded : Icons.play_circle_rounded, cur == a.g ? 'Berhenti' : 'Putar',
                        p, () => AudioService.I.toggle([a], 0)),
                    _SheetBtn(settings.marker == a.g ? Icons.flag_rounded : Icons.outlined_flag_rounded, 'Terakhir dibaca', p, () {
                      settings.marker == a.g ? settings.clearMarker() : settings.setMarker(a.g);
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text(settings.marker == a.g ? 'Penanda terakhir dibaca disimpan' : 'Penanda dihapus')));
                    }),
                    _SheetBtn(settings.bookmarks.contains(a.g) ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, 'Bookmark',
                        p, () => settings.toggleBookmark(a.g)),
                    _SheetBtn(Icons.copy_rounded, 'Salin', p, () {
                      Clipboard.setData(ClipboardData(text: '${arabicText(a)}\n\n${a.i}\n(QS ${s.en}: ${a.n})'));
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ayat disalin')));
                    }),
                  ]),
                ),
              ]),
            ),
          )),
    );
  }

  Widget _tok(_Tok t, double size, AppPalette p, TextStyle st) {
    if (t.mark) {
      return GestureDetector(
        onTap: () => _sheet(t.a, p),
        child: SizedBox(
          width: size * 1.08,
          height: size * 1.08,
          child: CustomPaint(
            painter: AyahMarkPainter(goldOf(p)),
            child: Center(
              child: Padding(
                padding: EdgeInsets.all(size * 0.17),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(arNum(t.a.n), style: arabicStyle('Amiri Quran', size * 0.46, p.text, height: 1.0)),
                ),
              ),
            ),
          ),
        ),
      );
    }
    Widget w = settings.tajwid
        ? Text.rich(TextSpan(children: tajwidSpans(t.t, st)), softWrap: false, textScaler: TextScaler.noScaling)
        : Text(t.t, style: st, softWrap: false, maxLines: 1, textScaler: TextScaler.noScaling);
    // lebar dikunci sesuai hasil ukur; jika huruf sedikit lebih lebar, dikecilkan (tidak pernah menimpa kata lain)
    w = SizedBox(
      width: _widthAt20(t.t) * size / 20 * 1.012,
      child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.center, child: w),
    );
    if (t.a.g == settings.marker) {
      w = DecoratedBox(
        decoration: BoxDecoration(color: goldOf(p).withValues(alpha: 0.30), borderRadius: BorderRadius.circular(4)),
        child: w,
      );
    }
    return GestureDetector(behavior: HitTestBehavior.translucent, onTap: () => _sheet(t.a, p), child: w);
  }

  Widget _lineW(_Line ln, _Layout lay, AppPalette p, TextStyle st, double W) {
    final size = lay.size;
    if (ln.banner != null) {
      return Padding(
        padding: EdgeInsets.symmetric(vertical: lay.lineH * 0.08),
        child: CustomPaint(
          painter: OrnamentBarPainter(goldOf(p), bold: true),
          child: Center(
            child: Text('سورة ${ln.banner!.arPlain}', style: arabicStyle(settings.font, size * 0.95, p.text, height: 1.2)),
          ),
        ),
      );
    }
    if (ln.bism != null) {
      return Center(
        child: Text(bismillah, textDirection: TextDirection.rtl, style: arabicStyle(settings.font, size * 0.95, p.text, height: 1.4)),
      );
    }
    final kids = [for (final t in ln.toks) _tok(t, size, p, st)];
    if (ln.justify) {
      return Row(textDirection: TextDirection.rtl, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: kids);
    }
    return Row(textDirection: TextDirection.rtl, mainAxisAlignment: MainAxisAlignment.center, children: [
      for (int i = 0; i < kids.length; i++) ...[if (i > 0) SizedBox(width: size * 0.2), kids[i]],
    ]);
  }

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final ayat = QuranData.pages[widget.page] ?? const <Ayah>[];
        if (ayat.isEmpty) return const SizedBox();
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
          child: Column(children: [
            Expanded(
              child: LayoutBuilder(builder: (ctx, box) {
                final key = '${widget.page}|${box.maxWidth.round()}|${box.maxHeight.round()}|${settings.font}|${settings.arabSize}|$_fontEpoch';
                if (key != _key || _lay == null) {
                  _lay = _compute(box.maxWidth, box.maxHeight, ayat);
                  _key = key;
                }
                final lay = _lay!;
                final st = arabicStyle(settings.font, lay.size, p.text, height: 1.5);
                final col = Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (final ln in lay.lines) SizedBox(height: lay.lineH, width: box.maxWidth, child: _lineW(ln, lay, p, st, box.maxWidth)),
                  ],
                );
                if (lay.overflow) {
                  return SingleChildScrollView(physics: const ClampingScrollPhysics(), child: col);
                }
                return widget.page <= 2 ? Center(child: col) : Align(alignment: Alignment.topCenter, child: col);
              }),
            ),
            const SizedBox(height: 4),
            Text(arNum(widget.page), style: arabicStyle('Amiri Quran', 15, p.sub, height: 1.2)),
          ]),
        );
      });
}

class _SheetBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final AppPalette p;
  final VoidCallback onTap;
  const _SheetBtn(this.icon, this.label, this.p, this.onTap);
  @override
  Widget build(BuildContext context) => Expanded(
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(children: [
              Icon(icon, color: p.accent, size: 28),
              const SizedBox(height: 2),
              Text(label, style: uiStyle(12, p.text)),
            ]),
          ),
        ),
      );
}

// ═════════════════════════ MODE DAFTAR (ayat + terjemahan) ═════════════════════════
class ReaderPage extends StatefulWidget {
  final String title;
  final List<Ayah> ayat;
  final int? jumpTo;
  const ReaderPage({super.key, required this.title, required this.ayat, this.jumpTo});

  @override
  State<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends State<ReaderPage> {
  final _ctl = ItemScrollController();
  final _sw = Stopwatch()..start();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      settings.addSession();
      settings.setLastRead(widget.jumpTo ?? widget.ayat.first.g);
    });
    if (widget.jumpTo != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final i = _items().indexWhere((e) => e is Ayah && e.g == widget.jumpTo);
        if (i > 0 && _ctl.isAttached) _ctl.jumpTo(index: i);
      });
    }
  }

  @override
  void dispose() {
    final secs = _sw.elapsed.inSeconds;
    Future.microtask(() {
      settings.addSeconds(secs);
      AudioService.I.stop();
    });
    super.dispose();
  }

  List<Object> _items() {
    final out = <Object>[];
    for (final a in widget.ayat) {
      if (a.n == 1) out.add(QuranData.surah(a.sn));
      out.add(a);
    }
    return out;
  }

  String _copyText(Ayah a) => '${arabicText(a)}\n\n${a.i}\n(QS ${QuranData.surah(a.sn).en}: ${a.n})';

  void _toMushaf() {
    final g = settings.lastRead;
    final inList = widget.ayat.any((a) => a.g == g);
    final page = inList ? QuranData.byGlobal(g).p : widget.ayat.first.p;
    settings.update(() => settings.bookMode = true);
    Navigator.pushReplacement(context, smoothRoute(MushafReader(title: widget.title, startPage: page)));
  }

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final items = _items();
        return GlassScaffold(
          title: widget.title,
          actions: [
            IconButton(tooltip: 'Mode Mushaf', icon: Icon(Icons.menu_book_rounded, color: p.text), onPressed: _toMushaf),
          ],
          floating: _markButton(p),
          body: ScrollablePositionedList.builder(
            itemScrollController: _ctl,
            padding: const EdgeInsets.only(bottom: 110, top: 4),
            itemCount: items.length,
            itemBuilder: (ctx, i) {
              final it = items[i];
              return it is Surah ? _header(it, p) : _tile(it as Ayah, p);
            },
          ),
        );
      });

  Widget _markButton(AppPalette p) => ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: Material(
          color: p.accent,
          child: InkWell(
            onTap: () {
              final n = settings.markRead(widget.ayat.map((a) => a.g));
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(n > 0 ? '$n ayat ditandai selesai dibaca' : 'Sudah ditandai sebelumnya')));
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 13),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.check_circle_rounded, color: Colors.black87, size: 20),
                const SizedBox(width: 8),
                Text('Tandai selesai dibaca', style: uiStyle(14, Colors.black87, w: FontWeight.w700)),
              ]),
            ),
          ),
        ),
      );

  Widget _header(Surah s, AppPalette p) => GlassCard(
        margin: const EdgeInsets.fromLTRB(16, 6, 16, 10),
        child: Column(children: [
          Text(s.arPlain, style: arabicStyle('Amiri Quran', 34, p.text)),
          Text('${s.en} • ${s.id}', style: uiStyle(14, p.text, w: FontWeight.w700)),
          Text('${s.type == 'Meccan' ? 'Makkiyah' : 'Madaniyah'} • ${s.ayat.length} ayat', style: uiStyle(12.5, p.sub)),
          if (s.n != 1 && s.n != 9) ...[
            const SizedBox(height: 10),
            Text(bismillah, textDirection: TextDirection.rtl, style: arabicStyle('Amiri Quran', 26, p.accent)),
          ],
        ]),
      );

  List<InlineSpan> _spans(Ayah a, TextStyle st) =>
      settings.tajwid ? tajwidSpans(arabicText(a), st) : [TextSpan(text: arabicText(a), style: st)];

  Widget _tile(Ayah a, AppPalette p) {
    final st = arabicStyle(settings.font, settings.arabSize, p.text);
    return ValueListenableBuilder<int?>(
      valueListenable: AudioService.I.current,
      builder: (ctx, cur, _) {
        final active = cur == a.g;
        final bm = settings.bookmarks.contains(a.g);
        return GlassCard(
          blur: false,
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
          onTap: () => settings.setLastRead(a.g),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                width: 34,
                height: 34,
                alignment: Alignment.center,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: p.accent, width: 1.4)),
                child: Text('${a.n}', style: uiStyle(12.5, p.accent, w: FontWeight.w700)),
              ),
              const Spacer(),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: Icon(active ? Icons.stop_circle_rounded : Icons.play_circle_outline_rounded, color: active ? p.accent : p.sub),
                onPressed: () {
                  final idx = widget.ayat.indexWhere((e) => e.g == a.g);
                  AudioService.I.toggle(widget.ayat, idx);
                },
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                tooltip: 'Tandai terakhir dibaca',
                icon: Icon(settings.marker == a.g ? Icons.flag_rounded : Icons.outlined_flag_rounded,
                    color: settings.marker == a.g ? p.accent : p.sub),
                onPressed: () => settings.marker == a.g ? settings.clearMarker() : settings.setMarker(a.g),
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: Icon(bm ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, color: bm ? p.accent : p.sub),
                onPressed: () => settings.toggleBookmark(a.g),
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: Icon(Icons.copy_rounded, color: p.sub, size: 20),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: _copyText(a)));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ayat disalin')));
                },
              ),
            ]),
            if (settings.showArabic)
              SizedBox(
                width: double.infinity,
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Text.rich(TextSpan(children: _spans(a, st)), textAlign: TextAlign.right),
                ),
              ),
            if (settings.showTranslit) ...[
              const SizedBox(height: 8),
              Text(a.t, style: uiStyle(settings.textSize - 1, p.accent, w: FontWeight.w500, height: 1.5)),
            ],
            if (settings.showTranslation) ...[
              const SizedBox(height: 8),
              Text(a.i, style: uiStyle(settings.textSize, p.text, w: FontWeight.w400, height: 1.55)),
            ],
            if (settings.showTafsir) ...[
              const SizedBox(height: 10),
              Text('Tafsir Jalalayn', style: uiStyle(12, p.sub, w: FontWeight.w700)),
              const SizedBox(height: 3),
              Text(a.k, style: uiStyle(settings.textSize - 1.5, p.sub, w: FontWeight.w400, height: 1.5)),
            ],
          ]),
        );
      },
    );
  }
}
