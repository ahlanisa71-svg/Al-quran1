import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/core.dart';

class TItem {
  String id, title, text, font;
  double size, height;
  int align; // 0 kanan, 1 tengah
  int color; // 0 = otomatis
  TItem({required this.id, this.title = '', this.text = '', this.font = 'Amiri Quran', this.size = 28,
      this.height = 2.0, this.align = 0, this.color = 0});
  Map<String, dynamic> toJson() =>
      {'id': id, 'title': title, 'text': text, 'font': font, 'size': size, 'height': height, 'align': align, 'color': color};
  factory TItem.fromJson(Map<String, dynamic> m) => TItem(
      id: m['id'], title: m['title'] ?? '', text: m['text'] ?? '', font: m['font'] ?? 'Amiri Quran',
      size: (m['size'] ?? 28).toDouble(), height: (m['height'] ?? 2.0).toDouble(), align: m['align'] ?? 0, color: m['color'] ?? 0);
}

class TFolder {
  String id, name;
  List<TItem> items;
  TFolder(this.id, this.name, this.items);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'items': items.map((e) => e.toJson()).toList()};
  factory TFolder.fromJson(Map<String, dynamic> m) =>
      TFolder(m['id'], m['name'], (m['items'] as List).map((e) => TItem.fromJson(e)).toList());
}

class TawasulStore extends ChangeNotifier {
  List<TFolder> folders = [];
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    try {
      folders = (jsonDecode(p.getString('tawasul_v1') ?? '[]') as List).map((e) => TFolder.fromJson(e)).toList();
    } catch (_) {
      folders = [];
    }
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('tawasul_v1', jsonEncode(folders.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  String newId() => DateTime.now().microsecondsSinceEpoch.toString();
}

final tawasul = TawasulStore();

Widget tb(Widget Function(BuildContext, AppPalette) f) => ListenableBuilder(
    listenable: Listenable.merge([settings, tawasul]), builder: (c, _) => f(c, settings.pal));

Future<String?> _askText(BuildContext ctx, String title, {String initial = '', String hint = ''}) {
  final ctl = TextEditingController(text: initial);
  return showDialog<String>(
    context: ctx,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: TextField(controller: ctl, autofocus: true, decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('Batal')),
        FilledButton(onPressed: () => Navigator.pop(c, ctl.text.trim()), child: const Text('Simpan')),
      ],
    ),
  );
}

Future<bool> _confirm(BuildContext ctx, String msg) async =>
    await showDialog<bool>(
      context: ctx,
      builder: (c) => AlertDialog(
        title: const Text('Hapus?'),
        content: Text(msg),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Hapus')),
        ],
      ),
    ) ??
    false;

class TawasulTab extends StatelessWidget {
  const TawasulTab({super.key});

  @override
  Widget build(BuildContext context) => tb((c, p) => SafeArea(
        bottom: false,
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 14, 12, 6),
            child: Row(children: [
              Expanded(child: Text('Tawasul', style: uiStyle(24, p.text, w: FontWeight.w700))),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: Colors.black87),
                onPressed: () async {
                  final n = await _askText(context, 'Buat buku / folder baru', hint: 'Nama buku');
                  if (n != null && n.isNotEmpty) {
                    tawasul.folders.add(TFolder(tawasul.newId(), n, []));
                    tawasul.save();
                  }
                },
                icon: const Icon(Icons.create_new_folder_rounded, size: 20),
                label: const Text('Buku baru'),
              ),
            ]),
          ),
          Expanded(
            child: tawasul.folders.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Text(
                          'Belum ada buku.\nBuat buku baru, lalu isi dengan teks tawasul / doa secara manual.',
                          textAlign: TextAlign.center,
                          style: uiStyle(14, p.sub, w: FontWeight.w400, height: 1.6)),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: navPad),
                    itemCount: tawasul.folders.length,
                    itemBuilder: (ctx, i) {
                      final f = tawasul.folders[i];
                      return GlassCard(
                        blur: false,
                        onTap: () => Navigator.push(ctx, smoothRoute(FolderPage(f))),
                        child: Row(children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: p.accent.withValues(alpha: 0.18)),
                            child: Icon(Icons.menu_book_rounded, color: p.accent),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(f.name, style: uiStyle(16, p.text, w: FontWeight.w700)),
                              Text('${f.items.length} tulisan', style: uiStyle(12.5, p.sub)),
                            ]),
                          ),
                          PopupMenuButton<String>(
                            icon: Icon(Icons.more_vert_rounded, color: p.sub),
                            onSelected: (v) async {
                              if (v == 'rename') {
                                final n = await _askText(ctx, 'Ubah nama buku', initial: f.name);
                                if (n != null && n.isNotEmpty) {
                                  f.name = n;
                                  tawasul.save();
                                }
                              } else if (v == 'del' && await _confirm(ctx, 'Hapus buku "${f.name}" beserta isinya?')) {
                                tawasul.folders.remove(f);
                                tawasul.save();
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'rename', child: Text('Ubah nama')),
                              PopupMenuItem(value: 'del', child: Text('Hapus')),
                            ],
                          ),
                        ]),
                      );
                    },
                  ),
          ),
        ]),
      ));
}

class FolderPage extends StatelessWidget {
  final TFolder folder;
  const FolderPage(this.folder, {super.key});

  @override
  Widget build(BuildContext context) => tb((c, p) => GlassScaffold(
        title: folder.name,
        actions: [
          IconButton(
            icon: Icon(Icons.add_circle_rounded, color: p.accent, size: 30),
            tooltip: 'Tambah tulisan',
            onPressed: () {
              final it = TItem(id: tawasul.newId());
              Navigator.push(context, smoothRoute(EditorPage(folder, it, isNew: true)));
            },
          ),
        ],
        body: folder.items.isEmpty
            ? Center(
                child: Text('Belum ada tulisan.\nTekan + untuk menambah.',
                    textAlign: TextAlign.center, style: uiStyle(14, p.sub, w: FontWeight.w400, height: 1.6)))
            : ListView.builder(
                padding: const EdgeInsets.only(bottom: 40),
                itemCount: folder.items.length,
                itemBuilder: (ctx, i) {
                  final it = folder.items[i];
                  return GlassCard(
                    blur: false,
                    onTap: () => Navigator.push(ctx, smoothRoute(ViewerPage(folder, it))),
                    child: Row(children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(it.title.isEmpty ? 'Tanpa judul' : it.title, style: uiStyle(15, p.text, w: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text(it.text, maxLines: 1, overflow: TextOverflow.ellipsis,
                              textDirection: TextDirection.rtl, style: arabicStyle(it.font, 18, p.sub, height: 1.5)),
                        ]),
                      ),
                      IconButton(
                        icon: Icon(Icons.delete_outline_rounded, color: p.sub),
                        onPressed: () async {
                          if (await _confirm(ctx, 'Hapus tulisan ini?')) {
                            folder.items.remove(it);
                            tawasul.save();
                          }
                        },
                      ),
                    ]),
                  );
                },
              ),
      ));
}

const _colors = <int>[
  0, 0xFFFFFFFF, 0xFFFFD369, 0xFF4ADE9C, 0xFF7DB8FF, 0xFFFF8A80, 0xFFE0C3FF,
  0xFF111111, 0xFF0F5A45, 0xFF1D4ED8, 0xFF9B1C1C, 0xFF6B3E26, 0xFF6D28D9,
];

double _contrast(Color a, Color b) {
  final l1 = a.computeLuminance(), l2 = b.computeLuminance();
  final hi = l1 > l2 ? l1 : l2, lo = l1 > l2 ? l2 : l1;
  return (hi + 0.05) / (lo + 0.05);
}

/// Warna yang cukup kontras dengan latar tema saat ini.
bool _readable(int col, AppPalette p) => col == 0 || _contrast(Color(col), p.bg[1]) >= 4.0;

/// Warna pilihan dipakai bila terbaca di tema aktif; jika tidak, otomatis ikut warna teks tema.
Color _itemColor(TItem it, AppPalette p) => _readable(it.color, p) && it.color != 0 ? Color(it.color) : p.text;

class ViewerPage extends StatelessWidget {
  final TFolder folder;
  final TItem item;
  const ViewerPage(this.folder, this.item, {super.key});

  @override
  Widget build(BuildContext context) => tb((c, p) => GlassScaffold(
        title: item.title.isEmpty ? 'Tulisan' : item.title,
        actions: [
          IconButton(
            icon: Icon(Icons.copy_rounded, color: p.text),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: item.text));
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Teks disalin')));
            },
          ),
          IconButton(
            icon: Icon(Icons.edit_rounded, color: p.text),
            onPressed: () => Navigator.push(context, smoothRoute(EditorPage(folder, item))),
          ),
        ],
        body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
          GlassCard(
            child: SizedBox(
              width: double.infinity,
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Text(item.text,
                    textAlign: item.align == 1 ? TextAlign.center : TextAlign.right,
                    style: arabicStyle(item.font, item.size, _itemColor(item, p), height: item.height)),
              ),
            ),
          ),
        ]),
      ));
}

class FontPickerList extends StatelessWidget {
  final String selected;
  final ValueChanged<String> onSelect;
  const FontPickerList({super.key, required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) => sb((c, p) => ListView.separated(
        padding: const EdgeInsets.only(bottom: 30),
        itemCount: appFonts.length,
        separatorBuilder: (_, __) => Divider(height: 1, color: p.glassBorder),
        itemBuilder: (ctx, i) {
          final f = appFonts[i];
          final sel = f.name == selected;
          return InkWell(
            onTap: () => onSelect(f.name),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(f.label, style: uiStyle(14, sel ? p.accent : p.text, w: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Directionality(
                      textDirection: TextDirection.rtl,
                      child: Text(bismillah, style: arabicStyle(f.name, 24, p.text, height: 1.7)),
                    ),
                  ]),
                ),
                if (sel) Icon(Icons.check_circle_rounded, color: p.accent),
              ]),
            ),
          );
        },
      ));
}

class EditorPage extends StatefulWidget {
  final TFolder folder;
  final TItem item;
  final bool isNew;
  const EditorPage(this.folder, this.item, {super.key, this.isNew = false});
  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  late final TextEditingController _title = TextEditingController(text: widget.item.title);
  late final TextEditingController _text = TextEditingController(text: widget.item.text);
  late String font = widget.item.font;
  late double size = widget.item.size, height = widget.item.height;
  late int align = widget.item.align, color = widget.item.color;

  void _save() {
    final it = widget.item;
    it.title = _title.text.trim();
    it.text = _text.text;
    it.font = font;
    it.size = size;
    it.height = height;
    it.align = align;
    it.color = color;
    if (widget.isNew && !widget.folder.items.contains(it)) widget.folder.items.add(it);
    tawasul.save();
    Navigator.pop(context);
  }

  void _pickFont() => showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: settings.pal.bg[1],
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (_) => SizedBox(
          height: MediaQuery.of(context).size.height * 0.75,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.all(18),
              child: Text('Pilih font Arab (${appFonts.length} pilihan)',
                  style: uiStyle(16, settings.pal.text, w: FontWeight.w700)),
            ),
            Expanded(
              child: FontPickerList(
                selected: font,
                onSelect: (f) {
                  setState(() => font = f);
                  Navigator.pop(context);
                },
              ),
            ),
          ]),
        ),
      );

  Widget _slider(AppPalette p, String label, double v, double min, double max, ValueChanged<double> cb) => Row(children: [
        SizedBox(width: 92, child: Text(label, style: uiStyle(13, p.sub))),
        Expanded(child: Slider(value: v, min: min, max: max, activeColor: p.accent, onChanged: cb)),
        SizedBox(width: 36, child: Text(v.toStringAsFixed(v < 5 ? 1 : 0), style: uiStyle(12.5, p.text))),
      ]);

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final preview = TItem(id: 'x', font: font, size: size, height: height, align: align, color: color);
        return GlassScaffold(
          title: widget.isNew ? 'Tulisan baru' : 'Edit tulisan',
          actions: [
            TextButton(onPressed: _save, child: Text('SIMPAN', style: uiStyle(14, p.accent, w: FontWeight.w700))),
          ],
          body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
            GlassCard(
              blur: false,
              child: TextField(
                controller: _title,
                style: uiStyle(15, p.text),
                decoration: InputDecoration(border: InputBorder.none, hintText: 'Judul', hintStyle: uiStyle(15, p.sub)),
              ),
            ),
            GlassCard(
              blur: false,
              child: TextField(
                controller: _text,
                minLines: 6,
                maxLines: 14,
                textDirection: TextDirection.rtl,
                textAlign: align == 1 ? TextAlign.center : TextAlign.right,
                onChanged: (_) => setState(() {}),
                style: arabicStyle(font, size, _itemColor(preview, p), height: height),
                decoration: InputDecoration(
                    border: InputBorder.none, hintText: 'اكتب هنا...', hintStyle: uiStyle(16, p.sub)),
              ),
            ),
            const SectionLabel('PENGATURAN FONT ARAB'),
            GlassCard(
              blur: false,
              child: Column(children: [
                MenuRow('Jenis font', value: fontOf(font).label, onTap: _pickFont),
                _slider(p, 'Ukuran', size, 16, 64, (v) => setState(() => size = v)),
                _slider(p, 'Jarak baris', height, 1.2, 3.2, (v) => setState(() => height = v)),
                Row(children: [
                  SizedBox(width: 92, child: Text('Perataan', style: uiStyle(13, p.sub))),
                  SegmentedButton<int>(
                    showSelectedIcon: false,
                    segments: const [
                      ButtonSegment(value: 0, icon: Icon(Icons.format_align_right_rounded)),
                      ButtonSegment(value: 1, icon: Icon(Icons.format_align_center_rounded)),
                    ],
                    selected: {align},
                    onSelectionChanged: (s) => setState(() => align = s.first),
                  ),
                ]),
                const SizedBox(height: 10),
                Row(children: [
                  SizedBox(width: 92, child: Text('Warna', style: uiStyle(13, p.sub))),
                  Expanded(
                    child: Wrap(spacing: 10, children: [
                      for (final col in _colors.where((x) => _readable(x, p)))
                        GestureDetector(
                          onTap: () => setState(() => color = col),
                          child: Container(
                            width: 30,
                            height: 30,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: col == 0 ? p.text : Color(col),
                              border: Border.all(color: color == col ? p.accent : p.glassBorder, width: color == col ? 3 : 1),
                            ),
                            child: col == 0 ? Icon(Icons.auto_awesome, size: 15, color: p.bg[1]) : null,
                          ),
                        ),
                    ]),
                  ),
                ]),
              ]),
            ),
          ]),
        );
      });
}
