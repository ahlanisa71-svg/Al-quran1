import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/core.dart';
import 'settings_pages.dart';
import 'update_page.dart';

class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});
  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  String version = '1.0.0';

  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((i) {
      if (mounted) setState(() => version = '${i.version} (${i.buildNumber})');
    });
  }

  void _go(Widget w) => Navigator.push(context, smoothRoute(w));

  @override
  Widget build(BuildContext context) => sb((c, p) => SafeArea(
        bottom: false,
        child: ListView(padding: const EdgeInsets.only(bottom: navPad), children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 14, 24, 10),
            child: Text('Pengaturan', style: uiStyle(24, p.text, w: FontWeight.w700)),
          ),
          GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
            child: Column(children: [
              MenuRow('Pengaturan Tampilan', onTap: () => _go(const DisplaySettingsPage())),
              MenuRow('Qari', value: settings.qariInfo.name, onTap: () => _go(const QariPage())),
              MenuRow('Statistik', onTap: () => _go(const StatsPage())),
              MenuRow('Target Khatam', onTap: () => _go(const KhatamPage()), divider: false),
            ]),
          ),
          GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
            child: Column(children: [
              MenuRow('Versi Aplikasi', value: version, trailing: const SizedBox(width: 4)),
              ListenableBuilder(
                listenable: Updater.I,
                builder: (ctx, _) => MenuRow('Pembaruan Aplikasi',
                    value: Updater.I.available != null ? 'Tersedia' : null, onTap: () => _go(const UpdatePage())),
              ),
              MenuRow('Laporan Bug', subtitle: bugEmail, onTap: () => _go(const BugReportPage())),
              MenuRow('Tentang Kami', onTap: () => _go(const AboutPage()), divider: false),
            ]),
          ),
          GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
            child: MenuRow('Kebijakan Privasi', onTap: () => _go(const PrivacyPage()), divider: false),
          ),
          const SectionLabel('IKUTI PENGEMBANG'),
          GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            child: Column(children: [
              _SocialRow(
                icon: const _InstagramIcon(),
                name: 'rifsy_am',
                label: 'Instagram',
                url: 'https://www.instagram.com/rifsy_am?exln=MWRqOWZuY2R2eDRlZQ==',
              ),
              Divider(height: 1, color: p.glassBorder),
              _SocialRow(
                icon: const _FacebookIcon(),
                name: 'El Mahmud Rifqi',
                label: 'Facebook',
                url: 'https://www.facebook.com/profile.php?id=61555140984359',
              ),
            ]),
          ),
        ]),
      ));
}

class _SocialRow extends StatelessWidget {
  final Widget icon;
  final String name, label, url;
  const _SocialRow({required this.icon, required this.name, required this.label, required this.url});

  @override
  Widget build(BuildContext context) => sb((c, p) => InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(children: [
            icon,
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name, style: uiStyle(15, p.text, w: FontWeight.w600)),
                Text(label, style: uiStyle(12.5, p.sub, w: FontWeight.w400)),
              ]),
            ),
            Icon(Icons.open_in_new_rounded, size: 18, color: p.sub),
          ]),
        ),
      ));
}

class _InstagramIcon extends StatelessWidget {
  const _InstagramIcon();
  @override
  Widget build(BuildContext context) => Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(13),
          gradient: const LinearGradient(
              begin: Alignment.bottomLeft,
              end: Alignment.topRight,
              colors: [Color(0xFFFEDA77), Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF), Color(0xFF515BD4)]),
        ),
        alignment: Alignment.center,
        child: Container(
          width: 22,
          height: 22,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(7), border: Border.all(color: Colors.white, width: 2)),
          alignment: Alignment.center,
          child: Stack(alignment: Alignment.center, children: [
            Container(
                width: 9,
                height: 9,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2))),
            Positioned(
                top: 2,
                right: 2,
                child: Container(width: 3, height: 3, decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white))),
          ]),
        ),
      );
}

class _FacebookIcon extends StatelessWidget {
  const _FacebookIcon();
  @override
  Widget build(BuildContext context) => Container(
        width: 42,
        height: 42,
        decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF1877F2)),
        alignment: Alignment.bottomCenter,
        child: const Padding(
          padding: EdgeInsets.only(bottom: 0),
          child: Text('f', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800, height: 1.15)),
        ),
      );
}
