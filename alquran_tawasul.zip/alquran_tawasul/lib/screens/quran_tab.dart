import 'package:flutter/material.dart';
import '../core/core.dart';
import 'reader.dart';

class QuranTab extends StatefulWidget {
  const QuranTab({super.key});
  @override
  State<QuranTab> createState() => _QuranTabState();
}

class _QuranTabState extends State<QuranTab> {
  final _ctl = TextEditingController();
  final _q = ValueNotifier<String>('');
  final _focus = FocusNode();
  bool _open = false;

  void _openSearch() {
    setState(() => _open = true);
    Future.delayed(const Duration(milliseconds: 260), () {
      if (mounted && _open) _focus.requestFocus();
    });
  }

  void _closeSearch() {
    _focus.unfocus();
    _ctl.clear();
    _q.value = '';
    setState(() => _open = false);
  }

  @override
  void dispose() {
    _focus.dispose();
    _ctl.dispose();
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => sb((c, p) => SafeArea(
        bottom: false,
        child: DefaultTabController(
          length: 3,
          initialIndex: 2,
          child: Builder(
            builder: (tabCtx) => Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 10, 16, 8),
                child: SizedBox(
                  height: 46,
                  child: LayoutBuilder(builder: (ctx, box) {
                    final maxW = box.maxWidth;
                    return Stack(children: [
                      Positioned.fill(
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: AnimatedOpacity(
                            duration: const Duration(milliseconds: 200),
                            opacity: _open ? 0 : 1,
                            child: Text('Al Quran', style: uiStyle(24, p.text, w: FontWeight.w700)),
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 340),
                          curve: Curves.easeOutCubic,
                          width: _open ? maxW : 46,
                          height: 46,
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                            color: p.glass,
                            borderRadius: BorderRadius.circular(23),
                            border: Border.all(color: p.glassBorder),
                          ),
                          child: LayoutBuilder(builder: (ctx2, b2) {
                            final w = b2.maxWidth;
                            final tw = (w - 92).clamp(0.0, 4000.0).toDouble();
                            return Stack(children: [
                              Positioned(
                                left: 0,
                                top: 0,
                                bottom: 0,
                                width: 44,
                                child: IconButton(
                                  padding: EdgeInsets.zero,
                                  tooltip: 'Cari surat',
                                  icon: Icon(Icons.search_rounded, color: _open ? p.sub : p.text),
                                  onPressed: _open ? null : _openSearch,
                                ),
                              ),
                              if (_open && tw > 40)
                                Positioned(
                                  left: 44,
                                  top: 0,
                                  bottom: 0,
                                  width: tw,
                                  child: TextField(
                                    controller: _ctl,
                                    focusNode: _focus,
                                    style: uiStyle(14.5, p.text, w: FontWeight.w500),
                                    cursorColor: p.accent,
                                    textInputAction: TextInputAction.search,
                                    onChanged: (v) {
                                      _q.value = v;
                                      if (v.trim().isNotEmpty) DefaultTabController.of(tabCtx).animateTo(2);
                                    },
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: 'Cari surat (mis. Yasin, 36, الكهف)',
                                      hintStyle: uiStyle(14, p.sub, w: FontWeight.w400),
                                      contentPadding: const EdgeInsets.symmetric(vertical: 13),
                                    ),
                                  ),
                                ),
                              if (_open && w >= 92)
                                Positioned(
                                  right: 0,
                                  top: 0,
                                  bottom: 0,
                                  width: 44,
                                  child: IconButton(
                                    padding: EdgeInsets.zero,
                                    tooltip: 'Tutup pencarian',
                                    icon: Icon(Icons.close_rounded, color: p.sub, size: 20),
                                    onPressed: _closeSearch,
                                  ),
                                ),
                            ]);
                          }),
                        ),
                      ),
                    ]);
                  }),
                ),
              ),
              TabBar(
                labelColor: p.accent,
                unselectedLabelColor: p.sub,
                indicatorColor: p.accent,
                dividerColor: p.glassBorder,
                labelStyle: uiStyle(13, p.accent, w: FontWeight.w600),
                unselectedLabelStyle: uiStyle(13, p.sub, w: FontWeight.w500),
                tabs: const [Tab(text: 'BOOKMARK'), Tab(text: 'JUZ'), Tab(text: 'SURAH')],
              ),
              Expanded(child: TabBarView(children: [const _Bookmarks(), const _JuzList(), _SurahList(query: _q)])),
            ]),
          ),
        ),
      ));
}

String _norm(String s) => s.toLowerCase().replaceAll(RegExp("[^a-z0-9\u0600-\u06FF]"), '');

class _SurahList extends StatelessWidget {
  final ValueNotifier<String> query;
  const _SurahList({required this.query});

  bool _match(Surah s, String q) {
    final n = _norm(q);
    if (n.isEmpty) return true;
    if (RegExp(r'^[0-9]+$').hasMatch(q.trim())) return s.n.toString() == q.trim() || s.n.toString().startsWith(q.trim());
    return _norm(s.en).contains(n) || _norm(s.id).contains(n) || _norm(s.arPlain).contains(n);
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
      valueListenable: query,
      builder: (_, q, __) => sb((c, p) {
        final list = QuranData.surahs.where((s) => _match(s, q)).toList();
        if (list.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Text('Surat "$q" tidak ditemukan.\nCoba nama lain, misalnya "baqarah", "yasin", atau nomor surat.',
                  textAlign: TextAlign.center, style: uiStyle(14, p.sub, w: FontWeight.w400, height: 1.6)),
            ),
          );
        }
        return ListView.separated(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.only(bottom: navPad),
          itemCount: list.length,
          separatorBuilder: (_, __) => Divider(height: 1, indent: 20, endIndent: 20, color: p.glassBorder),
          itemBuilder: (ctx, i) {
            final s = list[i];
            return InkWell(
              onTap: () => openSurah(ctx, s),
              child: Padding(
                padding: const EdgeInsets.only(left: 18, right: 6, top: 10, bottom: 10),
                child: Row(children: [
                  SizedBox(
                    width: 32,
                    child: Text('${s.n}', style: uiStyle(14, p.accent, w: FontWeight.w600)),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Flexible(child: Text(s.en, style: uiStyle(16, p.text, w: FontWeight.w500))),
                        if (settings.marker > 0 && QuranData.byGlobal(settings.marker).sn == s.n) ...[
                          const SizedBox(width: 6),
                          Icon(Icons.flag_rounded, size: 16, color: p.accent),
                        ],
                      ]),
                      const SizedBox(height: 2),
                      Text('${s.type == 'Meccan' ? 'MEKAH' : 'MADINAH'} | ${s.ayat.length} AYAT',
                          style: TextStyle(fontSize: 11.5, letterSpacing: 0.8, color: p.sub, fontWeight: FontWeight.w400)),
                    ]),
                  ),
                  Text(s.arPlain, style: arabicStyle('Aref Ruqaa', 26, p.text, height: 1.5)),
                  ValueListenableBuilder<int?>(
                    valueListenable: AudioService.I.current,
                    builder: (_, cur, __) {
                      final playing = cur != null && QuranData.byGlobal(cur).sn == s.n;
                      return IconButton(
                        icon: Icon(playing ? Icons.stop_circle_rounded : Icons.volume_up_rounded, color: p.accent),
                        onPressed: () => playing ? AudioService.I.stop() : AudioService.I.toggle(s.ayat, 0),
                      );
                    },
                  ),
                ]),
              ),
            );
          },
        );
      }));
}

class _JuzList extends StatelessWidget {
  const _JuzList();
  @override
  Widget build(BuildContext context) => sb((c, p) => ListView.separated(
        padding: const EdgeInsets.only(bottom: navPad),
        itemCount: 30,
        separatorBuilder: (_, __) => Divider(height: 1, color: p.glassBorder),
        itemBuilder: (ctx, i) {
          final j = i + 1;
          final st = QuranData.juzStart(j);
          final s = QuranData.surah(st.sn);
          return InkWell(
            onTap: () => openJuz(ctx, j),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
              child: Row(children: [
                Container(
                  width: 40,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent.withValues(alpha: 0.16)),
                  child: Text('$j', style: uiStyle(14, p.accent, w: FontWeight.w700)),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Juz $j', style: uiStyle(15, p.text, w: FontWeight.w600)),
                    Text('Mulai ${s.en} ayat ${st.n}', style: uiStyle(12.5, p.sub, w: FontWeight.w400)),
                  ]),
                ),
                Text(s.arPlain, style: arabicStyle('Aref Ruqaa', 22, p.sub, height: 1.4)),
              ]),
            ),
          );
        },
      ));
}

class _Bookmarks extends StatelessWidget {
  const _Bookmarks();
  @override
  Widget build(BuildContext context) => sb((c, p) {
        final list = settings.bookmarks.toList()..sort();
        if (list.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Text('Belum ada bookmark.\nTekan ikon bookmark pada ayat untuk menyimpannya.',
                  textAlign: TextAlign.center, style: uiStyle(14, p.sub, w: FontWeight.w400, height: 1.6)),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.only(bottom: navPad),
          itemCount: list.length,
          separatorBuilder: (_, __) => Divider(height: 1, color: p.glassBorder),
          itemBuilder: (ctx, i) {
            final a = QuranData.byGlobal(list[i]);
            final s = QuranData.surah(a.sn);
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 4),
              onTap: () => openSurah(ctx, s, jumpTo: a.g),
              title: Text('${s.en} : ${a.n}', style: uiStyle(14.5, p.text, w: FontWeight.w600)),
              subtitle: Text(a.i, maxLines: 2, overflow: TextOverflow.ellipsis, style: uiStyle(12.5, p.sub, w: FontWeight.w400)),
              trailing: IconButton(
                icon: Icon(Icons.bookmark_rounded, color: p.accent),
                onPressed: () => settings.toggleBookmark(a.g),
              ),
            );
          },
        );
      });
}
