import 'package:flutter/material.dart';
import '../core/core.dart';
import 'reader.dart';

class QuranTab extends StatelessWidget {
  const QuranTab({super.key});

  @override
  Widget build(BuildContext context) => sb((c, p) => SafeArea(
        bottom: false,
        child: DefaultTabController(
          length: 3,
          initialIndex: 2,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 14, 24, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Al Quran', style: uiStyle(24, p.text, w: FontWeight.w700)),
              ),
            ),
            TabBar(
              labelColor: p.accent,
              unselectedLabelColor: p.sub,
              indicatorColor: p.accent,
              dividerColor: p.glassBorder,
              labelStyle: uiStyle(13, p.accent, w: FontWeight.w600),
              unselectedLabelStyle: uiStyle(13, p.sub, w: FontWeight.w500),
              tabs: const [Tab(text: 'BOOKMARK'), Tab(text: 'JUZ'), Tab(text: 'SURAH')],
            ),
            const Expanded(child: TabBarView(children: [_Bookmarks(), _JuzList(), _SurahList()])),
          ]),
        ),
      ));
}

class _SurahList extends StatelessWidget {
  const _SurahList();
  @override
  Widget build(BuildContext context) => sb((c, p) {
        return ListView.separated(
          padding: const EdgeInsets.only(bottom: navPad),
          itemCount: QuranData.surahs.length,
          separatorBuilder: (_, __) => Divider(height: 1, indent: 20, endIndent: 20, color: p.glassBorder),
          itemBuilder: (ctx, i) {
            final s = QuranData.surahs[i];
            return InkWell(
              onTap: () => openSurah(ctx, s),
              child: Padding(
                padding: const EdgeInsets.only(left: 18, right: 6, top: 10, bottom: 10),
                child: Row(children: [
                  SizedBox(
                    width: 32,
                    child: Text('${s.n}', style: uiStyle(14, p.accent, w: FontWeight.w600)),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Flexible(child: Text(s.en, style: uiStyle(16, p.text, w: FontWeight.w500))),
                        if (settings.marker > 0 && QuranData.byGlobal(settings.marker).sn == s.n) ...[
                          const SizedBox(width: 6),
                          Icon(Icons.flag_rounded, size: 16, color: p.accent),
                        ],
                      ]),
                      const SizedBox(height: 2),
                      Text('${s.type == 'Meccan' ? 'MEKAH' : 'MADINAH'} | ${s.ayat.length} AYAT',
                          style: TextStyle(fontSize: 11.5, letterSpacing: 0.8, color: p.sub, fontWeight: FontWeight.w400)),
                    ]),
                  ),
                  Text(s.arPlain, style: arabicStyle('Aref Ruqaa', 26, p.text, height: 1.5)),
                  ValueListenableBuilder<int?>(
                    valueListenable: AudioService.I.current,
                    builder: (_, cur, __) {
                      final playing = cur != null && QuranData.byGlobal(cur).sn == s.n;
                      return IconButton(
                        icon: Icon(playing ? Icons.stop_circle_rounded : Icons.volume_up_rounded, color: p.accent),
                        onPressed: () => playing ? AudioService.I.stop() : AudioService.I.toggle(s.ayat, 0),
                      );
                    },
                  ),
                ]),
              ),
            );
          },
        );
      });
}

class _JuzList extends StatelessWidget {
  const _JuzList();
  @override
  Widget build(BuildContext context) => sb((c, p) => ListView.separated(
        padding: const EdgeInsets.only(bottom: navPad),
        itemCount: 30,
        separatorBuilder: (_, __) => Divider(height: 1, color: p.glassBorder),
        itemBuilder: (ctx, i) {
          final j = i + 1;
          final st = QuranData.juzStart(j);
          final s = QuranData.surah(st.sn);
          return InkWell(
            onTap: () => openJuz(ctx, j),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
              child: Row(children: [
                Container(
                  width: 40,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent.withValues(alpha: 0.16)),
                  child: Text('$j', style: uiStyle(14, p.accent, w: FontWeight.w700)),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Juz $j', style: uiStyle(15, p.text, w: FontWeight.w600)),
                    Text('Mulai ${s.en} ayat ${st.n}', style: uiStyle(12.5, p.sub, w: FontWeight.w400)),
                  ]),
                ),
                Text(s.arPlain, style: arabicStyle('Aref Ruqaa', 22, p.sub, height: 1.4)),
              ]),
            ),
          );
        },
      ));
}

class _Bookmarks extends StatelessWidget {
  const _Bookmarks();
  @override
  Widget build(BuildContext context) => sb((c, p) {
        final list = settings.bookmarks.toList()..sort();
        if (list.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Text('Belum ada bookmark.\nTekan ikon bookmark pada ayat untuk menyimpannya.',
                  textAlign: TextAlign.center, style: uiStyle(14, p.sub, w: FontWeight.w400, height: 1.6)),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.only(bottom: navPad),
          itemCount: list.length,
          separatorBuilder: (_, __) => Divider(height: 1, color: p.glassBorder),
          itemBuilder: (ctx, i) {
            final a = QuranData.byGlobal(list[i]);
            final s = QuranData.surah(a.sn);
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 4),
              onTap: () => openSurah(ctx, s, jumpTo: a.g),
              title: Text('${s.en} : ${a.n}', style: uiStyle(14.5, p.text, w: FontWeight.w600)),
              subtitle: Text(a.i, maxLines: 2, overflow: TextOverflow.ellipsis, style: uiStyle(12.5, p.sub, w: FontWeight.w400)),
              trailing: IconButton(
                icon: Icon(Icons.bookmark_rounded, color: p.accent),
                onPressed: () => settings.toggleBookmark(a.g),
              ),
            );
          },
        );
      });
}
