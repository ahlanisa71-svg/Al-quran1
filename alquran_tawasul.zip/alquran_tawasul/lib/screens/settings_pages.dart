import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/core.dart';
import 'tawasul.dart' show FontPickerList;

const bugEmail = 'rifqihisyammuddin429@gmail.com';

// ───────────────────────── Pengaturan Tampilan ─────────────────────────
class DisplaySettingsPage extends StatelessWidget {
  const DisplaySettingsPage({super.key});

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final f = fontOf(settings.font);
        return GlassScaffold(
          title: 'Pengaturan Tampilan',
          body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
            GlassCard(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
              child: MenuRow('Tema Warna',
                  value: settings.pal.name,
                  onTap: () => Navigator.push(context, smoothRoute(const ThemePage())),
                  divider: false),
            ),
            GlassCard(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
              child: MenuRow('Teks Arab',
                  trailing: GlassSwitch(settings.showArabic, (v) => settings.update(() => settings.showArabic = v)),
                  divider: false),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 0, 24, 8),
              child: GestureDetector(
                onTap: () => settings.update(() => settings.bookMode = !settings.bookMode),
                child: Text(
                  settings.bookMode ? 'Beralih ke Mode Daftar dari sini' : 'Beralih ke Mode Buku dari sini',
                  style: uiStyle(13, p.accent, w: FontWeight.w600),
                ),
              ),
            ),
            GlassCard(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
              child: MenuRow('Transliterasi',
                  trailing: GlassSwitch(settings.showTranslit, (v) => settings.update(() => settings.showTranslit = v)),
                  divider: false),
            ),
            const SectionLabel('Perlihatkan pengucapan Ayat'),
            GlassCard(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
              child: Column(children: [
                MenuRow('Gaya Penulisan',
                    value: f.label.split(' - ').first,
                    onTap: () => Navigator.push(context, smoothRoute(const FontStylePage()))),
                MenuRow('Pewarnaan Tajwid',
                    trailing: GlassSwitch(settings.tajwid, (v) => settings.update(() => settings.tajwid = v))),
                MenuRow('Panduan Warna Tajwid', onTap: () => Navigator.push(context, smoothRoute(const TajwidGuidePage()))),
                MenuRow('Terjemahan',
                    trailing: GlassSwitch(settings.showTranslation, (v) => settings.update(() => settings.showTranslation = v))),
                MenuRow('Tafsir',
                    trailing: GlassSwitch(settings.showTafsir, (v) => settings.update(() => settings.showTafsir = v)),
                    subtitle: 'Tafsir Jalalayn (Bahasa Indonesia)',
                    divider: false),
              ]),
            ),
            GlassCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Ukuran Huruf', style: uiStyle(15, p.text, w: FontWeight.w700)),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: p.text.withValues(alpha: 0.06), borderRadius: BorderRadius.circular(16)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(
                      width: double.infinity,
                      child: Directionality(
                        textDirection: TextDirection.rtl,
                        child: Text(bismillah, style: arabicStyle(settings.font, settings.arabSize, p.text)),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text('Bi-smi l-lāhi r-raḥmāni r-raḥīm(i)', style: uiStyle(settings.textSize, p.accent)),
                  ]),
                ),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: _Stepper('Teks', settings.textSize, 11, 28, (v) => settings.update(() => settings.textSize = v))),
                  const SizedBox(width: 12),
                  Expanded(child: _Stepper('Bahasa Arab', settings.arabSize, 18, 60, (v) => settings.update(() => settings.arabSize = v))),
                ]),
              ]),
            ),
          ]),
        );
      });
}

class ThemePage extends StatelessWidget {
  const ThemePage({super.key});
  @override
  Widget build(BuildContext context) => sb((c, p) => GlassScaffold(
        title: 'Tema Warna',
        body: GridView.builder(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.45),
          itemCount: palettes.length,
          itemBuilder: (ctx, i) {
            final t = palettes[i];
            final sel = settings.themeIdx == i;
            return GestureDetector(
              onTap: () => settings.update(() => settings.themeIdx = i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 320),
                curve: Curves.easeOutCubic,
                clipBehavior: Clip.antiAlias,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  color: t.bg[1],
                  border: Border.all(
                      color: sel ? (p.dark ? Colors.white : p.accent) : p.glassBorder, width: sel ? 3 : 1),
                ),
                child: Stack(clipBehavior: Clip.none, children: [
                  Positioned(
                      top: -70,
                      left: -70,
                      child: Container(width: 110, height: 110, decoration: BoxDecoration(shape: BoxShape.circle, color: t.accent.withValues(alpha: 0.16)))),
                  Positioned(
                      bottom: -80,
                      right: -60,
                      child: Container(width: 130, height: 130, decoration: BoxDecoration(shape: BoxShape.circle, color: t.blob.withValues(alpha: 0.22)))),
                  Align(
                    alignment: Alignment.topRight,
                    child: AnimatedScale(
                      scale: sel ? 1 : 0,
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOutBack,
                      child: CircleAvatar(radius: 14, backgroundColor: t.accent, child: const Icon(Icons.check, size: 18, color: Colors.black87)),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(t.name, style: uiStyle(15, t.text, w: FontWeight.w700)),
                      const SizedBox(width: 8),
                      Container(width: 10, height: 10, decoration: BoxDecoration(shape: BoxShape.circle, color: t.accent)),
                    ]),
                  ),
                ]),
              ),
            );
          },
        ),
      ));
}

class _Stepper extends StatelessWidget {
  final String label;
  final double value, min, max;
  final ValueChanged<double> onChanged;
  const _Stepper(this.label, this.value, this.min, this.max, this.onChanged);
  @override
  Widget build(BuildContext context) => sb((c, p) => Container(
        decoration: BoxDecoration(color: p.text.withValues(alpha: 0.06), borderRadius: BorderRadius.circular(30)),
        child: Row(children: [
          _btn(p, Icons.remove, () => onChanged((value - 1).clamp(min, max).toDouble())),
          Expanded(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(label, style: uiStyle(12.5, p.text, w: FontWeight.w600)),
              Text(value.toStringAsFixed(0), style: uiStyle(11, p.sub)),
            ]),
          ),
          _btn(p, Icons.add, () => onChanged((value + 1).clamp(min, max).toDouble())),
        ]),
      ));
  Widget _btn(AppPalette p, IconData i, VoidCallback f) => InkWell(
        onTap: f,
        customBorder: const CircleBorder(),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent),
          child: Icon(i, color: Colors.black87, size: 20),
        ),
      );
}

class FontStylePage extends StatelessWidget {
  const FontStylePage({super.key});
  @override
  Widget build(BuildContext context) => sb((c, p) => GlassScaffold(
        title: 'Gaya Penulisan',
        body: FontPickerList(selected: settings.font, onSelect: (f) => settings.update(() => settings.font = f)),
      ));
}

class TajwidGuidePage extends StatelessWidget {
  const TajwidGuidePage({super.key});
  @override
  Widget build(BuildContext context) => sb((c, p) => GlassScaffold(
        title: 'Panduan Warna Tajwid',
        body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
          for (final e in tajwidInfo.entries)
            GlassCard(
              child: Row(children: [
                Container(width: 22, height: 22, decoration: BoxDecoration(shape: BoxShape.circle, color: tajwidColors[e.key])),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(e.value[0], style: uiStyle(15, p.text, w: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(e.value[1], style: uiStyle(13, p.sub, w: FontWeight.w400, height: 1.45)),
                  ]),
                ),
              ]),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(28, 10, 28, 0),
            child: Text(
              'Catatan: pewarnaan dibuat otomatis oleh aturan di dalam aplikasi sehingga bersifat perkiraan. Untuk belajar tajwid, rujuklah mushaf tajwid dan guru.',
              style: uiStyle(12.5, p.sub, w: FontWeight.w400, height: 1.5),
            ),
          ),
        ]),
      ));
}

// ───────────────────────── Qari ─────────────────────────
class QariPage extends StatelessWidget {
  const QariPage({super.key});

  @override
  Widget build(BuildContext context) => sb((c, p) => GlassScaffold(
        title: 'Qari',
        body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
          for (final q in settings.allQaris)
            GlassCard(
              onTap: () => settings.update(() => settings.qari = q.id),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(q.name, style: uiStyle(15, p.text, w: FontWeight.w600)),
                    if (q.template != null) Text('Qari buatan sendiri', style: uiStyle(12, p.sub, w: FontWeight.w400)),
                  ]),
                ),
                if (q.template != null)
                  IconButton(
                    icon: Icon(Icons.delete_outline_rounded, color: p.sub),
                    onPressed: () => settings.removeCustomQari(q.id),
                  ),
                if (settings.qari == q.id) Icon(Icons.check_circle_rounded, color: p.accent),
              ]),
            ),
        ]),
      ));
}

// ───────────────────────── Unduhan ─────────────────────────
class DownloadsPage extends StatefulWidget {
  const DownloadsPage({super.key});
  @override
  State<DownloadsPage> createState() => _DownloadsPageState();
}

class _DownloadsPageState extends State<DownloadsPage> {
  final dm = DownloadManager.I;
  int _mine = 0, _all = 0;
  static const _rates = ['32', '64', '128', '192'];
  static const _rateNote = {'32': 'Hemat', '64': 'Standar', '128': 'Bagus', '192': 'Terbaik'};
  // perkiraan: rata-rata ayat ±10 detik → kbps × 1250 byte
  int _perAyat(String kbps) => int.parse(kbps) * 1250;
  int get _avg => _perAyat(settings.dlBitrate);

  Future<Directory> _root() async => Directory('${(await getApplicationDocumentsDirectory()).path}/audio');

  Future<int> _size(Directory d) async {
    if (!await d.exists()) return 0;
    int t = 0;
    await for (final e in d.list(recursive: true, followLinks: false)) {
      if (e is File) t += await e.length();
    }
    return t;
  }

  Future<void> _refreshSize() async {
    final root = await _root();
    final qdir = Directory('${root.path}/${settings.qari}');
    final m = await _size(qdir);
    final a = await _size(root);
    if (mounted) {
      setState(() {
        _mine = m;
        _all = a;
      });
    }
  }

  String _fmt(int b) {
    if (b < 1024) return '$b B';
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
    if (b < 1024 * 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
    return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
  }

  Future<void> _wipe({required bool all}) async {
    if (dm.busy) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tunggu unduhan selesai dulu.')));
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(all ? 'Hapus semua audio?' : 'Hapus audio qari ini?'),
        content: Text(all
            ? 'Semua audio unduhan dari semua qari (${_fmt(_all)}) akan dihapus dari HP. Anda bisa mengunduhnya lagi nanti.'
            : 'Audio unduhan ${settings.qariInfo.name} (${_fmt(_mine)}) akan dihapus dari HP. Anda bisa mengunduhnya lagi nanti.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;
    await AudioService.I.stop();
    final root = await _root();
    final dir = all ? root : Directory('${root.path}/${settings.qari}');
    if (await dir.exists()) await dir.delete(recursive: true);
    if (all) {
      await dm.forgetAll();
    } else {
      await dm.forgetQari(settings.qari);
    }
    await _refreshSize();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Audio dihapus')));
  }

  @override
  void initState() {
    super.initState();
    dm.load();
    _wasBusy = dm.busy;
    dm.addListener(_onDm);
    _refreshSize();
  }

  bool _wasBusy = false;
  void _onDm() {
    if (!mounted) return;
    setState(() {});
    if (_wasBusy && !dm.busy) {
      _refreshSize();
      if (dm.failedSome) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sebagian audio gagal diunduh. Periksa koneksi lalu coba lagi.')));
      }
    }
    _wasBusy = dm.busy;
  }

  @override
  void dispose() {
    dm.removeListener(_onDm); // unduhan tetap berjalan di latar belakang
    super.dispose();
  }

  int _remainingAyat() => QuranData.surahs
      .where((x) => !dm.isDone(settings.qari, x.n))
      .fold<int>(0, (t, x) => t + x.ayat.length);

  Future<void> _downloadAll() async {
    final est = _remainingAyat() * _avg;
    if (est == 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Semua surat sudah diunduh.')));
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Unduh semua surat?'),
        content: Text('Perkiraan ukuran: ${_fmt(est)} (${settings.dlBitrate} kbps) untuk ${settings.qariInfo.name}.\n'
            'Sebaiknya memakai Wi-Fi. Unduhan berjalan di latar belakang dan bisa dihentikan kapan saja.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Unduh')),
        ],
      ),
    );
    if (ok != true) return;
    for (final x in QuranData.surahs) {
      dm.enqueue(settings.qari, x);
    }
  }

  Future<void> _delete(Surah s) async {
    await dm.deleteSurah(settings.qari, s);
    _refreshSize();
  }

  @override
  Widget build(BuildContext context) => sb((c, p) => GlassScaffold(
        title: 'Unduhan',
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 0, 24, 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text('Audio qari: ${settings.qariInfo.name}\nUnduh agar bisa didengar tanpa internet.\nUnduhan tetap berjalan di latar belakang.',
                  style: uiStyle(12.5, p.sub, w: FontWeight.w400, height: 1.5)),
            ),
          ),
          GlassCard(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('Ruang terpakai (qari ini)', style: uiStyle(13, p.sub))),
                Text(_fmt(_mine), style: uiStyle(14, p.text, w: FontWeight.w700)),
              ]),
              const SizedBox(height: 4),
              Row(children: [
                Expanded(child: Text('Semua qari', style: uiStyle(13, p.sub))),
                Text(_fmt(_all), style: uiStyle(14, p.text, w: FontWeight.w700)),
              ]),
              const SizedBox(height: 12),
              Text('Kualitas unduhan (bitrate)', style: uiStyle(13, p.sub)),
              const SizedBox(height: 6),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final r in _rates)
                  ChoiceChip(
                    selected: settings.dlBitrate == r,
                    showCheckmark: false,
                    label: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text('$r kbps', style: uiStyle(12.5, p.text, w: FontWeight.w700)),
                      Text('${_rateNote[r]} • ~${_fmt(_remainingAyat() * _perAyat(r))}', style: uiStyle(10.5, p.sub, w: FontWeight.w400)),
                    ]),
                    onSelected: dm.busy ? null : (_) => settings.update(() => settings.dlBitrate = r),
                  ),
              ]),
              if (!dm.busy) ...[
                const SizedBox(height: 10),
                FilledButton.icon(
                  icon: const Icon(Icons.download_for_offline_rounded, size: 18),
                  label: Text('Unduh semua surat (~${_fmt(_remainingAyat() * _avg)})'),
                  onPressed: _downloadAll,
                ),
              ],
              if (dm.busy) ...[
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(foregroundColor: p.text, side: BorderSide(color: p.glassBorder)),
                  icon: const Icon(Icons.stop_circle_outlined, size: 18),
                  label: const Text('Hentikan unduhan'),
                  onPressed: dm.cancelAll,
                ),
              ],
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(foregroundColor: p.text, side: BorderSide(color: p.glassBorder)),
                    icon: const Icon(Icons.delete_outline_rounded, size: 18),
                    label: const Text('Hapus qari ini'),
                    onPressed: _mine == 0 ? null : () => _wipe(all: false),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(foregroundColor: p.text, side: BorderSide(color: p.glassBorder)),
                    icon: const Icon(Icons.delete_sweep_rounded, size: 18),
                    label: const Text('Hapus semua'),
                    onPressed: _all == 0 ? null : () => _wipe(all: true),
                  ),
                ),
              ]),
            ]),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.only(bottom: 30),
              itemCount: 114,
              separatorBuilder: (_, __) => Divider(height: 1, color: p.glassBorder),
              itemBuilder: (ctx, i) {
                final s = QuranData.surahs[i];
                final prog = dm.progressOf(settings.qari, s.n);
                final done = dm.isDone(settings.qari, s.n);
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 22),
                  leading: Text('${s.n}', style: uiStyle(13, p.sub)),
                  title: Text(s.en, style: uiStyle(14.5, p.text, w: FontWeight.w600)),
                  subtitle: prog != null
                      ? Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: LinearProgressIndicator(value: prog, color: p.accent, backgroundColor: p.glassBorder),
                        )
                      : Text(done ? '${s.ayat.length} ayat • tersimpan' : '${s.ayat.length} ayat • ~${_fmt(s.ayat.length * _avg)}', style: uiStyle(12, p.sub, w: FontWeight.w400)),
                  trailing: prog != null
                      ? Text('${(prog * 100).round()}%', style: uiStyle(12.5, p.accent))
                      : done
                          ? IconButton(
                              icon: Icon(Icons.check_circle_rounded, color: p.accent),
                              tooltip: 'Hapus unduhan',
                              onPressed: () => _delete(s),
                            )
                          : IconButton(
                              icon: Icon(Icons.download_rounded, color: p.sub),
                              onPressed: () => dm.enqueue(settings.qari, s),
                            ),
                );
              },
            ),
          ),
        ]),
      ));
}

// ───────────────────────── Statistik ─────────────────────────
class StatsPage extends StatelessWidget {
  const StatsPage({super.key});

  bool _active(DateTime d) {
    final k = d.toIso8601String().substring(0, 10);
    return (settings.dailySeconds[k] ?? 0) > 0 || (settings.dailyAyat[k] ?? 0) > 0;
  }

  int _streak() {
    var d = DateTime.now();
    if (!_active(d)) d = d.subtract(const Duration(days: 1));
    int n = 0;
    while (_active(d)) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }

  Widget _stat(AppPalette p, String label, String value) => Expanded(
        child: GlassCard(
          margin: const EdgeInsets.all(5),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
          child: Column(children: [
            Text(value, style: uiStyle(20, p.accent, w: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(label, textAlign: TextAlign.center, style: uiStyle(12, p.sub)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final read = settings.readSet.length;
        final surahDone = QuranData.surahs.where((s) => s.ayat.every((a) => settings.readSet.contains(a.g))).length;
        final juzDone = List.generate(30, (i) => i + 1)
            .where((j) => QuranData.juz(j).every((a) => settings.readSet.contains(a.g)))
            .length;
        final totalMin = settings.dailySeconds.values.fold<int>(0, (a, b) => a + b) ~/ 60;
        final days = List.generate(7, (i) => DateTime.now().subtract(Duration(days: 6 - i)));
        final vals = days.map((d) => (settings.dailySeconds[d.toIso8601String().substring(0, 10)] ?? 0) / 60).toList();
        final maxV = vals.fold<double>(1, (a, b) => b > a ? b : a);
        const names = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
        return GlassScaffold(
          title: 'Statistik',
          body: ListView(padding: const EdgeInsets.fromLTRB(11, 0, 11, 40), children: [
            Row(children: [
              _stat(p, 'Ayat dibaca', '$read'),
              _stat(p, 'Dari 6236 ayat', '${(read / 6236 * 100).toStringAsFixed(1)}%'),
            ]),
            Row(children: [
              _stat(p, 'Surah selesai', '$surahDone/114'),
              _stat(p, 'Juz selesai', '$juzDone/30'),
            ]),
            Row(children: [
              _stat(p, 'Total waktu baca', '$totalMin mnt'),
              _stat(p, 'Beruntun (hari)', '${_streak()}'),
            ]),
            Row(children: [
              _stat(p, 'Sesi membaca', '${settings.sessions}'),
              _stat(p, 'Bookmark', '${settings.bookmarks.length}'),
            ]),
            GlassCard(
              margin: const EdgeInsets.all(5),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Waktu baca 7 hari terakhir (menit)', style: uiStyle(13.5, p.text, w: FontWeight.w600)),
                const SizedBox(height: 14),
                SizedBox(
                  height: 120,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    for (int i = 0; i < 7; i++)
                      Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                          Text(vals[i].round().toString(), style: uiStyle(10.5, p.sub)),
                          const SizedBox(height: 3),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 500),
                            curve: Curves.easeOutCubic,
                            height: 6 + 70 * (vals[i] / maxV),
                            margin: const EdgeInsets.symmetric(horizontal: 6),
                            decoration: BoxDecoration(color: p.accent, borderRadius: BorderRadius.circular(8)),
                          ),
                          const SizedBox(height: 4),
                          Text(names[days[i].weekday - 1], style: uiStyle(10.5, p.sub)),
                        ]),
                      ),
                  ]),
                ),
              ]),
            ),
          ]),
        );
      });
}

// ───────────────────────── Target Khatam ─────────────────────────
class KhatamPage extends StatelessWidget {
  const KhatamPage({super.key});

  @override
  Widget build(BuildContext context) => sb((c, p) {
        final started = settings.khatamStart.isNotEmpty;
        final read = settings.readSet.length;
        const total = 6236;
        int daysLeft = settings.khatamDays;
        int perDay = (total / settings.khatamDays).ceil();
        if (started) {
          final elapsed = DateTime.now().difference(DateTime.parse(settings.khatamStart)).inDays;
          daysLeft = (settings.khatamDays - elapsed).clamp(1, 9999);
          perDay = ((total - read) / daysLeft).ceil().clamp(0, total);
        }
        return GlassScaffold(
          title: 'Target Khatam',
          body: ListView(padding: const EdgeInsets.only(bottom: 40), children: [
            GlassCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Target selesai dalam', style: uiStyle(13, p.sub)),
                Row(children: [
                  Expanded(child: Text('${settings.khatamDays} hari', style: uiStyle(22, p.text, w: FontWeight.w700))),
                  for (final d in const [7, 30, 60, 90])
                    Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: ChoiceChip(
                        label: Text('$d'),
                        selected: settings.khatamDays == d,
                        onSelected: (_) => settings.update(() => settings.khatamDays = d),
                      ),
                    ),
                ]),
                Slider(
                  value: settings.khatamDays.clamp(3, 365).toDouble(),
                  min: 3,
                  max: 365,
                  activeColor: p.accent,
                  onChanged: (v) => settings.update(() => settings.khatamDays = v.round()),
                ),
              ]),
            ),
            GlassCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(started ? 'Progres khatam' : 'Belum dimulai', style: uiStyle(13, p.sub)),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(value: read / total, minHeight: 12, color: p.accent, backgroundColor: p.glassBorder),
                ),
                const SizedBox(height: 8),
                Text('$read dari $total ayat (${(read / total * 100).toStringAsFixed(1)}%)', style: uiStyle(14, p.text, w: FontWeight.w600)),
                const SizedBox(height: 12),
                Text('Target harian: $perDay ayat', style: uiStyle(16, p.accent, w: FontWeight.w700)),
                Text(started ? 'Sisa $daysLeft hari' : 'Tekan "Mulai target" untuk memulai hitungan hari.', style: uiStyle(12.5, p.sub)),
                Text('Hari ini terbaca: ${settings.dailyAyat[todayKey()] ?? 0} ayat', style: uiStyle(12.5, p.sub)),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22),
              child: Row(children: [
                Expanded(
                  child: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: Colors.black87, minimumSize: const Size(0, 48)),
                    onPressed: () => settings.update(() => settings.khatamStart = todayKey()),
                    child: Text(started ? 'Mulai ulang tanggal' : 'Mulai target'),
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton(
                  style: OutlinedButton.styleFrom(minimumSize: const Size(0, 48), foregroundColor: p.text),
                  onPressed: () => settings.update(() {
                    settings.khatamStart = '';
                    settings.readSet = {};
                  }),
                  child: const Text('Reset progres'),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 14, 28, 0),
              child: Text('Progres bertambah saat Anda menekan "Tandai selesai dibaca" di halaman membaca.',
                  style: uiStyle(12.5, p.sub, w: FontWeight.w400, height: 1.5)),
            ),
          ]),
        );
      });
}

// ───────────────────────── Laporan Bug / Tentang / Privasi ─────────────────────────
class BugReportPage extends StatelessWidget {
  const BugReportPage({super.key});
  @override
  Widget build(BuildContext context) => sb((c, p) => GlassScaffold(
        title: 'Laporan Bug',
        body: ListView(children: [
          GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Menemukan masalah atau punya saran?', style: uiStyle(15, p.text, w: FontWeight.w700)),
              const SizedBox(height: 8),
              Text('Kirim laporan beserta langkah terjadinya masalah dan tipe HP Anda ke:',
                  style: uiStyle(13, p.sub, w: FontWeight.w400, height: 1.5)),
              const SizedBox(height: 10),
              SelectableText(bugEmail, style: uiStyle(15, p.accent, w: FontWeight.w700)),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: p.accent, foregroundColor: Colors.black87),
                    icon: const Icon(Icons.mail_rounded),
                    label: const Text('Kirim email'),
                    onPressed: () async {
                      final info = await PackageInfo.fromPlatform();
                      final uri = Uri(scheme: 'mailto', path: bugEmail, queryParameters: {
                        'subject': 'Laporan Bug Al Quran dan Tawasul v${info.version}',
                      });
                      final ok = await launchUrl(uri);
                      if (!ok && context.mounted) {
                        Clipboard.setData(const ClipboardData(text: bugEmail));
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Email disalin')));
                      }
                    },
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(foregroundColor: p.text),
                  icon: const Icon(Icons.copy_rounded, size: 18),
                  label: const Text('Salin'),
                  onPressed: () {
                    Clipboard.setData(const ClipboardData(text: bugEmail));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Email disalin')));
                  },
                ),
              ]),
            ]),
          ),
        ]),
      ));
}

class _TextPage extends StatelessWidget {
  final String title;
  final List<String> paragraphs;
  const _TextPage(this.title, this.paragraphs);
  @override
  Widget build(BuildContext context) => sb((c, p) => GlassScaffold(
        title: title,
        body: ListView(children: [
          GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              for (final t in paragraphs)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(t, style: uiStyle(13.5, p.text, w: FontWeight.w400, height: 1.6)),
                ),
            ]),
          ),
        ]),
      ));
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});
  @override
  Widget build(BuildContext context) => const _TextPage('Tentang Kami', [
        'Al Quran dan Tawasul adalah aplikasi membaca Al-Quran 30 juz (114 surah) lengkap dengan transliterasi, terjemahan Bahasa Indonesia, tafsir Jalalayn, audio qari, serta ruang Tawasul untuk menyimpan tulisan doa secara manual dengan pilihan font Arab.',
        'Semoga bermanfaat dan menjadi amal jariyah bagi kita semua.',
        'Sumber teks Al-Quran, terjemahan, dan audio: Al Quran Cloud (alquran.cloud).',
      ]);
}

class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});
  @override
  Widget build(BuildContext context) => const _TextPage('Kebijakan Privasi', [
        'Aplikasi ini tidak meminta akun dan tidak mengumpulkan data pribadi Anda.',
        'Pengaturan, bookmark, statistik, target khatam, dan isi Tawasul disimpan hanya di perangkat Anda.',
        'Aplikasi bekerja sepenuhnya offline untuk membaca. Koneksi internet hanya dipakai untuk memutar atau mengunduh audio qari dan membuka tautan media sosial.',
        'Jika Anda mengirim laporan bug lewat email, data yang Anda tulis di email tersebut akan diterima pengembang.',
      ]);
}
