import 'package:flutter/material.dart';
import '../core/core.dart';

class UpdatePage extends StatefulWidget {
  const UpdatePage({super.key});
  @override
  State<UpdatePage> createState() => _UpdatePageState();
}

class _UpdatePageState extends State<UpdatePage> {
  final u = Updater.I;

  @override
  void initState() {
    super.initState();
    u.loadCurrent();
    if (!u.checkedOnce) u.check();
  }

  String _mb(int b) => '${(b / 1024 / 1024).toStringAsFixed(1)} MB';

  @override
  Widget build(BuildContext context) => sb((c, p) => GlassScaffold(
        title: 'Pembaruan Aplikasi',
        body: ListenableBuilder(
          listenable: u,
          builder: (ctx, _) {
            final a = u.available;
            return ListView(children: [
              GlassCard(
                child: Row(children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent.withValues(alpha: 0.18)),
                    child: Icon(a != null ? Icons.system_update_rounded : Icons.check_circle_rounded, color: p.accent),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Versi terpasang', style: uiStyle(12.5, p.sub)),
                      Text(u.currentName.isEmpty ? '…' : u.currentName, style: uiStyle(18, p.text, w: FontWeight.w700)),
                    ]),
                  ),
                  if (u.checking) SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.2, color: p.accent)),
                ]),
              ),
              if (a != null)
                GlassCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text('Pembaruan tersedia', style: uiStyle(15, p.text, w: FontWeight.w700))),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: p.accent.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(12)),
                        child: Text('Versi baru', style: uiStyle(11.5, p.accent, w: FontWeight.w700)),
                      ),
                    ]),
                    const SizedBox(height: 6),
                    Text(a.name, style: uiStyle(26, p.accent, w: FontWeight.w700)),
                    if (a.size > 0) Text('Ukuran ${_mb(a.size)}', style: uiStyle(12.5, p.sub, w: FontWeight.w400)),
                    if (a.notes.trim().isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(a.notes.trim(), style: uiStyle(13, p.text, w: FontWeight.w400, height: 1.5)),
                    ],
                    const SizedBox(height: 14),
                    if (u.downloading) ...[
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                            value: (u.progress ?? 0) > 0 ? u.progress : null,
                            minHeight: 8,
                            color: p.accent,
                            backgroundColor: p.accent.withValues(alpha: 0.18)),
                      ),
                      const SizedBox(height: 6),
                      Text('Mengunduh ${(((u.progress ?? 0) * 100).round())}%', style: uiStyle(12.5, p.sub)),
                    ] else
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(
                              backgroundColor: p.accent, foregroundColor: Colors.black87, padding: const EdgeInsets.symmetric(vertical: 14)),
                          icon: Icon(u.downloadedPath != null ? Icons.install_mobile_rounded : Icons.download_rounded),
                          label: Text(u.downloadedPath != null ? 'Pasang sekarang' : 'Unduh dan pasang'),
                          onPressed: u.downloadAndInstall,
                        ),
                      ),
                  ]),
                ),
              if (u.message != null)
                GlassCard(
                  child: Text(u.message!, style: uiStyle(13.5, p.text, w: FontWeight.w400, height: 1.5)),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(foregroundColor: p.text, side: BorderSide(color: p.glassBorder), padding: const EdgeInsets.symmetric(vertical: 14)),
                  icon: const Icon(Icons.refresh_rounded, size: 20),
                  label: const Text('Periksa pembaruan'),
                  onPressed: u.checking || u.downloading ? null : () => u.check(),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 14, 24, 0),
                child: Text(
                    'Data bacaan, penanda, dan unduhan Anda tetap aman saat pembaruan. Pemasangan memerlukan persetujuan Anda di layar Android.',
                    style: uiStyle(12, p.sub, w: FontWeight.w400, height: 1.5)),
              ),
            ]);
          },
        ),
      ));
}
