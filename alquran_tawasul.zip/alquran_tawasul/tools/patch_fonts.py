"""Daftarkan font yang diunduh (folder google_fonts/) langsung sebagai font Flutter di pubspec.yaml."""
import pathlib, re

FILES = {
    "Amiri Quran": [("AmiriQuran-Regular.ttf", 400)],
    "Scheherazade New": [("ScheherazadeNew-Regular.ttf", 400)],
    "Amiri": [("Amiri-Regular.ttf", 400)],
    "Noto Naskh Arabic": [("NotoNaskhArabic-Regular.ttf", 400)],
    "Lateef": [("Lateef-Regular.ttf", 400)],
    "Harmattan": [("Harmattan-Regular.ttf", 400)],
    "Noto Nastaliq Urdu": [("NotoNastaliqUrdu-Regular.ttf", 400)],
    "Cairo": [("Cairo-Regular.ttf", 400)],
    "Tajawal": [("Tajawal-Regular.ttf", 400)],
    "Reem Kufi": [("ReemKufi-Regular.ttf", 400)],
    "Markazi Text": [("MarkaziText-Regular.ttf", 400)],
    "El Messiri": [("ElMessiri-Regular.ttf", 400)],
    "Aref Ruqaa": [("ArefRuqaa-Regular.ttf", 400)],
    "Mirza": [("Mirza-Regular.ttf", 400)],
    "Poppins": [("Poppins-Regular.ttf", 400), ("Poppins-Medium.ttf", 500),
                ("Poppins-SemiBold.ttf", 600), ("Poppins-Bold.ttf", 700)],
}
d = pathlib.Path("google_fonts")
lines = ["  fonts:"]
for fam, items in FILES.items():
    have = [(f, w) for f, w in items if (d / f).is_file() and (d / f).stat().st_size > 1000]
    if not have:
        print("font tidak ada, dilewati:", fam)
        continue
    lines.append(f"    - family: {fam}")
    lines.append("      fonts:")
    for f, w in have:
        lines.append(f"        - asset: google_fonts/{f}")
        if w != 400:
            lines.append(f"          weight: {w}")
if not any("Amiri Quran" in l for l in lines):
    raise SystemExit("Font Amiri Quran tidak ditemukan di folder google_fonts/")
pp = pathlib.Path("pubspec.yaml")
s = pp.read_text(encoding="utf-8")
s = re.sub(r"\n  fonts:\n(?:    .*\n|      .*\n|        .*\n|          .*\n)+", "\n", s)  # buang blok lama bila ada
s = s.replace("    - google_fonts/\n", "")
s = s.replace("  uses-material-design: true\n", "  uses-material-design: true\n" + "\n".join(lines) + "\n", 1)
pp.write_text(s, encoding="utf-8")
print("Font terdaftar:", sum(1 for l in lines if "family:" in l))
