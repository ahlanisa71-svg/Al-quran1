import re, pathlib
m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
s = m.read_text()
if "android.permission.INTERNET" not in s:
    s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Al Quran dan Tawasul"', s, count=1)
if "<queries>" not in s:
    s = s.replace("</manifest>", '    <queries><intent><action android:name="android.intent.action.SENDTO"/><data android:scheme="mailto"/></intent></queries>\n</manifest>')
m.write_text(s)

# ── Latar belakang: pemutar suara (audio_service) + unduhan (foreground service) ──
s = m.read_text()
perms = [
    "android.permission.WAKE_LOCK",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK",
    "android.permission.FOREGROUND_SERVICE_DATA_SYNC",
    "android.permission.POST_NOTIFICATIONS",
]
for pm in perms:
    if pm not in s:
        s = s.replace("<application", '<uses-permission android:name="%s"/>\n    <application' % pm, 1)
s = s.replace('android:name=".MainActivity"', 'android:name="com.ryanheise.audioservice.AudioServiceActivity"', 1)
if "com.ryanheise.audioservice.AudioService\"" not in s:
    block = (
        '    <service android:name="com.ryanheise.audioservice.AudioService" android:foregroundServiceType="mediaPlayback" android:exported="true">\n'
        '      <intent-filter><action android:name="android.media.browse.MediaBrowserService"/></intent-filter>\n'
        '    </service>\n'
        '    <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver" android:exported="true">\n'
        '      <intent-filter><action android:name="android.intent.action.MEDIA_BUTTON"/></intent-filter>\n'
        '    </receiver>\n'
        '    <service android:name="com.pravera.flutter_foreground_task.service.ForegroundService" android:foregroundServiceType="dataSync" android:exported="false"/>\n'
    )
    s = s.replace("</application>", block + "</application>", 1)
m.write_text(s)
assert "AudioServiceActivity" in s, "MainActivity tidak ditemukan di manifest"
print("background service patched")

# just_audio / plugins need minSdk 21+ ; make sure it is not lower
for g in ("android/app/build.gradle", "android/app/build.gradle.kts"):
    p = pathlib.Path(g)
    if p.exists():
        t = p.read_text()
        t = re.sub(r"minSdk(Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)", "minSdk = 23" if g.endswith("kts") else "minSdkVersion 23", t)
        p.write_text(t)
print("patched")

# Matikan lint release (bug lintVitalAnalyzeRelease pada plugin); tidak mempengaruhi isi APK.
import os
init_dir = pathlib.Path.home() / ".gradle" / "init.d"
init_dir.mkdir(parents=True, exist_ok=True)
(init_dir / "skip-lint.gradle").write_text(
    "allprojects {\n"
    "    tasks.whenTaskAdded { t ->\n"
    "        if (t.name.startsWith('lintVital') || t.name.startsWith('lintAnalyze') || t.name.startsWith('lintReport')) {\n"
    "            t.enabled = false\n"
    "        }\n"
    "    }\n"
    "}\n")
gp = pathlib.Path("android/gradle.properties")
if gp.exists():
    t = gp.read_text()
    if "android.lint.skip" not in t:
        gp.write_text(t.rstrip() + "\norg.gradle.daemon=false\n")
print("lint disabled")
