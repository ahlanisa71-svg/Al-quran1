import re, pathlib
m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
s = m.read_text()
if "android.permission.INTERNET" not in s:
    s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Al Quran dan Tawasul"', s, count=1)
if "<queries>" not in s:
    s = s.replace("</manifest>", '    <queries><intent><action android:name="android.intent.action.SENDTO"/><data android:scheme="mailto"/></intent></queries>\n</manifest>')
m.write_text(s)
# just_audio / plugins need minSdk 21+ ; make sure it is not lower
for g in ("android/app/build.gradle", "android/app/build.gradle.kts"):
    p = pathlib.Path(g)
    if p.exists():
        t = p.read_text()
        t = re.sub(r"minSdk(Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)", "minSdk = 23" if g.endswith("kts") else "minSdkVersion 23", t)
        p.write_text(t)
print("patched")
