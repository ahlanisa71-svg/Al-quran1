"""Generate the app icon: Arabic text 'القرآن والتوسل' (no harakat), glass style."""
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import sys

FONT = sys.argv[1] if len(sys.argv) > 1 else "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
S = 1024

def gradient(size, top, bottom):
    img = Image.new("RGB", (size, size))
    px = img.load()
    for y in range(size):
        t = y / (size - 1)
        c = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        for x in range(size):
            px[x, y] = c
    return img

def make(foreground_only=False):
    base = Image.new("RGBA", (S, S), (0, 0, 0, 0)) if foreground_only else gradient(S, (14, 120, 84), (8, 30, 44)).convert("RGBA")
    if not foreground_only:
        glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        d = ImageDraw.Draw(glow)
        d.ellipse((-150, -200, 600, 450), fill=(255, 255, 255, 40))
        d.ellipse((520, 600, 1250, 1300), fill=(60, 220, 160, 60))
        glow = glow.filter(ImageFilter.GaussianBlur(40))
        base = Image.alpha_composite(base, glow)
    # glass panel
    pad = 190 if foreground_only else 120
    panel = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(panel)
    d.rounded_rectangle((pad, pad + 60, S - pad, S - pad - 60), radius=120,
                        fill=(255, 255, 255, 38), outline=(255, 255, 255, 140), width=5)
    base = Image.alpha_composite(base, panel)
    d = ImageDraw.Draw(base)
    f1 = ImageFont.truetype(FONT, 175, layout_engine=ImageFont.Layout.RAQM)
    f2 = ImageFont.truetype(FONT, 140, layout_engine=ImageFont.Layout.RAQM)
    for text, font, cy in (("القرآن", f1, 440), ("والتوسل", f2, 620)):
        d.text((S / 2, cy), text, font=font, fill=(255, 255, 255, 255), anchor="mm",
               direction="rtl", language="ar")
    return base

make().convert("RGB").save("assets/icon.png")
make(True).save("assets/icon_fg.png")
print("ok")
