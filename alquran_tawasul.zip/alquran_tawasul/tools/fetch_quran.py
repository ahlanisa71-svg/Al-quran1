"""Download the complete Quran (30 juz, 114 surah) and bundle it as assets/quran.json.
Runs inside GitHub Actions (needs internet). Source: api.alquran.cloud"""
import json, re, urllib.request

BASE = "https://api.alquran.cloud/v1/quran/"
EDITIONS = {"u": "quran-uthmani", "s": "quran-simple", "t": "en.transliteration",
            "i": "id.indonesian", "k": "id.jalalayn"}

ID_MEANING = ["Pembukaan","Sapi Betina","Keluarga Imran","Wanita","Hidangan","Binatang Ternak","Tempat Tertinggi","Rampasan Perang","Pengampunan","Yunus","Hud","Yusuf","Guruh","Ibrahim","Hijr","Lebah","Perjalanan Malam","Gua","Maryam","Taha","Para Nabi","Haji","Orang-orang Mukmin","Cahaya","Pembeda","Para Penyair","Semut","Kisah-kisah","Laba-laba","Bangsa Romawi","Luqman","Sujud","Golongan yang Bersekutu","Saba'","Pencipta","Yasin","Barisan-barisan","Shad","Rombongan","Yang Mengampuni","Dijelaskan","Musyawarah","Perhiasan","Kabut","Berlutut","Bukit Pasir","Muhammad","Kemenangan","Kamar-kamar","Qaf","Angin yang Menerbangkan","Bukit","Bintang","Bulan","Yang Maha Pengasih","Hari Kiamat","Besi","Wanita yang Mengajukan Gugatan","Pengusiran","Wanita yang Diuji","Barisan","Hari Jumat","Orang-orang Munafik","Hari Dinampakkan Kesalahan","Talak","Pengharaman","Kerajaan","Pena","Hari Kiamat yang Pasti","Tempat-tempat Naik","Nuh","Jin","Orang yang Berselimut","Orang yang Berkemul","Kiamat","Manusia","Malaikat Pengirim","Berita Besar","Malaikat Pencabut","Ia Bermuka Masam","Menggulung","Terbelah","Orang-orang Curang","Terbelahnya Langit","Gugusan Bintang","Yang Datang di Malam Hari","Yang Paling Tinggi","Hari Pembalasan","Fajar","Negeri","Matahari","Malam","Waktu Dhuha","Lapang","Buah Tin","Segumpal Darah","Kemuliaan","Bukti Nyata","Guncangan","Berlari Kencang","Hari Penggetar","Berlomba-lomba","Masa","Pengumpat","Gajah","Suku Quraisy","Barang-barang Berguna","Nikmat yang Banyak","Orang-orang Kafir","Pertolongan","Gejolak Api","Ikhlas","Waktu Subuh","Manusia"]
assert len(ID_MEANING) == 114, len(ID_MEANING)
NAMES = ['Al-Fatihah', 'Al-Baqarah', "Ali 'Imran", "An-Nisa'", "Al-Ma'idah", "Al-An'am", "Al-A'raf", 'Al-Anfal', 'At-Taubah', 'Yunus', 'Hud', 'Yusuf', "Ar-Ra'd", 'Ibrahim', 'Al-Hijr', 'An-Nahl', "Al-Isra'", 'Al-Kahf', 'Maryam', 'Taha', "Al-Anbiya'", 'Al-Hajj', "Al-Mu'minun", 'An-Nur', 'Al-Furqan', "Asy-Syu'ara'", 'An-Naml', 'Al-Qasas', "Al-'Ankabut", 'Ar-Rum', 'Luqman', 'As-Sajdah', 'Al-Ahzab', "Saba'", 'Fatir', 'Yasin', 'As-Saffat', 'Sad', 'Az-Zumar', 'Gafir', 'Fussilat', 'Asy-Syura', 'Az-Zukhruf', 'Ad-Dukhan', 'Al-Jasiyah', 'Al-Ahqaf', 'Muhammad', 'Al-Fath', 'Al-Hujurat', 'Qaf', 'Az-Zariyat', 'At-Tur', 'An-Najm', 'Al-Qamar', 'Ar-Rahman', "Al-Waqi'ah", 'Al-Hadid', 'Al-Mujadalah', 'Al-Hasyr', 'Al-Mumtahanah', 'As-Saff', "Al-Jumu'ah", 'Al-Munafiqun', 'At-Tagabun', 'At-Talaq', 'At-Tahrim', 'Al-Mulk', 'Al-Qalam', 'Al-Haqqah', "Al-Ma'arij", 'Nuh', 'Al-Jinn', 'Al-Muzzammil', 'Al-Muddassir', 'Al-Qiyamah', 'Al-Insan', 'Al-Mursalat', "An-Naba'", "An-Nazi'at", "'Abasa", 'At-Takwir', 'Al-Infitar', 'Al-Mutaffifin', 'Al-Insyiqaq', 'Al-Buruj', 'At-Tariq', "Al-A'la", 'Al-Gasyiyah', 'Al-Fajr', 'Al-Balad', 'Asy-Syams', 'Al-Lail', 'Ad-Duha', 'Asy-Syarh', 'At-Tin', "Al-'Alaq", 'Al-Qadr', 'Al-Bayyinah', 'Az-Zalzalah', "Al-'Adiyat", "Al-Qari'ah", 'At-Takasur', "Al-'Asr", 'Al-Humazah', 'Al-Fil', 'Quraisy', "Al-Ma'un", 'Al-Kausar', 'Al-Kafirun', 'An-Nasr', 'Al-Lahab', 'Al-Ikhlas', 'Al-Falaq', 'An-Nas']
assert len(NAMES) == 114
BISMI_WORDS = 4

def get(ed):
    print("fetching", ed, flush=True)
    req = urllib.request.Request(BASE + ed, headers={"User-Agent": "alquran-tawasul-build"})
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.load(r)["data"]["surahs"]

data = {k: get(v) for k, v in EDITIONS.items()}

def strip_bismi(text, surah, ayah):
    if ayah == 1 and surah not in (1, 9):
        parts = text.split(" ")
        if len(parts) > BISMI_WORDS:
            return " ".join(parts[BISMI_WORDS:])
    return text

out = []
for idx in range(114):
    su = data["u"][idx]
    n = su["number"]
    ayat = []
    for j, a in enumerate(su["ayahs"]):
        num = a["numberInSurah"]
        ayat.append({
            "n": num, "g": a["number"], "j": a["juz"], "p": a["page"],
            "a": strip_bismi(a["text"], n, num),
            "s": strip_bismi(data["s"][idx]["ayahs"][j]["text"], n, num),
            "t": data["t"][idx]["ayahs"][j]["text"],
            "i": data["i"][idx]["ayahs"][j]["text"],
            "k": data["k"][idx]["ayahs"][j]["text"],
        })
    out.append({"n": n, "ar": su["name"].replace("سُورَةُ ", "").replace("سورة ", ""),
                "en": NAMES[idx], "id": ID_MEANING[idx],
                "type": su["revelationType"], "ayat": ayat})

total = sum(len(s["ayat"]) for s in out)
juz = {a["j"] for s in out for a in s["ayat"]}
assert total == 6236, total
assert juz == set(range(1, 31)), juz
with open("assets/quran.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
print("OK: 114 surah,", total, "ayat, 30 juz")
