# Widget layar utama bergaya kaca + jembatan MethodChannel (dipanggil dari patch_android.py).
import glob
import pathlib
import re

m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
main_kt = glob.glob("android/app/src/main/kotlin/**/MainActivity.kt", recursive=True)
assert main_kt, "MainActivity.kt tidak ditemukan"
main_kt = pathlib.Path(main_kt[0])
pkg = re.search(r"^package\s+([\w.]+)", main_kt.read_text(), re.M).group(1)
print("package:", pkg)

main_kt.write_text(f"""package {pkg}

import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : AudioServiceActivity() {{
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {{
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "alquran/widget").setMethodCallHandler {{ call, result ->
            if (call.method == "update") {{
                val args = call.arguments as? Map<*, *>
                val e = WidgetStore.prefs(applicationContext).edit()
                if (args != null) {{
                    for ((k, v) in args) {{
                        if (k is String) {{
                            if (v is String) e.putString(k, v)
                            if (v is Int) e.putInt(k, v)
                        }}
                    }}
                }}
                e.apply()
                WidgetStore.refreshAll(applicationContext)
                result.success(null)
            }} else {{
                result.notImplemented()
            }}
        }}
    }}
}}
""")

(main_kt.parent / "GlassWidgets.kt").write_text(f"""package {pkg}

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.KeyEvent
import android.widget.RemoteViews

object WidgetStore {{
    fun prefs(c: Context) = c.getSharedPreferences("alquran_widget", Context.MODE_PRIVATE)

    fun openApp(c: Context): PendingIntent {{
        val i = c.packageManager.getLaunchIntentForPackage(c.packageName) ?: Intent()
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }}

    fun mediaKey(c: Context, code: Int): PendingIntent {{
        val i = Intent(Intent.ACTION_MEDIA_BUTTON)
        i.component = ComponentName(c, "com.ryanheise.audioservice.MediaButtonReceiver")
        i.putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, code))
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }}

    fun refreshAll(c: Context) {{
        val m = AppWidgetManager.getInstance(c)
        val a = m.getAppWidgetIds(ComponentName(c, AyatWidget::class.java))
        if (a.isNotEmpty()) m.updateAppWidget(a, AyatWidget.build(c))
        val l = m.getAppWidgetIds(ComponentName(c, LastReadWidget::class.java))
        if (l.isNotEmpty()) m.updateAppWidget(l, LastReadWidget.build(c))
        val k = m.getAppWidgetIds(ComponentName(c, KhatamWidget::class.java))
        if (k.isNotEmpty()) m.updateAppWidget(k, KhatamWidget.build(c))
        val q = m.getAppWidgetIds(ComponentName(c, PlayerWidget::class.java))
        if (q.isNotEmpty()) m.updateAppWidget(q, PlayerWidget.build(c))
    }}
}}

class AyatWidget : AppWidgetProvider() {{
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {{
        appWidgetManager.updateAppWidget(appWidgetIds, build(context))
    }}
    companion object {{
        fun build(c: Context): RemoteViews {{
            val p = WidgetStore.prefs(c)
            val v = RemoteViews(c.packageName, R.layout.widget_ayat)
            v.setTextViewText(R.id.w_ar, p.getString("daily_ar", "") ?: "")
            v.setTextViewText(R.id.w_tr, p.getString("daily_tr", "Buka aplikasi untuk memuat ayat hari ini.") ?: "")
            v.setTextViewText(R.id.w_ref, p.getString("daily_ref", "") ?: "")
            v.setOnClickPendingIntent(R.id.w_root, WidgetStore.openApp(c))
            return v
        }}
    }}
}}

class LastReadWidget : AppWidgetProvider() {{
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {{
        appWidgetManager.updateAppWidget(appWidgetIds, build(context))
    }}
    companion object {{
        fun build(c: Context): RemoteViews {{
            val p = WidgetStore.prefs(c)
            val v = RemoteViews(c.packageName, R.layout.widget_last)
            v.setTextViewText(R.id.w_title, p.getString("last_title", "Belum ada bacaan") ?: "")
            v.setTextViewText(R.id.w_sub, p.getString("last_sub", "Buka Al-Quran untuk mulai membaca") ?: "")
            v.setOnClickPendingIntent(R.id.w_root, WidgetStore.openApp(c))
            return v
        }}
    }}
}}

class KhatamWidget : AppWidgetProvider() {{
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {{
        appWidgetManager.updateAppWidget(appWidgetIds, build(context))
    }}
    companion object {{
        fun build(c: Context): RemoteViews {{
            val p = WidgetStore.prefs(c)
            val v = RemoteViews(c.packageName, R.layout.widget_khatam)
            v.setTextViewText(R.id.w_pct, p.getString("khatam_pct", "0%") ?: "0%")
            v.setTextViewText(R.id.w_sub, p.getString("khatam_sub", "") ?: "")
            v.setProgressBar(R.id.w_bar, 100, p.getInt("khatam_progress", 0), false)
            v.setOnClickPendingIntent(R.id.w_root, WidgetStore.openApp(c))
            return v
        }}
    }}
}}

class PlayerWidget : AppWidgetProvider() {{
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {{
        appWidgetManager.updateAppWidget(appWidgetIds, build(context))
    }}
    companion object {{
        fun build(c: Context): RemoteViews {{
            val p = WidgetStore.prefs(c)
            val v = RemoteViews(c.packageName, R.layout.widget_player)
            val active = p.getInt("play_active", 0) == 1
            val playing = p.getInt("play_playing", 0) == 1
            v.setTextViewText(R.id.w_title, if (active) (p.getString("play_title", "") ?: "") else "Belum ada yang diputar")
            v.setTextViewText(R.id.w_sub, if (active) (p.getString("play_sub", "") ?: "") else "Ketuk untuk membuka aplikasi")
            v.setImageViewResource(R.id.w_btn, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
            v.setOnClickPendingIntent(R.id.w_root, WidgetStore.openApp(c))
            if (active) {{
                v.setOnClickPendingIntent(R.id.w_btn, WidgetStore.mediaKey(c, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            }} else {{
                v.setOnClickPendingIntent(R.id.w_btn, WidgetStore.openApp(c))
            }}
            return v
        }}
    }}
}}
""")

res = pathlib.Path("android/app/src/main/res")
for d in ("layout", "drawable", "xml"):
    (res / d).mkdir(parents=True, exist_ok=True)

(res / "drawable/widget_glass.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <gradient android:angle="315" android:startColor="#CC1B3A38" android:endColor="#B3101622" android:type="linear"/>
    <stroke android:width="1dp" android:color="#55FFFFFF"/>
    <corners android:radius="26dp"/>
</shape>
""")
(res / "drawable/widget_pill.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <solid android:color="#336EE7B7"/>
    <corners android:radius="14dp"/>
</shape>
""")
(res / "drawable/widget_progress.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:id="@android:id/background">
        <shape android:shape="rectangle"><solid android:color="#33FFFFFF"/><corners android:radius="6dp"/></shape>
    </item>
    <item android:id="@android:id/progress">
        <clip><shape android:shape="rectangle"><solid android:color="#6EE7B7"/><corners android:radius="6dp"/></shape></clip>
    </item>
</layer-list>
""")

(res / "layout/widget_ayat.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/w_root"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp"
    android:background="@drawable/widget_glass">
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="AYAT HARI INI"
        android:textColor="#B3FFFFFF"
        android:textSize="10sp"
        android:textStyle="bold"/>
    <TextView
        android:id="@+id/w_ar"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="6dp"
        android:gravity="end"
        android:textDirection="rtl"
        android:maxLines="3"
        android:ellipsize="end"
        android:textColor="#FFFFFF"
        android:textSize="19sp"/>
    <TextView
        android:id="@+id/w_tr"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="6dp"
        android:maxLines="3"
        android:ellipsize="end"
        android:textColor="#E6FFFFFF"
        android:textSize="12sp"/>
    <TextView
        android:id="@+id/w_ref"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="4dp"
        android:textColor="#6EE7B7"
        android:textSize="11sp"
        android:textStyle="bold"/>
</LinearLayout>
""")

(res / "layout/widget_last.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/w_root"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center_vertical"
    android:padding="16dp"
    android:background="@drawable/widget_glass">
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="LANJUTKAN MEMBACA"
        android:textColor="#B3FFFFFF"
        android:textSize="10sp"
        android:textStyle="bold"/>
    <TextView
        android:id="@+id/w_title"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="6dp"
        android:maxLines="2"
        android:ellipsize="end"
        android:textColor="#FFFFFF"
        android:textSize="17sp"
        android:textStyle="bold"/>
    <TextView
        android:id="@+id/w_sub"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="2dp"
        android:maxLines="1"
        android:ellipsize="end"
        android:textColor="#D9FFFFFF"
        android:textSize="12sp"/>
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="10dp"
        android:background="@drawable/widget_pill"
        android:paddingLeft="12dp"
        android:paddingRight="12dp"
        android:paddingTop="5dp"
        android:paddingBottom="5dp"
        android:text="Buka"
        android:textColor="#6EE7B7"
        android:textSize="12sp"
        android:textStyle="bold"/>
</LinearLayout>
""")

(res / "layout/widget_khatam.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/w_root"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center_vertical"
    android:padding="16dp"
    android:background="@drawable/widget_glass">
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="TARGET KHATAM"
        android:textColor="#B3FFFFFF"
        android:textSize="10sp"
        android:textStyle="bold"/>
    <TextView
        android:id="@+id/w_pct"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="4dp"
        android:textColor="#FFFFFF"
        android:textSize="30sp"
        android:textStyle="bold"/>
    <ProgressBar
        android:id="@+id/w_bar"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="match_parent"
        android:layout_height="8dp"
        android:layout_marginTop="6dp"
        android:max="100"
        android:progressDrawable="@drawable/widget_progress"/>
    <TextView
        android:id="@+id/w_sub"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="6dp"
        android:maxLines="1"
        android:ellipsize="end"
        android:textColor="#D9FFFFFF"
        android:textSize="11sp"/>
</LinearLayout>
""")


(res / "drawable/ic_w_play.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp" android:height="28dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#6EE7B7" android:pathData="M8,5v14l11,-7z"/>
</vector>
""")
(res / "drawable/ic_w_pause.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="28dp" android:height="28dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#6EE7B7" android:pathData="M6,5h4v14h-4zM14,5h4v14h-4z"/>
</vector>
""")
(res / "drawable/widget_btn.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="oval">
    <solid android:color="#336EE7B7"/>
    <stroke android:width="1dp" android:color="#556EE7B7"/>
</shape>
""")
(res / "layout/widget_player.xml").write_text("""<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/w_root"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="horizontal"
    android:gravity="center_vertical"
    android:paddingLeft="18dp"
    android:paddingRight="14dp"
    android:paddingTop="12dp"
    android:paddingBottom="12dp"
    android:background="@drawable/widget_glass">
    <LinearLayout
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_weight="1"
        android:orientation="vertical">
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="SEDANG DIPUTAR"
            android:textColor="#B3FFFFFF"
            android:textSize="10sp"
            android:textStyle="bold"/>
        <TextView
            android:id="@+id/w_title"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="3dp"
            android:maxLines="1"
            android:ellipsize="end"
            android:textColor="#FFFFFF"
            android:textSize="16sp"
            android:textStyle="bold"/>
        <TextView
            android:id="@+id/w_sub"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:maxLines="1"
            android:ellipsize="end"
            android:textColor="#D9FFFFFF"
            android:textSize="12sp"/>
    </LinearLayout>
    <ImageView
        android:id="@+id/w_btn"
        android:layout_width="52dp"
        android:layout_height="52dp"
        android:padding="12dp"
        android:background="@drawable/widget_btn"
        android:contentDescription="Putar atau jeda"
        android:src="@drawable/ic_w_play"/>
</LinearLayout>
""")


def info(name, w, h, cw, ch, layout):
    (res / f"xml/{name}.xml").write_text(f"""<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="{w}dp"
    android:minHeight="{h}dp"
    android:targetCellWidth="{cw}"
    android:targetCellHeight="{ch}"
    android:updatePeriodMillis="3600000"
    android:initialLayout="@layout/{layout}"
    android:resizeMode="horizontal|vertical"
    android:widgetCategory="home_screen"/>
""")


info("widget_ayat_info", 250, 110, 4, 2, "widget_ayat")
info("widget_last_info", 110, 110, 2, 2, "widget_last")
info("widget_khatam_info", 110, 110, 2, 2, "widget_khatam")
info("widget_player_info", 250, 70, 4, 1, "widget_player")

s = m.read_text()
if "AyatWidget" not in s:
    rec = ""
    for cls, rn in (("AyatWidget", "widget_ayat_info"), ("LastReadWidget", "widget_last_info"), ("KhatamWidget", "widget_khatam_info"), ("PlayerWidget", "widget_player_info")):
        rec += (f'    <receiver android:name=".{cls}" android:exported="true">\n'
                '      <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/></intent-filter>\n'
                f'      <meta-data android:name="android.appwidget.provider" android:resource="@xml/{rn}"/>\n'
                '    </receiver>\n')
    s = s.replace("</application>", rec + "</application>", 1)
    m.write_text(s)
print("widgets written")
